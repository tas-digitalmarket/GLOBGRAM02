# 🎯 راه‌حل نهایی: رفع مشکل عدم نمایش دیالوگ میکروفون در اپلیکیشن اندروید

## خلاصه مشکل
- اپلیکیشن اندروید WebView که فایل‌های محلی (`file://`) یا HTTP (`http://`) بارگذاری می‌کند
- عدم نمایش دیالوگ مجوز میکروفون به دلیل عدم Secure Context
- Chrome 47+ فقط در Secure Context اجازه `getUserMedia()` می‌دهد

## 🥇 بهترین راه‌حل: سرور localhost داخلی

### چرا این راه‌حل بهترین است؟
✅ `localhost` حتی با `http://` نیز Secure Context محسوب می‌شود
✅ کاملاً serverless - بدون نیاز به سرور خارجی
✅ سازگاری کامل با WebRTC و میکروفون
✅ عملکرد بهتر از `file://` URLs

---

## 📋 گام‌های پیاده‌سازی

### 1️⃣ اضافه کردن وابستگی به build.gradle

```gradle
dependencies {
    implementation 'org.nanohttpd:nanohttpd:2.3.1'
    // سایر dependencies
}
```

### 2️⃣ ایجاد کلاس SimpleLocalServer.java

```java
package com.example.globgram;

import android.content.Context;
import android.content.res.AssetManager;
import android.util.Log;
import java.io.IOException;
import java.io.InputStream;
import fi.iki.elonen.NanoHTTPD;

public class SimpleLocalServer extends NanoHTTPD {
    private static final String TAG = "LocalServer";
    private static final int PORT = 8080;
    private Context context;
    
    public SimpleLocalServer(Context context) {
        super("localhost", PORT);
        this.context = context;
    }
    
    @Override
    public Response serve(IHTTPSession session) {
        String uri = session.getUri();
        if (uri.startsWith("/")) uri = uri.substring(1);
        if (uri.isEmpty()) uri = "index.html";
        
        try {
            AssetManager assetManager = context.getAssets();
            InputStream inputStream = assetManager.open("www/" + uri);
            String mimeType = getMimeType(uri);
            
            Response response = newFixedLengthResponse(Response.Status.OK, mimeType, inputStream, inputStream.available());
            response.addHeader("Access-Control-Allow-Origin", "*");
            return response;
            
        } catch (IOException e) {
            return newFixedLengthResponse(Response.Status.NOT_FOUND, MIME_PLAINTEXT, "File not found: " + uri);
        }
    }
    
    private String getMimeType(String uri) {
        if (uri.endsWith(".html")) return "text/html; charset=utf-8";
        if (uri.endsWith(".js")) return "application/javascript; charset=utf-8";
        if (uri.endsWith(".css")) return "text/css; charset=utf-8";
        if (uri.endsWith(".json")) return "application/json; charset=utf-8";
        return "text/plain; charset=utf-8";
    }
    
    public String getServerUrl() {
        return "http://localhost:" + PORT + "/";
    }
}
```

### 3️⃣ بهبود MainActivity.java

```java
package com.example.globgram;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "GlobgramWebView";
    private static final int REQUEST_MICROPHONE = 1001;
    
    private WebView webView;
    private SimpleLocalServer localServer;
    private PermissionRequest mPermissionRequest;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        startLocalServer();
        setupWebView();
        checkAndRequestPermissions();
    }
    
    private void startLocalServer() {
        try {
            localServer = new SimpleLocalServer(this);
            localServer.start();
            Log.d(TAG, "Local server started: " + localServer.getServerUrl());
        } catch (Exception e) {
            Log.e(TAG, "Failed to start local server", e);
        }
    }

    private void setupWebView() {
        webView = findViewById(R.id.webview);
        
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        webSettings.setMediaPlaybackRequiresUserGesture(false); // مهم!
        webSettings.setDatabaseEnabled(true);
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            webSettings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            WebView.setWebContentsDebuggingEnabled(true);
        }

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                Log.d(TAG, "Page loaded: " + url);
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(PermissionRequest request) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    mPermissionRequest = request;
                    
                    if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.RECORD_AUDIO) 
                            == PackageManager.PERMISSION_GRANTED) {
                        
                        runOnUiThread(() -> request.grant(request.getResources()));
                    } else {
                        ActivityCompat.requestPermissions(MainActivity.this,
                                new String[]{Manifest.permission.RECORD_AUDIO},
                                REQUEST_MICROPHONE);
                    }
                }
            }
        });

        webView.addJavascriptInterface(new WebAppInterface(this), "AndroidAudio");

        if (localServer != null) {
            webView.loadUrl(localServer.getServerUrl());
        }
    }

    private void checkAndRequestPermissions() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) 
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.RECORD_AUDIO},
                    REQUEST_MICROPHONE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        
        if (requestCode == REQUEST_MICROPHONE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                if (mPermissionRequest != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    runOnUiThread(() -> {
                        mPermissionRequest.grant(mPermissionRequest.getResources());
                        mPermissionRequest = null;
                    });
                }
                new android.os.Handler().postDelayed(() -> webView.reload(), 500);
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (localServer != null) {
            localServer.stop();
        }
    }
}
```

### 4️⃣ بهبود AndroidManifest.xml

```xml
<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.example.globgram">

    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.RECORD_AUDIO" />
    <uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />
    
    <uses-feature 
        android:name="android.hardware.microphone" 
        android:required="false" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:theme="@style/AppTheme"
        android:usesCleartextTraffic="true"
        android:networkSecurityConfig="@xml/network_security_config">

        <activity
            android:name=".MainActivity"
            android:configChanges="orientation|screenSize"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

    </application>
</manifest>
```

### 5️⃣ ایجاد network_security_config.xml

در `res/xml/network_security_config.xml`:

```xml
<?xml version="1.0" encoding="utf-8"?>
<network-security-config>
    <domain-config cleartextTrafficPermitted="true">
        <domain includeSubdomains="true">localhost</domain>
        <domain includeSubdomains="true">127.0.0.1</domain>
    </domain-config>
</network-security-config>
```

### 6️⃣ کپی فایل‌های وب به assets/www/

ساختار پوشه:
```
src/main/assets/www/
├── index.html
├── chat-room.html
├── styles.css
└── src/
    ├── voice-manager.js
    ├── auth.js
    └── سایر فایل‌ها
```

---

## 🧪 تست و اعتبارسنجی

### استفاده از صفحه تست

1. فایل `secure-context-test.html` را در assets/www قرار دهید
2. اپلیکیشن را اجرا کنید
3. به `http://localhost:8080/secure-context-test.html` بروید
4. تست‌های مختلف را اجرا کنید

### بررسی‌های مهم

✅ Secure Context: true
✅ getUserMedia موجود است
✅ دیالوگ مجوز نمایش داده می‌شود
✅ ضبط صدا کار می‌کند

---

## 🔧 عیب‌یابی

### مشکلات رایج و راه‌حل‌ها

**1. سرور شروع نمی‌شود**
```
خطا: BindException: Address already in use
راه‌حل: پورت را تغییر دهید یا سرور قبلی را متوقف کنید
```

**2. صفحه‌ها بارگذاری نمی‌شوند**
```
بررسی: آیا فایل‌ها در assets/www قرار دارند؟
بررسی: آیا مجوز INTERNET در Manifest است؟
```

**3. میکروفون کار نمی‌کند**
```
بررسی: setMediaPlaybackRequiresUserGesture(false)
بررسی: onPermissionRequest پیاده‌سازی شده
بررسی: مجوز RECORD_AUDIO در Manifest
```

### دیباگ کردن

```bash
# اتصال به device
adb connect DEVICE_IP

# مشاهده لاگ‌ها
adb logcat | grep "GlobgramWebView\|LocalServer\|chromium"

# دسترسی به WebView debugger
# Chrome -> chrome://inspect -> دستگاه خود را انتخاب کنید
```

---

## ⚠️ نکات مهم

### محدودیت‌ها
- پورت 8080 باید آزاد باشد
- فایل‌های بزرگ ممکن است کند بارگذاری شوند
- Self-signed certificate در Play Store مشکل ایجاد کند

### بهینه‌سازی
- فشرده‌سازی فایل‌های CSS/JS
- Cache headers اضافه کردن
- Gzip compression فعال کردن

### امنیت
- فقط روی localhost گوش دادن
- فایل‌های حساس را در assets قرار ندادن
- Permission های غیرضروری حذف کردن

---

## 🚀 نتیجه‌گیری

این راه‌حل:
✅ 100% serverless است
✅ Secure Context کامل فراهم می‌کند  
✅ با تمام نسخه‌های Android سازگار است
✅ میکروفون و WebRTC را پشتیبانی می‌کند
✅ بدون نیاز به HTTPS خارجی کار می‌کند

با پیاده‌سازی این تغییرات، دیالوگ مجوز میکروفون به درستی نمایش داده می‌شود و مشکل صفحه سفید رفع خواهد شد.
