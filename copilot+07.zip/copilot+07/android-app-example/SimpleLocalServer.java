package com.example.globgram;

import android.content.Context;
import android.content.res.AssetManager;
import android.util.Log;

import java.io.IOException;
import java.io.InputStream;

import fi.iki.elonen.NanoHTTPD;

/**
 * سرور HTTP ساده برای سرو فایل‌های محلی
 * این نسخه بدون SSL است و روی localhost:8080 کار می‌کند
 */
public class SimpleLocalServer extends NanoHTTPD {
    private static final String TAG = "SimpleLocalServer";
    private static final int PORT = 8080;
    private Context context;
    
    public SimpleLocalServer(Context context) {
        super("localhost", PORT);
        this.context = context;
        Log.d(TAG, "Local HTTP Server initialized on port " + PORT);
    }
    
    @Override
    public Response serve(IHTTPSession session) {
        String uri = session.getUri();
        String method = session.getMethod().toString();
        Log.d(TAG, method + " " + uri);
        
        // اضافه کردن CORS headers برای جلوگیری از مشکلات CORS
        Response response = handleRequest(uri);
        response.addHeader("Access-Control-Allow-Origin", "*");
        response.addHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
        response.addHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
        
        return response;
    }
    
    private Response handleRequest(String uri) {
        // حذف / از ابتدای URI
        if (uri.startsWith("/")) {
            uri = uri.substring(1);
        }
        
        // اگر URI خالی است، index.html را برگردان
        if (uri.isEmpty()) {
            uri = "index.html";
        }
        
        try {
            // خواندن فایل از assets
            AssetManager assetManager = context.getAssets();
            InputStream inputStream = assetManager.open("www/" + uri);
            
            // تشخیص MIME type
            String mimeType = getMimeType(uri);
            
            return newFixedLengthResponse(Response.Status.OK, mimeType, inputStream, inputStream.available());
            
        } catch (IOException e) {
            Log.e(TAG, "File not found: " + uri, e);
            return newFixedLengthResponse(Response.Status.NOT_FOUND, MIME_PLAINTEXT, 
                "<!DOCTYPE html><html><body><h1>File not found: " + uri + "</h1></body></html>");
        }
    }
    
    private String getMimeType(String uri) {
        String lowerUri = uri.toLowerCase();
        
        if (lowerUri.endsWith(".html") || lowerUri.endsWith(".htm")) {
            return "text/html; charset=utf-8";
        }
        if (lowerUri.endsWith(".js")) {
            return "application/javascript; charset=utf-8";
        }
        if (lowerUri.endsWith(".css")) {
            return "text/css; charset=utf-8";
        }
        if (lowerUri.endsWith(".json")) {
            return "application/json; charset=utf-8";
        }
        if (lowerUri.endsWith(".png")) {
            return "image/png";
        }
        if (lowerUri.endsWith(".jpg") || lowerUri.endsWith(".jpeg")) {
            return "image/jpeg";
        }
        if (lowerUri.endsWith(".gif")) {
            return "image/gif";
        }
        if (lowerUri.endsWith(".svg")) {
            return "image/svg+xml";
        }
        if (lowerUri.endsWith(".ico")) {
            return "image/x-icon";
        }
        if (lowerUri.endsWith(".woff") || lowerUri.endsWith(".woff2")) {
            return "font/woff";
        }
        if (lowerUri.endsWith(".ttf")) {
            return "font/ttf";
        }
        
        return "text/plain; charset=utf-8";
    }
    
    public String getServerUrl() {
        return "http://localhost:" + PORT + "/";
    }
}
