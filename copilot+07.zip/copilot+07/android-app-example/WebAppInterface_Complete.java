package com.example.globgram;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.util.Log;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

/**
 * رابط جاوااسکریپت پیشرفته برای ارتباط با کد native
 */
public class WebAppInterface {
    private static final String TAG = "WebAppInterface";
    private static final int REQUEST_MICROPHONE = 1002;
    
    private Context mContext;
    private WebView mWebView;
    private boolean mReloadRequired = false;

    public WebAppInterface(Context context, WebView webView) {
        this.mContext = context;
        this.mWebView = webView;
        Log.d(TAG, "WebAppInterface initialized");
    }
    
    public WebAppInterface(Context context) {
        this.mContext = context;
        Log.d(TAG, "WebAppInterface initialized (simple mode)");
    }

    /**
     * نمایش پیام toast از جاوااسکریپت
     */
    @JavascriptInterface
    public void showToast(String message) {
        Toast.makeText(mContext, message, Toast.LENGTH_LONG).show();
        Log.d(TAG, "Toast shown: " + message);
    }
    
    /**
     * ثبت پیام debug از جاوااسکریپت
     */
    @JavascriptInterface
    public void logDebug(String message) {
        Log.d(TAG, "JS Debug: " + message);
    }
    
    /**
     * ثبت خطا از جاوااسکریپت
     */
    @JavascriptInterface
    public void logError(String message) {
        Log.e(TAG, "JS Error: " + message);
    }
    
    /**
     * بررسی وضعیت مجوز میکروفون
     */
    @JavascriptInterface
    public boolean hasAudioPermission() {
        boolean hasPermission = ContextCompat.checkSelfPermission(mContext, Manifest.permission.RECORD_AUDIO) 
                == PackageManager.PERMISSION_GRANTED;
        Log.d(TAG, "hasAudioPermission check: " + hasPermission);
        return hasPermission;
    }
    
    /**
     * درخواست مجوز میکروفون
     */
    @JavascriptInterface
    public boolean requestPermission() {
        if (mContext instanceof Activity) {
            Activity activity = (Activity) mContext;
            
            if (ContextCompat.checkSelfPermission(mContext, Manifest.permission.RECORD_AUDIO) 
                    == PackageManager.PERMISSION_GRANTED) {
                Log.d(TAG, "Permission already granted");
                return true;
            }
            
            Log.d(TAG, "Requesting RECORD_AUDIO permission from JavaScript");
            
            // درخواست از سیستم اندروید
            ActivityCompat.requestPermissions(activity,
                    new String[]{Manifest.permission.RECORD_AUDIO},
                    REQUEST_MICROPHONE);
            
            // تنظیم فلگ برای reload
            mReloadRequired = true;
            
            return false; // نتیجه در callback بررسی می‌شود
        }
        Log.w(TAG, "Context is not an Activity, cannot request permission");
        return false;
    }
    
    /**
     * بررسی نیاز به reload بعد از تغییر مجوز
     */
    @JavascriptInterface
    public boolean getReloadRequired() {
        return mReloadRequired;
    }
    
    /**
     * ریست کردن فلگ reload
     */
    @JavascriptInterface
    public void resetReloadFlag() {
        mReloadRequired = false;
        Log.d(TAG, "Reload flag reset");
    }
    
    /**
     * بازنشانی WebView
     */
    @JavascriptInterface
    public void reloadWebView() {
        if (mWebView != null && mContext instanceof Activity) {
            Activity activity = (Activity) mContext;
            activity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Log.d(TAG, "Reloading WebView from JavaScript");
                    mWebView.reload();
                }
            });
        }
    }
    
    /**
     * باز کردن تنظیمات اپلیکیشن
     */
    @JavascriptInterface
    public void openSettings() {
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri = Uri.fromParts("package", mContext.getPackageName(), null);
        intent.setData(uri);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        mContext.startActivity(intent);
        Log.d(TAG, "Opening app settings");
    }
    
    /**
     * دریافت اطلاعات دستگاه برای دیباگ
     */
    @JavascriptInterface
    public String getDeviceInfo() {
        String info = "Android SDK: " + Build.VERSION.SDK_INT + 
                     ", Device: " + Build.DEVICE +
                     ", Model: " + Build.MODEL +
                     ", Manufacturer: " + Build.MANUFACTURER +
                     ", Brand: " + Build.BRAND;
        Log.d(TAG, "Device info requested: " + info);
        return info;
    }
    
    /**
     * دریافت نسخه اپلیکیشن
     */
    @JavascriptInterface
    public String getAppVersion() {
        try {
            String version = mContext.getPackageManager()
                    .getPackageInfo(mContext.getPackageName(), 0).versionName;
            Log.d(TAG, "App version: " + version);
            return version;
        } catch (Exception e) {
            Log.e(TAG, "Error getting app version", e);
            return "Unknown";
        }
    }
    
    /**
     * فعال/غیرفعال کردن WebView debugging
     */
    @JavascriptInterface
    public void setWebViewDebugging(boolean enabled) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            WebView.setWebContentsDebuggingEnabled(enabled);
            Log.d(TAG, "WebView debugging " + (enabled ? "enabled" : "disabled"));
        }
    }
    
    /**
     * بررسی وضعیت شبکه
     */
    @JavascriptInterface
    public boolean isNetworkAvailable() {
        try {
            android.net.ConnectivityManager cm = (android.net.ConnectivityManager) 
                    mContext.getSystemService(Context.CONNECTIVITY_SERVICE);
            android.net.NetworkInfo networkInfo = cm.getActiveNetworkInfo();
            boolean available = networkInfo != null && networkInfo.isConnected();
            Log.d(TAG, "Network available: " + available);
            return available;
        } catch (Exception e) {
            Log.e(TAG, "Error checking network", e);
            return false;
        }
    }
    
    /**
     * دریافت اطلاعات WebView
     */
    @JavascriptInterface
    public String getWebViewInfo() {
        try {
            String userAgent = "";
            if (mWebView != null) {
                userAgent = mWebView.getSettings().getUserAgentString();
            }
            
            String info = "WebView User Agent: " + userAgent + 
                         ", WebView Package: " + getCurrentWebViewPackage();
            
            Log.d(TAG, "WebView info: " + info);
            return info;
        } catch (Exception e) {
            Log.e(TAG, "Error getting WebView info", e);
            return "Error getting WebView info";
        }
    }
    
    private String getCurrentWebViewPackage() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                return android.webkit.WebView.getCurrentWebViewPackage().packageName;
            } else {
                return "Unknown (API < 26)";
            }
        } catch (Exception e) {
            return "Unknown";
        }
    }
    
    /**
     * تست اتصال به سرور محلی
     */
    @JavascriptInterface
    public boolean testLocalServerConnection() {
        try {
            // این متد می‌تواند اتصال به سرور محلی را تست کند
            Log.d(TAG, "Testing local server connection");
            return true; // فعلاً همیشه true برمی‌گرداند
        } catch (Exception e) {
            Log.e(TAG, "Error testing local server", e);
            return false;
        }
    }
    
    /**
     * ارسال analytics یا crash report
     */
    @JavascriptInterface
    public void reportError(String errorType, String errorMessage, String stackTrace) {
        Log.e(TAG, "JS Error Report - Type: " + errorType + ", Message: " + errorMessage);
        Log.e(TAG, "JS Stack Trace: " + stackTrace);
        
        // اینجا می‌توانید کد ارسال گزارش خطا به سرور analytics اضافه کنید
    }
    
    /**
     * نمایش dialog native
     */
    @JavascriptInterface
    public void showNativeDialog(String title, String message) {
        if (mContext instanceof Activity) {
            Activity activity = (Activity) mContext;
            activity.runOnUiThread(() -> {
                new android.app.AlertDialog.Builder(activity)
                    .setTitle(title)
                    .setMessage(message)
                    .setPositiveButton("باشه", null)
                    .show();
            });
        }
    }
}
