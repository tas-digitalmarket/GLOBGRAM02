package com.example.globgram;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.webkit.PermissionRequest;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

/**
 * MainActivity کامل برای Globgram با پشتیبانی کامل میکروفون
 */
public class MainActivity extends AppCompatActivity {
    private static final String TAG = "GlobgramWebView";
    private static final int REQUEST_MICROPHONE = 1001;
    private static final int REQUEST_ALL_PERMISSIONS = 1002;
    
    // مجوزهای مورد نیاز
    private static final String[] REQUIRED_PERMISSIONS = {
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.MODIFY_AUDIO_SETTINGS
    };
    
    private WebView webView;
    private LocalSecureServer localServer;
    private PermissionRequest pendingPermissionRequest;
    private WebAppInterface webAppInterface;
    private boolean permissionChanged = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Log.d(TAG, "Starting Globgram Application");
        
        // شروع سرور محلی
        startLocalServer();
        
        // راه‌اندازی WebView
        setupWebView();
        
        // بررسی و درخواست مجوزها
        checkAndRequestPermissions();
    }

    /**
     * راه‌اندازی سرور محلی (HTTP/HTTPS)
     */
    private void startLocalServer() {
        try {
            // ابتدا تلاش برای HTTPS
            localServer = new LocalSecureServer(this, true);
            
            try {
                localServer.start();
                Log.d(TAG, "HTTPS Server started: " + localServer.getServerUrl());
                Toast.makeText(this, "سرور امن راه‌اندازی شد", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Log.w(TAG, "HTTPS failed, falling back to HTTP", e);
                localServer.stop();
                
                // fallback به HTTP
                localServer = new LocalSecureServer(this, false);
                localServer.start();
                Log.d(TAG, "HTTP Server started: " + localServer.getServerUrl());
                Toast.makeText(this, "سرور محلی راه‌اندازی شد (HTTP)", Toast.LENGTH_SHORT).show();
            }
            
        } catch (Exception e) {
            Log.e(TAG, "Failed to start any server", e);
            Toast.makeText(this, "خطا در راه‌اندازی سرور: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    /**
     * تنظیم کامل WebView
     */
    private void setupWebView() {
        webView = findViewById(R.id.webview);
        
        // تنظیمات پایه WebView
        configureWebViewSettings();
        
        // تنظیم WebViewClient
        setupWebViewClient();
        
        // تنظیم WebChromeClient برای مدیریت مجوزها
        setupWebChromeClient();
        
        // اضافه کردن JavaScript Interface
        setupJavaScriptInterface();
        
        // بارگذاری صفحه اصلی
        loadMainPage();
    }

    private void configureWebViewSettings() {
        WebSettings webSettings = webView.getSettings();
        
        // تنظیمات اساسی
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        webSettings.setDatabaseEnabled(true);
        webSettings.setAppCacheEnabled(true);
        
        // تنظیمات دسترسی فایل
        webSettings.setAllowFileAccess(true);
        webSettings.setAllowContentAccess(true);
        webSettings.setAllowFileAccessFromFileURLs(true);
        webSettings.setAllowUniversalAccessFromFileURLs(true);
        
        // تنظیمات مهم برای میکروفون
        webSettings.setMediaPlaybackRequiresUserGesture(false); // مهم!
        
        // تنظیمات امنیتی
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            webSettings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }
        
        // تنظیمات عملکرد
        webSettings.setCacheMode(WebSettings.LOAD_DEFAULT);
        webSettings.setRenderPriority(WebSettings.RenderPriority.HIGH);
        webSettings.setEnableSmoothTransition(true);
        
        // تنظیمات debugging
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG);
        }
        
        Log.d(TAG, "WebView settings configured");
    }

    private void setupWebViewClient() {
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                Log.d(TAG, "Loading URL: " + url);
                view.loadUrl(url);
                return true;
            }
            
            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                Log.d(TAG, "Page started: " + url);
            }
            
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                Log.d(TAG, "Page finished: " + url);
                
                // اطلاع به JavaScript که صفحه بارگذاری شده
                String script = "console.log('WebView: Page loaded in secure context: ' + window.isSecureContext);";
                view.evaluateJavascript(script, null);
                
                // اگر مجوز تغییر کرده، اطلاع به JavaScript
                if (permissionChanged) {
                    Log.d(TAG, "Permission changed, notifying JavaScript");
                    permissionChanged = false;
                    
                    view.evaluateJavascript(
                        "if (window.runEnvironmentTest) { setTimeout(function() { window.runEnvironmentTest(); }, 1000); }",
                        null
                    );
                }
            }
            
            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    Log.e(TAG, "WebView Error: " + error.getDescription() + " for " + request.getUrl());
                    if (request.isForMainFrame()) {
                        showErrorToUser("خطا در بارگذاری صفحه: " + error.getDescription());
                    }
                }
            }
            
            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                Log.e(TAG, "WebView Error: " + description + " for " + failingUrl);
                showErrorToUser("خطا در بارگذاری: " + description);
            }
            
            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, android.net.http.SslError error) {
                // برای localhost و self-signed certificate، خطای SSL را نادیده می‌گیریم
                Log.w(TAG, "SSL Error ignored for localhost: " + error);
                handler.proceed();
            }
        });
    }

    private void setupWebChromeClient() {
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(PermissionRequest request) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    Log.d(TAG, "WebView permission request from: " + request.getOrigin());
                    Log.d(TAG, "Requested resources: " + java.util.Arrays.toString(request.getResources()));
                    
                    pendingPermissionRequest = request;
                    
                    // بررسی مجوز اندروید
                    if (hasAllPermissions()) {
                        // اعطای فوری مجوز به WebView
                        grantWebViewPermission(request);
                    } else {
                        // درخواست مجوز از کاربر
                        Log.d(TAG, "Requesting permissions from user");
                        requestPermissionsFromUser();
                    }
                }
            }
            
            @Override
            public void onPermissionRequestCanceled(PermissionRequest request) {
                super.onPermissionRequestCanceled(request);
                Log.d(TAG, "Permission request canceled");
                pendingPermissionRequest = null;
            }
            
            @Override
            public void onConsoleMessage(String message, int lineNumber, String sourceID) {
                Log.d(TAG, "Console: " + message + " (line " + lineNumber + " in " + sourceID + ")");
            }
            
            @Override
            public boolean onConsoleMessage(android.webkit.ConsoleMessage consoleMessage) {
                Log.d(TAG, "Console: " + consoleMessage.message() + 
                          " (" + consoleMessage.messageLevel() + ") at " + 
                          consoleMessage.sourceId() + ":" + consoleMessage.lineNumber());
                return true;
            }
        });
    }

    private void setupJavaScriptInterface() {
        webAppInterface = new WebAppInterface(this, webView);
        webView.addJavascriptInterface(webAppInterface, "AndroidAudio");
        Log.d(TAG, "AndroidAudio JavaScript interface added");
    }

    private void loadMainPage() {
        if (localServer != null) {
            String url = localServer.getServerUrl();
            Log.d(TAG, "Loading from local server: " + url);
            webView.loadUrl(url);
        } else {
            // fallback به file://
            Log.w(TAG, "Local server not available, using file://");
            webView.loadUrl("file:///android_asset/www/index.html");
        }
    }

    /**
     * بررسی و درخواست مجوزها
     */
    private void checkAndRequestPermissions() {
        if (!hasAllPermissions()) {
            Log.d(TAG, "Some permissions missing, requesting...");
            requestPermissionsFromUser();
        } else {
            Log.d(TAG, "All permissions already granted");
        }
    }

    private boolean hasAllPermissions() {
        for (String permission : REQUIRED_PERMISSIONS) {
            if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                return false;
            }
        }
        return true;
    }

    private void requestPermissionsFromUser() {
        ActivityCompat.requestPermissions(this, REQUIRED_PERMISSIONS, REQUEST_ALL_PERMISSIONS);
    }

    private void grantWebViewPermission(PermissionRequest request) {
        runOnUiThread(() -> {
            try {
                request.grant(request.getResources());
                Log.d(TAG, "Permission granted to WebView");
                
                // اطلاع به JavaScript
                webView.evaluateJavascript(
                    "console.log('WebView: Microphone permission granted');",
                    null
                );
            } catch (Exception e) {
                Log.e(TAG, "Error granting permission to WebView", e);
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        
        if (requestCode == REQUEST_ALL_PERMISSIONS || requestCode == REQUEST_MICROPHONE) {
            boolean allGranted = true;
            StringBuilder deniedPermissions = new StringBuilder();
            
            for (int i = 0; i < permissions.length; i++) {
                if (grantResults[i] != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    if (deniedPermissions.length() > 0) {
                        deniedPermissions.append(", ");
                    }
                    deniedPermissions.append(permissions[i]);
                }
            }
            
            if (allGranted) {
                Log.d(TAG, "All permissions granted");
                Toast.makeText(this, "تمام مجوزها اعطا شد", Toast.LENGTH_SHORT).show();
                permissionChanged = true;
                
                // اعطای مجوز به WebView در صورت انتظار
                if (pendingPermissionRequest != null) {
                    grantWebViewPermission(pendingPermissionRequest);
                    pendingPermissionRequest = null;
                }
                
                // بازنشانی صفحه برای اعمال مجوزها
                reloadPageAfterPermissionChange();
                
            } else {
                Log.d(TAG, "Some permissions denied: " + deniedPermissions.toString());
                handlePermissionDenied(deniedPermissions.toString());
            }
        }
    }

    private void handlePermissionDenied(String deniedPermissions) {
        String message = "برای عملکرد صحیح برنامه، مجوزهای زیر ضروری است:\n" + deniedPermissions;
        
        // بررسی اینکه آیا کاربر "دیگر نپرس" را انتخاب کرده
        boolean shouldShowRationale = false;
        for (String permission : REQUIRED_PERMISSIONS) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, permission)) {
                shouldShowRationale = true;
                break;
            }
        }
        
        if (!shouldShowRationale) {
            // کاربر "دیگر نپرس" را انتخاب کرده، به تنظیمات هدایت می‌کنیم
            showPermissionSettingsDialog();
        } else {
            // نمایش پیام توضیحی و درخواست مجدد
            new AlertDialog.Builder(this)
                .setTitle("مجوز مورد نیاز")
                .setMessage(message)
                .setPositiveButton("تلاش مجدد", (dialog, which) -> checkAndRequestPermissions())
                .setNegativeButton("انصراف", (dialog, which) -> finish())
                .show();
        }
    }

    private void showPermissionSettingsDialog() {
        new AlertDialog.Builder(this)
            .setTitle("تنظیمات مجوز")
            .setMessage("لطفاً مجوز میکروفون را در تنظیمات برنامه فعال کنید.")
            .setPositiveButton("باز کردن تنظیمات", (dialog, which) -> openAppSettings())
            .setNegativeButton("انصراف", (dialog, which) -> finish())
            .show();
    }

    private void openAppSettings() {
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri = Uri.fromParts("package", getPackageName(), null);
        intent.setData(uri);
        startActivity(intent);
    }

    private void reloadPageAfterPermissionChange() {
        new android.os.Handler().postDelayed(() -> {
            Log.d(TAG, "Reloading WebView after permission change");
            if (webView != null) {
                webView.reload();
            }
        }, 500);
    }

    private void showErrorToUser(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        
        // بررسی وضعیت مجوزها هنگام بازگشت به اپلیکیشن
        if (hasAllPermissions()) {
            Log.d(TAG, "onResume: All permissions available");
            
            // اطلاع به JavaScript
            if (webView != null) {
                webView.evaluateJavascript(
                    "if (window.runEnvironmentTest) { window.runEnvironmentTest(); }",
                    null
                );
            }
        } else {
            Log.d(TAG, "onResume: Some permissions missing");
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (webView != null) {
            webView.onPause();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        
        // توقف سرور محلی
        if (localServer != null) {
            localServer.stop();
            Log.d(TAG, "Local server stopped");
        }
        
        // پاکسازی WebView
        if (webView != null) {
            webView.removeJavascriptInterface("AndroidAudio");
            webView.destroy();
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
