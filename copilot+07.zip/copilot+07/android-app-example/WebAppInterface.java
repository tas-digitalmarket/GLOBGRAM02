package com.example.globgram;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.provider.Settings;
import android.util.Log;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

/**
 * JavaScript interface to provide native functionality to web app
 */
public class WebAppInterface {
    private static final String TAG = "WebAppInterface";
    private static final int REQUEST_MICROPHONE = 1002;
    
    private Context mContext;

    public WebAppInterface(Context context) {
        this.mContext = context;
    }

    /**
     * Show a toast message from JavaScript
     */
    @JavascriptInterface
    public void showToast(String message) {
        Toast.makeText(mContext, message, Toast.LENGTH_LONG).show();
    }
    
    /**
     * Log debug message from JavaScript
     */
    @JavascriptInterface
    public void logDebug(String message) {
        Log.d(TAG, "JS Debug: " + message);
    }
    
    /**
     * Check if microphone permission is granted
     */
    @JavascriptInterface
    public boolean hasAudioPermission() {
        return ContextCompat.checkSelfPermission(mContext, Manifest.permission.RECORD_AUDIO) 
                == PackageManager.PERMISSION_GRANTED;
    }
    
    /**
     * Request microphone permission
     */
    @JavascriptInterface
    public boolean requestPermission() {
        if (mContext instanceof Activity) {
            Activity activity = (Activity) mContext;
            
            if (ContextCompat.checkSelfPermission(mContext, Manifest.permission.RECORD_AUDIO) 
                    == PackageManager.PERMISSION_GRANTED) {
                return true;
            }
            
            ActivityCompat.requestPermissions(activity,
                    new String[]{Manifest.permission.RECORD_AUDIO},
                    REQUEST_MICROPHONE);
            
            // This will return false, but the permission result will be handled in MainActivity
            return false;
        }
        return false;
    }
    
    /**
     * Open application settings
     */
    @JavascriptInterface
    public void openSettings() {
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri = Uri.fromParts("package", mContext.getPackageName(), null);
        intent.setData(uri);
        mContext.startActivity(intent);
    }
    
    /**
     * Get device info for debugging
     */
    @JavascriptInterface
    public String getDeviceInfo() {
        return "Android SDK: " + android.os.Build.VERSION.SDK_INT + 
               ", Device: " + android.os.Build.DEVICE +
               ", Model: " + android.os.Build.MODEL;
    }
}
