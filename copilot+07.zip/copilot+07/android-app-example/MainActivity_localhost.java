package com.example.globgram;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

/**
 * MainActivity ساده‌شده برای استفاده با سرور HTTP محلی
 */
public class MainActivity extends AppCompatActivity {
    private static final String TAG = "GlobgramWebView";
    private static final int REQUEST_MICROPHONE = 1001;
    
    private WebView webView;
    private SimpleLocalServer localServer;
    private PermissionRequest mPermissionRequest;
    private WebAppInterface webAppInterface;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // شروع سرور محلی
        startLocalServer();
        
        // راه‌اندازی WebView
        setupWebView();
        
        // درخواست مجوزها
        checkAndRequestPermissions();
    }
    
    private void startLocalServer() {
        try {
            localServer = new SimpleLocalServer(this);
            localServer.start();
            Log.d(TAG, "Local server started: " + localServer.getServerUrl());
            Toast.makeText(this, "سرور محلی راه‌اندازی شد", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Log.e(TAG, "Failed to start local server", e);
            Toast.makeText(this, "خطا در راه‌اندازی سرور محلی: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void setupWebView() {
        webView = findViewById(R.id.webview);
        
        // تنظیمات اساسی WebView
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        webSettings.setAllowFileAccess(true);
        webSettings.setAllowContentAccess(true);
        webSettings.setAllowFileAccessFromFileURLs(true);
        webSettings.setAllowUniversalAccessFromFileURLs(true);
        webSettings.setMediaPlaybackRequiresUserGesture(false); // مهم برای میکروفون
        webSettings.setDatabaseEnabled(true);
        webSettings.setAppCacheEnabled(true);
        
        // تنظیمات امنیتی
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            webSettings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }
        
        // فعال کردن debugging برای توسعه
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            WebView.setWebContentsDebuggingEnabled(true);
        }

        // تنظیم WebViewClient
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                Log.d(TAG, "Loading URL: " + url);
                view.loadUrl(url);
                return true;
            }
            
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                Log.d(TAG, "Page loaded successfully: " + url);
                
                // اطلاع به JavaScript که صفحه بارگذاری شده
                view.evaluateJavascript(
                    "console.log('WebView: Page loaded in secure context: ' + window.isSecureContext);",
                    null
                );
            }
            
            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    Log.e(TAG, "WebView Error: " + error.getDescription() + " for " + request.getUrl());
                }
            }
            
            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                Log.e(TAG, "WebView Error: " + description + " for " + failingUrl);
                Toast.makeText(MainActivity.this, "خطا در بارگذاری: " + description, Toast.LENGTH_LONG).show();
            }
        });

        // تنظیم WebChromeClient برای مدیریت مجوزها
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(PermissionRequest request) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    Log.d(TAG, "WebView permission request from: " + request.getOrigin());
                    Log.d(TAG, "Requested resources: " + java.util.Arrays.toString(request.getResources()));
                    
                    mPermissionRequest = request;
                    
                    // بررسی مجوز اندروید
                    if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.RECORD_AUDIO) 
                            == PackageManager.PERMISSION_GRANTED) {
                        
                        // اعطای مجوز به WebView
                        runOnUiThread(() -> {
                            try {
                                request.grant(request.getResources());
                                Log.d(TAG, "Permission granted to WebView");
                                
                                // اطلاع به JavaScript
                                webView.evaluateJavascript(
                                    "console.log('WebView: Microphone permission granted');",
                                    null
                                );
                            } catch (Exception e) {
                                Log.e(TAG, "Error granting permission", e);
                            }
                        });
                    } else {
                        // درخواست مجوز از کاربر
                        Log.d(TAG, "Requesting RECORD_AUDIO permission from user");
                        ActivityCompat.requestPermissions(MainActivity.this,
                                new String[]{Manifest.permission.RECORD_AUDIO},
                                REQUEST_MICROPHONE);
                    }
                }
            }
            
            @Override
            public void onConsoleMessage(String message, int lineNumber, String sourceID) {
                Log.d(TAG, "Console: " + message + " (line " + lineNumber + " in " + sourceID + ")");
            }
        });

        // اضافه کردن JavaScript Interface
        webAppInterface = new WebAppInterface(this, webView);
        webView.addJavascriptInterface(webAppInterface, "AndroidAudio");
        Log.d(TAG, "AndroidAudio JavaScript interface added");

        // بارگذاری صفحه از سرور محلی
        if (localServer != null) {
            String url = localServer.getServerUrl();
            Log.d(TAG, "Loading URL: " + url);
            webView.loadUrl(url);
        } else {
            // fallback به file://
            Log.w(TAG, "Local server not available, using file://");
            webView.loadUrl("file:///android_asset/www/index.html");
        }
    }

    private void checkAndRequestPermissions() {
        String[] permissions = {
            Manifest.permission.RECORD_AUDIO
        };
        
        boolean needsPermission = false;
        for (String permission : permissions) {
            if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                needsPermission = true;
                break;
            }
        }
        
        if (needsPermission) {
            Log.d(TAG, "Requesting permissions: " + java.util.Arrays.toString(permissions));
            ActivityCompat.requestPermissions(this, permissions, REQUEST_MICROPHONE);
        } else {
            Log.d(TAG, "All permissions already granted");
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        
        if (requestCode == REQUEST_MICROPHONE) {
            boolean allGranted = true;
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    break;
                }
            }
            
            if (allGranted) {
                Log.d(TAG, "All permissions granted");
                Toast.makeText(this, "مجوز میکروفون اعطا شد", Toast.LENGTH_SHORT).show();
                
                // اعطای مجوز به WebView در صورت انتظار
                if (mPermissionRequest != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    runOnUiThread(() -> {
                        try {
                            mPermissionRequest.grant(mPermissionRequest.getResources());
                            Log.d(TAG, "Pending permission request granted");
                            mPermissionRequest = null;
                        } catch (Exception e) {
                            Log.e(TAG, "Error granting pending permission", e);
                        }
                    });
                }
                
                // بازنشانی صفحه برای اعمال مجوزها
                new android.os.Handler().postDelayed(() -> {
                    Log.d(TAG, "Reloading WebView to apply permissions");
                    webView.reload();
                }, 500);
                
            } else {
                Log.d(TAG, "Some permissions denied");
                Toast.makeText(this, "برای عملکرد صحیح برنامه، مجوز میکروفون ضروری است", Toast.LENGTH_LONG).show();
                
                // باز کردن تنظیمات اپلیکیشن
                boolean shouldShow = false;
                for (String permission : permissions) {
                    if (!ActivityCompat.shouldShowRequestPermissionRationale(this, permission)) {
                        shouldShow = true;
                        break;
                    }
                }
                
                if (shouldShow) {
                    if (webAppInterface != null) {
                        webAppInterface.openSettings();
                    }
                }
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        
        // بررسی وضعیت مجوزها هنگام بازگشت به اپلیکیشن
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) 
                == PackageManager.PERMISSION_GRANTED) {
            Log.d(TAG, "onResume: Microphone permission available");
            
            // اطلاع به JavaScript
            if (webView != null) {
                webView.evaluateJavascript(
                    "if (window.runEnvironmentTest) { window.runEnvironmentTest(); }",
                    null
                );
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        
        // توقف سرور محلی
        if (localServer != null) {
            localServer.stop();
            Log.d(TAG, "Local server stopped");
        }
        
        // پاکسازی WebView
        if (webView != null) {
            webView.removeJavascriptInterface("AndroidAudio");
            webView.destroy();
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
