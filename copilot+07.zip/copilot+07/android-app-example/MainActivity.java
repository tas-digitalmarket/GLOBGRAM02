package com.example.globgram;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "GlobgramWebView";
    private static final int REQUEST_MICROPHONE = 1001;
    private WebView webView;
    private PermissionRequest mPermissionRequest;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize WebView
        webView = findViewById(R.id.webview);
        setupWebView();
        
        // Check and request permissions
        checkAndRequestPermissions();
    }

    private void setupWebView() {
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        webSettings.setAllowFileAccess(true);
        webSettings.setAllowContentAccess(true);
        webSettings.setDatabaseEnabled(true);
        webSettings.setMediaPlaybackRequiresUserGesture(false);
        
        // Enable debugging if in development build
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            WebView.setWebContentsDebuggingEnabled(true);
        }

        // Set WebViewClient to handle navigation
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                view.loadUrl(url);
                return true;
            }
            
            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                Log.e(TAG, "WebView Error: " + description);
                Toast.makeText(MainActivity.this, "خطا: " + description, Toast.LENGTH_LONG).show();
            }
        });

        // Set WebChromeClient to handle permissions
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(PermissionRequest request) {
                Log.d(TAG, "onPermissionRequest: " + request.getOrigin().toString());
                
                mPermissionRequest = request;
                
                // Check if microphone permission is granted
                if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.RECORD_AUDIO) 
                        == PackageManager.PERMISSION_GRANTED) {
                    // Grant permission to WebView
                    String[] resources = request.getResources();
                    request.grant(resources);
                    Log.d(TAG, "Permission granted to WebView");
                } else {
                    // Request permission from user
                    ActivityCompat.requestPermissions(MainActivity.this, 
                            new String[]{Manifest.permission.RECORD_AUDIO}, 
                            REQUEST_MICROPHONE);
                }
            }
            
            @Override
            public void onConsoleMessage(String message, int lineNumber, String sourceID) {
                Log.d(TAG, "Console: " + message + " -- From line " + lineNumber + " of " + sourceID);
            }
        });

        // Add JavaScript interface for enhanced functionality
        webView.addJavascriptInterface(new WebAppInterface(this), "AndroidAudio");

        // Load the main HTML file
        webView.loadUrl("file:///android_asset/www/index.html");
        // Or for online version:
        // webView.loadUrl("https://your-website.com");
    }

    private void checkAndRequestPermissions() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) 
                != PackageManager.PERMISSION_GRANTED) {
            
            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.RECORD_AUDIO)) {
                Toast.makeText(this, "دسترسی به میکروفون برای ضبط صدا ضروری است", Toast.LENGTH_LONG).show();
            }
            
            ActivityCompat.requestPermissions(this, 
                    new String[]{Manifest.permission.RECORD_AUDIO}, 
                    REQUEST_MICROPHONE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        
        if (requestCode == REQUEST_MICROPHONE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted
                Log.d(TAG, "Microphone permission granted");
                
                // Grant permission to WebView if request is pending
                if (mPermissionRequest != null) {
                    mPermissionRequest.grant(mPermissionRequest.getResources());
                    mPermissionRequest = null;
                }
                
                // Reload WebView to apply permissions
                webView.reload();
                
            } else {
                // Permission denied
                Log.d(TAG, "Microphone permission denied");
                Toast.makeText(this, "برای استفاده از قابلیت صوتی، دسترسی میکروفون لازم است", Toast.LENGTH_LONG).show();
                
                // Open app settings if permission was permanently denied
                if (!ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.RECORD_AUDIO)) {
                    openAppSettings();
                }
            }
        }
    }

    private void openAppSettings() {
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri = Uri.fromParts("package", getPackageName(), null);
        intent.setData(uri);
        startActivity(intent);
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
