package com.example.globgram;

import android.content.Context;
import android.content.res.AssetManager;
import android.util.Log;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.interfaces.RSAPrivateKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Base64;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLServerSocketFactory;

import fi.iki.elonen.NanoHTTPD;

/**
 * سرور HTTPS محلی برای ایجاد Secure Context
 * این سرور فقط روی localhost کار می‌کند و کاملاً آفلاین است
 */
public class LocalSecureServer extends NanoHTTPD {
    private static final String TAG = "LocalSecureServer";
    private static final int HTTPS_PORT = 8443;
    private static final int HTTP_PORT = 8080;
    
    private Context context;
    private boolean useHttps;

    public LocalSecureServer(Context context, boolean useHttps) {
        super("127.0.0.1", useHttps ? HTTPS_PORT : HTTP_PORT);
        this.context = context;
        this.useHttps = useHttps;
        
        if (useHttps) {
            try {
                // ایجاد SSL context با self-signed certificate
                makeSecure(createSSLSocketFactory(), null);
                Log.d(TAG, "HTTPS Server initialized on port " + HTTPS_PORT);
            } catch (Exception e) {
                Log.e(TAG, "Failed to initialize HTTPS", e);
                useHttps = false;
            }
        } else {
            Log.d(TAG, "HTTP Server initialized on port " + HTTP_PORT);
        }
    }

    @Override
    public Response serve(IHTTPSession session) {
        String uri = session.getUri();
        String method = session.getMethod().toString();
        
        Log.d(TAG, method + " " + uri);

        // حذف / از ابتدای URI
        if (uri.startsWith("/")) {
            uri = uri.substring(1);
        }
        
        // اگر URI خالی است، index.html را برگردان
        if (uri.isEmpty()) {
            uri = "index.html";
        }

        try {
            // خواندن فایل از assets
            AssetManager assetManager = context.getAssets();
            InputStream inputStream = assetManager.open("www/" + uri);
            
            // تشخیص MIME type
            String mimeType = getMimeType(uri);
            
            // ایجاد response با headers مناسب
            Response response = newFixedLengthResponse(Response.Status.OK, mimeType, inputStream, inputStream.available());
            
            // اضافه کردن headers ضروری
            addSecurityHeaders(response);
            
            return response;
            
        } catch (IOException e) {
            Log.e(TAG, "File not found: " + uri, e);
            return create404Response(uri);
        }
    }
    
    private void addSecurityHeaders(Response response) {
        // CORS headers
        response.addHeader("Access-Control-Allow-Origin", "*");
        response.addHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
        response.addHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
        
        // Security headers
        response.addHeader("X-Content-Type-Options", "nosniff");
        response.addHeader("X-Frame-Options", "SAMEORIGIN");
        
        // Cache headers
        response.addHeader("Cache-Control", "no-cache, no-store, must-revalidate");
        response.addHeader("Pragma", "no-cache");
        response.addHeader("Expires", "0");
    }
    
    private Response create404Response(String uri) {
        String html = "<!DOCTYPE html>" +
                "<html><head><title>404 Not Found</title></head>" +
                "<body style='font-family: Arial; text-align: center; padding: 50px;'>" +
                "<h1>404 - File Not Found</h1>" +
                "<p>The file <code>" + uri + "</code> was not found.</p>" +
                "<p><a href='/'>Go to Home</a></p>" +
                "</body></html>";
        
        Response response = newFixedLengthResponse(Response.Status.NOT_FOUND, "text/html", html);
        addSecurityHeaders(response);
        return response;
    }

    private String getMimeType(String uri) {
        String lowerUri = uri.toLowerCase();
        
        if (lowerUri.endsWith(".html") || lowerUri.endsWith(".htm")) {
            return "text/html; charset=utf-8";
        }
        if (lowerUri.endsWith(".js")) {
            return "application/javascript; charset=utf-8";
        }
        if (lowerUri.endsWith(".css")) {
            return "text/css; charset=utf-8";
        }
        if (lowerUri.endsWith(".json")) {
            return "application/json; charset=utf-8";
        }
        if (lowerUri.endsWith(".png")) {
            return "image/png";
        }
        if (lowerUri.endsWith(".jpg") || lowerUri.endsWith(".jpeg")) {
            return "image/jpeg";
        }
        if (lowerUri.endsWith(".gif")) {
            return "image/gif";
        }
        if (lowerUri.endsWith(".svg")) {
            return "image/svg+xml";
        }
        if (lowerUri.endsWith(".ico")) {
            return "image/x-icon";
        }
        if (lowerUri.endsWith(".woff") || lowerUri.endsWith(".woff2")) {
            return "font/woff";
        }
        if (lowerUri.endsWith(".ttf")) {
            return "font/ttf";
        }
        if (lowerUri.endsWith(".mp3")) {
            return "audio/mpeg";
        }
        if (lowerUri.endsWith(".wav")) {
            return "audio/wav";
        }
        
        return "text/plain; charset=utf-8";
    }

    private SSLServerSocketFactory createSSLSocketFactory() throws Exception {
        // ایجاد self-signed certificate برای localhost
        String certificate = "-----BEGIN CERTIFICATE-----\n" +
                "MIIDETCCAfkCAQAwDQYJKoZIhvcNAQELBQAwGDEWMBQGA1UEAwwNbG9jYWxob3N0\n" +
                "-----END CERTIFICATE-----";
        
        String privateKey = "-----BEGIN PRIVATE KEY-----\n" +
                "MIIEvwIBADANBgkqhkiG9w0BAQEFAASCBKkwggSlAgEAAoIBAQC8Q7HgL8Yb5Y4z\n" +
                "-----END PRIVATE KEY-----";
        
        // در واقعیت، باید certificate و private key واقعی استفاده کنید
        // برای سادگی، از یک keystore خالی استفاده می‌کنیم
        
        KeyStore keyStore = KeyStore.getInstance(KeyStore.getDefaultType());
        keyStore.load(null, null);
        
        KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
        kmf.init(keyStore, "password".toCharArray());
        
        SSLContext sslContext = SSLContext.getInstance("TLS");
        sslContext.init(kmf.getKeyManagers(), null, new SecureRandom());
        
        return sslContext.getServerSocketFactory();
    }

    public String getServerUrl() {
        String protocol = useHttps ? "https" : "http";
        int port = useHttps ? HTTPS_PORT : HTTP_PORT;
        return protocol + "://127.0.0.1:" + port + "/";
    }
    
    public boolean isSecure() {
        return useHttps;
    }
}
