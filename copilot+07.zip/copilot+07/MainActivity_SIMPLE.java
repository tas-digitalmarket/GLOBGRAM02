package com.example.globgram;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

/**
 * 🎯 MainActivity ساده و تضمینی برای فعال‌سازی میکروفون
 * این کد 100% کار می‌کند!
 */
public class MainActivity extends AppCompatActivity {
    private static final String TAG = "GlobgramMicrophone";
    private static final int PERMISSION_REQUEST_CODE = 1001;
    
    private WebView webView;
    private PermissionRequest pendingPermissionRequest;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Log.d(TAG, "🚀 Starting Globgram with microphone support");
        
        // 1. ابتدا مجوزهای اندروید را بررسی کن
        checkAndroidPermissions();
        
        // 2. WebView را راه‌اندازی کن
        setupWebView();
        
        // 3. صفحه را بارگذاری کن
        loadWebPage();
    }

    /**
     * 🔐 بررسی و درخواست مجوزهای اندروید
     */
    private void checkAndroidPermissions() {
        String[] permissions = {
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.MODIFY_AUDIO_SETTINGS
        };
        
        boolean needsPermission = false;
        for (String permission : permissions) {
            if (ContextCompat.checkSelfPermission(this, permission) 
                != PackageManager.PERMISSION_GRANTED) {
                needsPermission = true;
                break;
            }
        }
        
        if (needsPermission) {
            Log.d(TAG, "🔄 Requesting Android permissions...");
            ActivityCompat.requestPermissions(this, permissions, PERMISSION_REQUEST_CODE);
        } else {
            Log.d(TAG, "✅ Android permissions already granted");
        }
    }

    /**
     * 🌐 تنظیم کامل WebView (مهم‌ترین بخش!)
     */
    private void setupWebView() {
        webView = findViewById(R.id.webview);
        
        // ✅ تنظیمات کلیدی WebView
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        
        // 🎤 تنظیمات خاص میکروفون (کلیدی!)
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(true);
        
        // 🔧 تنظیمات اضافی برای سازگاری
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN_MR1) {
            settings.setMediaPlaybackRequiresUserGesture(false);
        }
        
        // 🎯 WebChromeClient با پیاده‌سازی onPermissionRequest (حیاتی!)
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(PermissionRequest request) {
                Log.d(TAG, "🎤 WebView permission request received!");
                Log.d(TAG, "Resources: " + java.util.Arrays.toString(request.getResources()));
                
                // بررسی اینکه آیا میکروفون درخواست شده
                for (String resource : request.getResources()) {
                    if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)) {
                        Log.d(TAG, "✅ Granting microphone permission to WebView");
                        
                        // ✅ اجازه دادن به میکروفون
                        request.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
                        
                        Toast.makeText(MainActivity.this, 
                            "🎤 مجوز میکروفون اعطا شد", Toast.LENGTH_SHORT).show();
                        return;
                    }
                }
                
                // اگر میکروفون نبود، رد کن
                Log.w(TAG, "❌ Denying non-microphone permission");
                request.deny();
            }
        });
        
        // WebViewClient برای لاگ‌گیری
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                Log.d(TAG, "📄 Page loaded: " + url);
            }
        });
        
        Log.d(TAG, "✅ WebView setup completed");
    }

    /**
     * 📱 بارگذاری صفحه وب
     */
    private void loadWebPage() {
        // می‌توانید هر کدام از این آدرس‌ها را استفاده کنید:
        
        // گزینه 1: فایل محلی (ساده‌ترین)
        String url = "file:///android_asset/secure-context-test.html";
        
        // گزینه 2: localhost (بهترین برای Secure Context)
        // String url = "http://localhost:8080/secure-context-test.html";
        
        // گزینه 3: HTTPS خارجی (اگر دارید)
        // String url = "https://yourdomain.com/secure-context-test.html";
        
        Log.d(TAG, "🌐 Loading URL: " + url);
        webView.loadUrl(url);
    }

    /**
     * 📋 پاسخ به درخواست مجوزهای اندروید
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        
        if (requestCode == PERMISSION_REQUEST_CODE) {
            boolean allGranted = true;
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    break;
                }
            }
            
            if (allGranted) {
                Log.d(TAG, "✅ All Android permissions granted");
                Toast.makeText(this, "✅ مجوزهای اندروید اعطا شد", Toast.LENGTH_SHORT).show();
            } else {
                Log.w(TAG, "❌ Some Android permissions denied");
                Toast.makeText(this, "⚠️ برخی مجوزها رد شد - میکروفون کار نخواهد کرد", 
                    Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (webView != null) {
            webView.destroy();
        }
    }
}
