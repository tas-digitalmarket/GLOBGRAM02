class ChatRoom {
    constructor() {
        this.connectionManager = new ConnectionManager();
        this.voiceManager = new VoiceManager();
        this.currentRoom = null;
        this.isInitialized = false;
    }

    async initialize() {
        if (this.isInitialized) return;

        console.log('ChatRoom: Starting initialization...');
        
        // بررسی ساده session بدون database
        const sessionCheck = this.checkLocalSession();
        if (!sessionCheck.valid) {
            console.warn('ChatRoom: Invalid local session detected:', sessionCheck.reason);
            this.redirectToHome();
            return;
        }
        
        console.log('ChatRoom: Session valid, proceeding with initialization');
        
        const roomCode = localStorage.getItem('currentRoomCode');
        const isJoining = window.location.search.includes('join');
        
        if (!roomCode) {
            console.warn('ChatRoom: No room code found');
            this.showError('کد اتاق یافت نشد');
            setTimeout(() => this.redirectToHome(), 2000);
            return;
        }

        try {
            console.log('ChatRoom: Initializing room:', roomCode);
            this.currentRoom = roomCode;
            this.updateRoomDisplay(roomCode);
            
            // راه‌اندازی اتصالات
            await this.connectionManager.initializePeer(roomCode, !isJoining);
            
            // بارگذاری پیام‌های موجود
            await this.loadExistingRecordings();
            
            // تنظیم event listeners
            this.setupEventListeners();
            
            // تنظیم global references
            window.connectionManager = this.connectionManager;
            window.ChatRoom = this;
            
            this.isInitialized = true;
            console.log('ChatRoom initialized successfully');
            
        } catch (error) {
            console.error('Failed to initialize chat room:', error);
            this.showError('خطا در راه‌اندازی اتاق چت');
            setTimeout(() => this.redirectToHome(), 3000);
        }
    }

    updateRoomDisplay(roomCode) {
        const roomCodeDisplay = document.getElementById('roomCodeDisplay');
        if (roomCodeDisplay) {
            roomCodeDisplay.textContent = roomCode;
        }
        
        // فراخوانی تابع در chat-room.html اگر موجود است
        if (typeof window.updateRoomCode === 'function') {
            window.updateRoomCode(roomCode);
        }
        
        // تنظیم عنوان صفحه
        document.title = `اتاق ${roomCode} | Globgram`;
    }

    setupEventListeners() {
        const recordButton = document.getElementById('recordButton');
        const stopButton = document.getElementById('stopButton');
        const leaveButton = document.getElementById('leaveRoom');

        if (recordButton) {
            recordButton.onclick = () => this.voiceManager.startRecording();
        }

        if (stopButton) {
            stopButton.onclick = () => this.voiceManager.stopRecording();
        }
        
        if (leaveButton) {
            leaveButton.onclick = () => this.leaveRoom();
        }

        // کلیدهای میانبر
        document.addEventListener('keydown', (e) => {
            if (e.code === 'Space' && e.ctrlKey) {
                e.preventDefault();
                if (this.voiceManager.isRecording) {
                    this.voiceManager.stopRecording();
                } else {
                    this.voiceManager.startRecording();
                }
            }
        });

        // مدیریت تغییر وضعیت صفحه
        document.addEventListener('visibilitychange', () => {
            if (document.hidden && this.voiceManager.isRecording) {
                this.voiceManager.stopRecording();
            }
        });

        // مدیریت خروج از صفحه
        window.addEventListener('beforeunload', (e) => {
            if (this.voiceManager.isRecording) {
                e.preventDefault();
                e.returnValue = 'ضبط صدا در حال انجام است. آیا مطمئن هستید؟';
            }
        });
    }

    async loadExistingRecordings() {
        try {
            console.log('Loading existing recordings for room:', this.currentRoom);
            const recordings = await DatabaseManager.getVoicesByRoom(this.currentRoom);
            const recordingsContainer = document.getElementById('chatMessages');
            
            if (recordingsContainer) {
                // پیام‌های سیستم را حفظ کنیم
                const systemMessages = recordingsContainer.querySelectorAll('.message:not(.voice-message)');
                
                // فقط پیام‌های صوتی را پاک می‌کنیم
                const voiceMessages = recordingsContainer.querySelectorAll('.voice-message, .recording-item');
                voiceMessages.forEach(msg => msg.remove());
                
                if (recordings.length === 0) {
                    this.showEmptyState();
                } else {
                    console.log(`Found ${recordings.length} recordings to load`);
                    
                    recordings.forEach((recording, index) => {
                        try {
                            const currentUser = Utils.getCurrentUser();
                            const isCurrentUser = recording.userEmail === currentUser.email;
                            
                            // تولید URL جدید برای هر بار بارگذاری
                            if (recording.blob && recording.blob instanceof Blob) {
                                const audioUrl = URL.createObjectURL(recording.blob);
                                console.log(`Creating audio URL for recording ${index}:`, {
                                    voiceId: recording.voiceId,
                                    blobSize: recording.blob.size,
                                    blobType: recording.blob.type,
                                    url: audioUrl
                                });
                                
                                this.displayRecording(
                                    audioUrl,
                                    !isCurrentUser,
                                    recording.timestamp,
                                    recording.voiceId,
                                    recording.userEmail,
                                    recording.userAvatar || CONFIG.DEFAULT_AVATAR,
                                    recording.userName || recording.userEmail,
                                    {
                                        uploaded: recording.uploaded || false,
                                        fileName: recording.fileName || null,
                                        duration: recording.duration || 0,
                                        platform: recording.platform || 'unknown'
                                    }
                                );
                            } else {
                                console.warn('Invalid blob for recording:', recording.voiceId);
                                // نمایش پیام خطا برای رکورد نامعتبر
                                this.displayCorruptedRecording(recording);
                            }
                        } catch (error) {
                            console.error('Error displaying individual recording:', error);
                        }
                    });
                }
            }
        } catch (error) {
            console.error('Error loading recordings:', error);
            this.showError('خطا در بارگذاری پیام‌ها: ' + error.message);
        }
    }

    showEmptyState() {
        const recordingsContainer = document.getElementById('chatMessages');
        if (recordingsContainer) {
            // اگر قبلاً پیام‌های سیستم وجود دارند، آنها را حفظ کنیم
            const systemMessages = Array.from(recordingsContainer.querySelectorAll('.message:not(.voice-message):not(.recording-item)'));
            
            if (systemMessages.length === 0) {
                recordingsContainer.innerHTML += `
                    <div class="empty-state">
                        <div class="empty-icon">🎙️</div>
                        <h3>هنوز پیامی ارسال نشده</h3>
                        <p>اولین نفری باشید که پیام صوتی ارسال می‌کند!</p>
                    </div>
                `;
            }
        }
    }

    // تابع ساده بررسی session محلی
    checkLocalSession() {
        try {
            const userEmail = localStorage.getItem('userEmail');
            const userVerified = localStorage.getItem('userVerified');
            const loginTimestamp = localStorage.getItem('loginTimestamp');
            
            console.log('ChatRoom: Checking local session:', {
                email: userEmail,
                verified: userVerified,
                timestamp: loginTimestamp
            });
            
            if (!userEmail || !userVerified) {
                return { valid: false, reason: 'Missing email or verification status' };
            }
            
            if (userVerified !== 'true') {
                return { valid: false, reason: 'User not verified' };
            }
            
            // بررسی اختیاری timestamp (اگر خیلی قدیمی باشد)
            if (loginTimestamp) {
                const loginTime = parseInt(loginTimestamp);
                const now = Date.now();
                const maxAge = 30 * 24 * 60 * 60 * 1000; // 30 روز
                
                if (now - loginTime > maxAge) {
                    console.warn('ChatRoom: Session expired');
                    return { valid: false, reason: 'Session expired' };
                }
            }
            
            return { 
                valid: true, 
                email: userEmail,
                verified: userVerified === 'true',
                loginTime: loginTimestamp 
            };
            
        } catch (error) {
            console.error('ChatRoom: Error checking local session:', error);
            return { valid: false, reason: 'Session check error', error };
        }
    }

    // بهبود showError برای نمایش بهتر در Android
    showError(message, duration = 5000) {
        console.error('ChatRoom Error:', message);
        
        const recordingsContainer = document.getElementById('recordings');
        if (recordingsContainer) {
            recordingsContainer.innerHTML = `
                <div class="error-state">
                    <div class="error-icon">⚠️</div>
                    <h3>خطا</h3>
                    <p>${message}</p>
                    <div class="error-actions">
                        <button onclick="window.location.reload()" class="retry-button">تلاش مجدد</button>
                        <button onclick="window.location.href='index.html'" class="home-button">بازگشت به خانه</button>
                    </div>
                </div>
            `;
        }
        
        // Toast notification برای Android
        if (window.showToast) {
            window.showToast(message, 'error');
        }
    }

    displayRecording(audioUrl, isRemote, timestamp, voiceId, userEmail, userAvatar, userName, additionalInfo = null) {
        const recordingsContainer = document.getElementById('chatMessages');
        if (!recordingsContainer) {
            console.warn('Chat messages container not found');
            return;
        }

        // حذف empty state اگر وجود دارد
        const emptyState = recordingsContainer.querySelector('.empty-state');
        if (emptyState) {
            emptyState.remove();
        }

        // بررسی اینکه آیا این recording قبلاً نمایش داده شده
        const existingRecording = recordingsContainer.querySelector(`[data-voice-id="${voiceId}"]`);
        if (existingRecording) {
            console.log('Recording already displayed:', voiceId);
            return;
        }

        const recordingItem = document.createElement('div');
        recordingItem.className = `recording-item ${isRemote ? 'remote' : 'local'}`;
        recordingItem.setAttribute('data-voice-id', voiceId);
        
        // اضافه کردن کلاس اضافی برای فایل‌های آپلود شده
        if (additionalInfo?.uploaded) {
            recordingItem.classList.add('uploaded');
        }

        const avatar = document.createElement('img');
        avatar.className = 'recording-avatar';
        avatar.src = userAvatar || CONFIG.DEFAULT_AVATAR;
        avatar.alt = 'تصویر پروفایل';
        avatar.onerror = () => {
            avatar.src = CONFIG.DEFAULT_AVATAR;
        };

        const content = document.createElement('div');
        content.className = 'recording-content';

        const audio = document.createElement('audio');
        audio.src = audioUrl;
        audio.controls = true;
        audio.preload = 'metadata';
        
        // اضافه کردن event listeners برای audio
        audio.addEventListener('loadedmetadata', () => {
            console.log('Audio loaded successfully for voice:', voiceId);
        });
        
        audio.addEventListener('error', (error) => {
            console.error('Audio loading error for voice:', voiceId, error);
            // نمایش پیام خطا
            const errorDiv = document.createElement('div');
            errorDiv.className = 'audio-error';
            errorDiv.innerHTML = `
                <span class="error-icon">⚠️</span>
                <span>خطا در بارگذاری فایل صوتی</span>
            `;
            audio.replaceWith(errorDiv);
        });
        
        audio.addEventListener('play', () => {
            console.log('Playing audio:', voiceId);
            // متوقف کردن سایر صداها
            document.querySelectorAll('audio').forEach(otherAudio => {
                if (otherAudio !== audio && !otherAudio.paused) {
                    otherAudio.pause();
                }
            });
        });

        const info = document.createElement('div');
        info.className = 'recording-info';
        
        const userNameSpan = document.createElement('p');
        userNameSpan.className = 'user-name';
        
        // نمایش اطلاعات مختلف برای فایل‌های آپلود شده
        if (additionalInfo?.uploaded && additionalInfo?.fileName) {
            userNameSpan.innerHTML = `📁 ${additionalInfo.fileName} - ${isRemote ? 'دریافتی از: ' : 'ارسال شده توسط: '}<strong>${userName || userEmail}</strong>`;
        } else {
            userNameSpan.innerHTML = `${isRemote ? 'دریافتی از: ' : 'ضبط شده توسط: '}<strong>${userName || userEmail}</strong>`;
        }
        
        const timestampSpan = document.createElement('small');
        timestampSpan.className = 'timestamp';
        timestampSpan.textContent = this.formatTimestamp(timestamp);
        
        // اضافه کردن اطلاعات مدت زمان اگر موجود باشد
        if (additionalInfo?.duration) {
            const durationSpan = document.createElement('small');
            durationSpan.className = 'duration';
            durationSpan.textContent = ` • ${Math.round(additionalInfo.duration / 1000)}s`;
            timestampSpan.appendChild(durationSpan);
        }

        info.appendChild(userNameSpan);
        info.appendChild(timestampSpan);

        content.appendChild(audio);
        content.appendChild(info);
        
        recordingItem.appendChild(avatar);
        recordingItem.appendChild(content);
        
        // اضافه کردن به ابتدای لیست
        recordingsContainer.insertBefore(recordingItem, recordingsContainer.firstChild);
        
        // انیمیشن ورود
        requestAnimationFrame(() => {
            recordingItem.classList.add('fade-in');
        });
        
        // اسکرول به پایین
        setTimeout(() => {
            recordingsContainer.scrollTop = recordingsContainer.scrollHeight;
        }, 100);
    }

    // نمایش پیام برای رکوردهای خراب شده
    displayCorruptedRecording(recording) {
        const recordingsContainer = document.getElementById('chatMessages');
        if (!recordingsContainer) return;
        
        const recordingItem = document.createElement('div');
        recordingItem.className = 'recording-item corrupted';
        recordingItem.setAttribute('data-voice-id', recording.voiceId);
        
        recordingItem.innerHTML = `
            <div class="recording-content">
                <div class="corrupted-message">
                    <span class="corrupted-icon">⚠️</span>
                    <div class="corrupted-text">
                        <p>فایل صوتی خراب شده</p>
                        <small>ارسال شده در ${this.formatTimestamp(recording.timestamp)} توسط ${recording.userName || recording.userEmail}</small>
                    </div>
                    <button class="remove-corrupted-btn" onclick="this.removeCorruptedRecording('${recording.voiceId}')">
                        حذف
                    </button>
                </div>
            </div>
        `;
        
        recordingsContainer.insertBefore(recordingItem, recordingsContainer.firstChild);
    }
    
    // حذف رکورد خراب شده
    async removeCorruptedRecording(voiceId) {
        try {
            await DatabaseManager.deleteVoice(voiceId);
            const recordingElement = document.querySelector(`[data-voice-id="${voiceId}"]`);
            if (recordingElement) {
                recordingElement.remove();
            }
        } catch (error) {
            console.error('Error removing corrupted recording:', error);
        }
    }

    formatTimestamp(timestamp) {
        const now = Date.now();
        const diff = now - timestamp;
        
        if (diff < 60000) { // کمتر از 1 دقیقه
            return 'همین الان';
        } else if (diff < 3600000) { // کمتر از 1 ساعت
            const minutes = Math.floor(diff / 60000);
            return `${minutes} دقیقه پیش`;
        } else if (diff < 86400000) { // کمتر از 1 روز
            const hours = Math.floor(diff / 3600000);
            return `${hours} ساعت پیش`;
        } else {
            return new Date(timestamp).toLocaleString('fa-IR');
        }
    }

    // متد اصلاح شده برای خروج از اتاق
    leaveRoom() {
        if (confirm('آیا مطمئن هستید که می‌خواهید از اتاق خارج شوید؟')) {
            try {
                // ذخیره اطلاعات اتاق برای صفحه اصلی
                const roomCode = this.currentRoom || localStorage.getItem('currentRoomCode');
                const roomName = localStorage.getItem('currentRoomName');
                
                if (roomCode) {
                    // آماده‌سازی داده‌های اتاق برای ذخیره
                    const roomData = {
                        code: roomCode,
                        name: roomName ? roomName.replace('🏠 ', '') : `اتاق ${roomCode}`,
                        lastVisited: new Date().toISOString(),
                        messageCount: document.querySelectorAll('.recording-item').length || 0
                    };
                    
                    // ذخیره اطلاعات اتاق برای انتقال به صفحه اصلی
                    sessionStorage.setItem('roomToSave', JSON.stringify(roomData));
                    sessionStorage.setItem('fromChatRoom', 'true');
                    
                    console.log('ChatRoom: Room data prepared for saving:', roomData);
                }
                
                // متوقف کردن ضبط اگر در حال انجام است
                if (this.voiceManager && this.voiceManager.isRecording) {
                    this.voiceManager.stopRecording();
                }
                
                // قطع اتصالات
                if (this.connectionManager) {
                    this.connectionManager.disconnect();
                }
                
                // فقط کد اتاق فعلی را حذف کنیم، نه اطلاعات کاربر
                localStorage.removeItem('currentRoomCode');
                localStorage.removeItem('currentRoomName');
                
                // اطمینان از حفظ اطلاعات کاربر
                const userEmail = localStorage.getItem('userEmail');
                const userName = localStorage.getItem('userName');
                const userAvatar = localStorage.getItem('userAvatar');
                
                console.log('Leaving room - User data preserved:', {
                    email: userEmail,
                    name: userName,
                    avatar: !!userAvatar
                });
                
                // انتقال به صفحه اصلی
                this.redirectToHome();
                
            } catch (error) {
                console.error('Error leaving room:', error);
                // در صورت خطا، همچنان به صفحه اصلی برویم
                this.redirectToHome();
            }
        }
    }

    redirectToHome() {
        console.log('ChatRoom: Redirecting to home...');
        
        try {
            // اطمینان از حفظ اطلاعات کاربر قبل از انتقال
            const userEmail = localStorage.getItem('userEmail');
            const userVerified = localStorage.getItem('userVerified');
            
            // تنظیم فلگ برای اطلاع index.html که از chat-room برگشته‌ایم
            sessionStorage.setItem('fromChatRoom', 'true');
            
            // تشخیص محیط Android
            const isAndroid = /android/i.test(navigator.userAgent);
            const isWebView = window.navigator.userAgent.includes('wv');
            
            if (isAndroid || isWebView) {
                // برای Android: انتقال فوری با حفظ history
                window.location.replace('index.html');
            } else {
                // برای سایر پلتفرم‌ها
                window.location.href = 'index.html';
            }
        } catch (error) {
            console.error('ChatRoom: Error redirecting to home:', error);
            // fallback
            window.location = 'index.html';
        }
    }

    updateOnlineUsers(count) {
        const onlineUsersElement = document.getElementById('onlineUsers');
        if (onlineUsersElement) {
            onlineUsersElement.textContent = `کاربران آنلاین: ${count + 1}`;
        }
    }

    // متد برای مدیریت خطاها
    handleError(error, userMessage = 'خطای غیرمنتظره‌ای رخ داد') {
        console.error('ChatRoom error:', error);
        
        const errorDiv = document.createElement('div');
        errorDiv.className = 'error-notification';
        errorDiv.textContent = userMessage;
        errorDiv.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: #dc3545;
            color: white;
            padding: 15px;
            border-radius: 5px;
            z-index: 10000;
            max-width: 300px;
        `;
        
        document.body.appendChild(errorDiv);
        
        setTimeout(() => {
            errorDiv.remove();
        }, 5000);
    }

    // متد جدید برای بررسی وضعیت session کاربر
    static checkUserSession() {
        const userEmail = localStorage.getItem('userEmail');
        const userName = localStorage.getItem('userName');
        
        return {
            isLoggedIn: !!userEmail,
            email: userEmail,
            name: userName
        };
    }
}

// راه‌اندازی خودکار با بهبود Android
document.addEventListener('DOMContentLoaded', async () => {
    try {
        console.log('ChatRoom: DOM loaded, starting initialization...');
        
        // تشخیص محیط
        const isAndroid = /android/i.test(navigator.userAgent);
        const isWebView = window.navigator.userAgent.includes('wv');
        
        if (isAndroid) {
            console.log('ChatRoom: Android environment detected');
            // برای Android کمی صبر می‌کنیم تا localStorage sync شود
            await new Promise(resolve => setTimeout(resolve, 300));
        }
        
        // بررسی ساده session
        const userEmail = localStorage.getItem('userEmail');
        const userVerified = localStorage.getItem('userVerified');
        
        if (!userEmail || userVerified !== 'true') {
            console.warn('ChatRoom: No valid user session found, redirecting to login');
            // تاخیر کوتاه برای Android قبل از redirect
            if (isAndroid) {
                await new Promise(resolve => setTimeout(resolve, 500));
            }
            window.location.href = 'index.html';
            return;
        }
        
        console.log('ChatRoom: User session verified:', userEmail);
        
        const chatRoom = new ChatRoom();
        await chatRoom.initialize();
        
    } catch (error) {
        console.error('ChatRoom: Failed to initialize:', error);
        
        // نمایش خطا
        const container = document.getElementById('recordings');
        if (container) {
            container.innerHTML = `
                <div class="error-state">
                    <div class="error-icon">⚠️</div>
                    <h3>خطا در راه‌اندازی</h3>
                    <p>امکان راه‌اندازی اتاق چت وجود ندارد</p>
                    <div class="error-details">
                        <small>${error.message}</small>
                    </div>
                    <div class="error-actions">
                        <button onclick="window.location.reload()" class="retry-button">تلاش مجدد</button>
                        <button onclick="window.location.href='index.html'" class="home-button">بازگشت به خانه</button>
                    </div>
                </div>
            `;
        }
        
        // توقف 3 ثانیه‌ای و انتقال به صفحه اصلی
        setTimeout(() => {
            window.location.href = 'index.html';
        }, 3000);
    }
});