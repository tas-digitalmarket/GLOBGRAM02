// Load recordings with precise room filtering
// بارگذاری و نمایش پیام‌های صوتی اتاق
async function loadRoomContent() {
    console.log('Loading room content for:', currentRoom);
    const recordings = await db.voices
        .where('roomCode')
        .equals(currentRoom)
        .toArray();
    console.log('Loaded recordings:', recordings.length);
    
    recordings.forEach(recording => {
        console.log('Processing recording:', recording.voiceId);
    });
}
// مدیریت تغییر اتاق و بروزرسانی وضعیت
function changeRoomState(newRoomCode) {
    console.log('Room state change requested:', newRoomCode);
    currentRoom = newRoomCode;
    document.getElementById('currentRoomDisplay').textContent = `اتاق فعلی: ${newRoomCode}`;
    console.log('Room state updated successfully');
}

// بررسی و مدیریت اتصالات فعال در اتاق
function monitorRoomConnections() {
    console.log('Monitoring room connections');
    connections.forEach((conn, index) => {
        console.log(`Connection ${index} status:`, conn.open ? 'active' : 'inactive');
    });
    console.log('Total active connections:', connections.filter(c => c.open).length);
}
class RoomManager {
    constructor() {
        this.activeRooms = new Map();
        this.initializeRoomControls();
    }

    initializeRoomControls() {
        document.addEventListener('DOMContentLoaded', () => {
            this.bindRoomEvents();
            this.loadRecentRooms();
        });
    }

    bindRoomEvents() {
        const createRoomBtn = document.getElementById('createRoom');
        if (createRoomBtn) {
            createRoomBtn.onclick = () => this.createRoom();
        }

        const joinRoomBtn = document.getElementById('joinRoom');
        if (joinRoomBtn) {
            joinRoomBtn.onclick = () => this.joinRoom();
        }

        const joinRoomInput = document.getElementById('joinRoomInput');
        if (joinRoomInput) {
            joinRoomInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    this.joinRoom();
                }
            });

            joinRoomInput.addEventListener('input', (e) => {
                let value = e.target.value.replace(/\D/g, '');
                if (value.length > 6) {
                    value = value.substring(0, 6);
                }
                e.target.value = value;
            });
        }
    }

    createRoom() {
        // بررسی session قبل از ایجاد اتاق
        const userEmail = localStorage.getItem('userEmail');
        const userVerified = localStorage.getItem('userVerified');
        
        console.log('Room Manager: Checking session before room creation:', {
            email: userEmail,
            verified: userVerified
        });
        
        if (!userEmail || userVerified !== 'true') {
            console.warn('Room Manager: Invalid session for room creation');
            this.showError('لطفاً ابتدا وارد حساب کاربری خود شوید');
            
            // هدایت به صفحه auth
            const authContainer = document.getElementById('authContainer');
            const mainContent = document.getElementById('mainContent');
            if (authContainer && mainContent) {
                mainContent.style.display = 'none';
                authContainer.style.display = 'flex';
                
                // Re-bind auth events
                setTimeout(() => {
                    if (window.auth) {
                        window.auth.bindAuthEvents();
                    }
                }, 100);
            }
            return;
        }
        
        const roomCode = Utils.generateRoomCode();
        this.saveToHistory(roomCode, 'created');
        
        const roomCodeDisplay = document.getElementById('roomCode');
        const roomCodeDisplaySection = document.getElementById('roomCodeDisplay');
        
        if (roomCodeDisplay) {
            roomCodeDisplay.textContent = roomCode;
        }
        
        if (roomCodeDisplaySection) {
            roomCodeDisplaySection.style.display = 'block';
        }

        // ذخیره اطلاعات اتاق و کاربر با تایید مجدد
        try {
            localStorage.setItem('currentRoomCode', roomCode);
            localStorage.setItem('roomCreator', userEmail);
            localStorage.setItem('roomCreatedAt', Date.now().toString());
            
            console.log('Room created:', {
                code: roomCode,
                creator: userEmail,
                timestamp: Date.now()
            });
            
            this.showRoomCreatedMessage(roomCode);
            this.copyToClipboard(roomCode);
            
            // انتقال فوری به اتاق چت (بدون تاخیر)
            this.navigateToRoom();
            
        } catch (error) {
            console.error('Error creating room:', error);
            this.showError('خطا در ایجاد اتاق. لطفاً مجدداً تلاش کنید.');
        }
    }

    joinRoom() {
        const joinRoomInput = document.getElementById('joinRoomInput');
        if (!joinRoomInput) return;

        const roomCode = joinRoomInput.value.trim();
        
        if (!this.validateRoomCode(roomCode)) {
            this.showError('لطفاً یک کد 6 رقمی معتبر وارد کنید');
            joinRoomInput.focus();
            return;
        }

        // بررسی session قبل از پیوستن
        const userEmail = localStorage.getItem('userEmail');
        const userVerified = localStorage.getItem('userVerified');
        
        if (!userEmail || userVerified !== 'true') {
            this.showError('لطفاً ابتدا وارد حساب کاربری خود شوید');
            return;
        }

        try {
            this.saveToHistory(roomCode, 'joined');
            localStorage.setItem('currentRoomCode', roomCode);
            localStorage.setItem('roomJoinedAt', Date.now().toString());
            
            console.log('Joining room:', {
                code: roomCode,
                user: userEmail,
                timestamp: Date.now()
            });
            
            this.showJoiningMessage(roomCode);
            
            // انتقال فوری به اتاق چت
            this.navigateToRoom(true);
            
        } catch (error) {
            console.error('Error joining room:', error);
            this.showError('خطا در پیوستن به اتاق. لطفاً مجدداً تلاش کنید.');
        }
    }

    validateRoomCode(roomCode) {
        return roomCode && roomCode.length === 6 && /^\d{6}$/.test(roomCode);
    }

    async copyToClipboard(text) {
        try {
            await navigator.clipboard.writeText(text);
            this.showSuccess('کد اتاق کپی شد! 📋');
        } catch (error) {
            this.fallbackCopyToClipboard(text);
        }
    }

    fallbackCopyToClipboard(text) {
        const textArea = document.createElement('textarea');
        textArea.value = text;
        textArea.style.position = 'fixed';
        textArea.style.left = '-999999px';
        textArea.style.top = '-999999px';
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        
        try {
            document.execCommand('copy');
            this.showSuccess('کد اتاق کپی شد! 📋');
        } catch (error) {
            console.error('Failed to copy text: ', error);
        }
        
        document.body.removeChild(textArea);
    }

    saveToHistory(roomCode, action) {
        const history = JSON.parse(localStorage.getItem('roomHistory') || '[]');
        const entry = {
            roomCode,
            action,
            timestamp: Date.now()
        };
        
        const filteredHistory = history.filter(item => item.roomCode !== roomCode);
        filteredHistory.unshift(entry);
        const limitedHistory = filteredHistory.slice(0, 10);
        
        localStorage.setItem('roomHistory', JSON.stringify(limitedHistory));
    }

    loadRecentRooms() {
        const history = JSON.parse(localStorage.getItem('roomHistory') || '[]');
        const recentRoomsContainer = document.getElementById('recentRooms');
        
        if (!recentRoomsContainer || history.length === 0) return;

        const recentRoomsHTML = history.map(entry => `
            <div class="recent-room-item" onclick="roomManager.joinRecentRoom('${entry.roomCode}')">
                <span class="room-code">${entry.roomCode}</span>
                <span class="room-action">${entry.action === 'created' ? 'ایجاد شده' : 'پیوسته'}</span>
                <span class="room-time">${this.formatTime(entry.timestamp)}</span>
            </div>
        `).join('');

        recentRoomsContainer.innerHTML = `
            <h3>اتاق‌های اخیر</h3>
            ${recentRoomsHTML}
        `;
    }

    joinRecentRoom(roomCode) {
        const joinRoomInput = document.getElementById('joinRoomInput');
        if (joinRoomInput) {
            joinRoomInput.value = roomCode;
        }
        this.joinRoom();
    }

    formatTime(timestamp) {
        const now = Date.now();
        const diff = now - timestamp;
        
        if (diff < 60000) return 'همین الان';
        if (diff < 3600000) return `${Math.floor(diff / 60000)} دقیقه پیش`;
        if (diff < 86400000) return `${Math.floor(diff / 3600000)} ساعت پیش`;
        return new Date(timestamp).toLocaleDateString('fa-IR');
    }

    showRoomCreatedMessage(roomCode) {
        const message = document.createElement('div');
        message.className = 'room-message success';
        message.innerHTML = `
            <h3>✅ اتاق با موفقیت ایجاد شد!</h3>
            <p>کد اتاق: <strong>${roomCode}</strong></p>
            <p>کد به کلیپ‌بورد کپی شد</p>
            <p>در حال انتقال به اتاق چت...</p>
        `;
        this.showMessage(message);
    }

    showJoiningMessage(roomCode) {
        const message = document.createElement('div');
        message.className = 'room-message info';
        message.innerHTML = `
            <h3>🔄 در حال پیوستن به اتاق...</h3>
            <p>کد اتاق: <strong>${roomCode}</strong></p>
        `;
        this.showMessage(message);
    }

    showSuccess(text) {
        const message = document.createElement('div');
        message.className = 'room-message success';
        message.innerHTML = `<p>${text}</p>`;
        this.showMessage(message, 2000);
    }

    showError(text) {
        const message = document.createElement('div');
        message.className = 'room-message error';
        message.innerHTML = `<p>❌ ${text}</p>`;
        this.showMessage(message, 3000);
    }

    showMessage(messageElement, duration = 5000) {
        const existingMessages = document.querySelectorAll('.room-message');
        existingMessages.forEach(msg => msg.remove());
        
        document.body.appendChild(messageElement);
        
        setTimeout(() => {
            if (messageElement.parentNode) {
                messageElement.remove();
            }
        }, duration);
    }

    // متد جدید برای navigation بهبود یافته
    navigateToRoom(isJoining = false) {
        try {
            // تایید نهایی session قبل از انتقال
            const userEmail = localStorage.getItem('userEmail');
            const userVerified = localStorage.getItem('userVerified');
            const roomCode = localStorage.getItem('currentRoomCode');
            
            if (!userEmail || userVerified !== 'true' || !roomCode) {
                console.error('Invalid session or room code before navigation');
                this.showError('خطا در اطلاعات کاربری یا اتاق');
                return;
            }
            
            console.log('Navigating to chat room:', {
                user: userEmail,
                room: roomCode,
                joining: isJoining
            });
            
            // تشخیص محیط Android
            const isAndroid = /android/i.test(navigator.userAgent);
            const isWebView = window.navigator.userAgent.includes('wv');
            
            if (isAndroid || isWebView) {
                // برای Android: انتقال فوری با حفظ history
                if (isJoining) {
                    window.location.replace('chat-room.html?join=true');
                } else {
                    window.location.replace('chat-room.html');
                }
            } else {
                // برای سایر پلتفرم‌ها
                const url = isJoining ? 'chat-room.html?join=true' : 'chat-room.html';
                window.location.href = url;
            }
            
        } catch (error) {
            console.error('Error navigating to room:', error);
            this.showError('خطا در انتقال به اتاق چت');
        }
    }
}

// ایجاد instance global
const roomManager = new RoomManager();
window.RoomManager = RoomManager;
window.roomManager = roomManager;
