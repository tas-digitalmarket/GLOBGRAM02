// مدیریت دیتابیس مشترک
const db = new Dexie('voiceApp');
db.version(1).stores({
    voices: '++id, voiceId, blob, timestamp, roomCode, userEmail, userAvatar, userName, fileName, uploaded, duration, platform',
    users: '++id, email, verifyCode, verified, timestamp, userName, avatar'
});

// اطمینان از اینکه دیتابیس به صورت global در دسترس است
window.db = db;

// اطمینان از باز بودن دیتابیس
db.open().catch(err => {
    console.error("Failed to open database:", err);
});

// تعریف و export کلاس DatabaseManager
class DatabaseManager {
    static async saveVoice(voiceData) {
        try {
            // Validate required fields
            if (!voiceData || !voiceData.voiceId || !voiceData.blob) {
                throw new Error('Voice data is incomplete');
            }

            // اطمینان از اینکه blob در فرمت قابل ذخیره‌سازی است
            let blobToStore = voiceData.blob;
            
            // اگر blob مناسب ذخیره‌سازی نیست، آن را با نوع صحیح ذخیره کنیم
            if (!(blobToStore instanceof Blob)) {
                console.warn('Blob is not a valid Blob instance, converting...');
                try {
                    if (blobToStore instanceof ArrayBuffer) {
                        blobToStore = new Blob([blobToStore], { type: 'audio/webm' });
                    } else {
                        throw new Error('Invalid blob format');
                    }
                } catch (e) {
                    console.error('Failed to convert blob:', e);
                    throw new Error('Invalid blob data: ' + e.message);
                }
            }

            // Ensure all required fields have default values
            const completeVoiceData = {
                voiceId: voiceData.voiceId,
                blob: blobToStore,
                timestamp: voiceData.timestamp || Date.now(),
                roomCode: voiceData.roomCode || 'unknown',
                userEmail: voiceData.userEmail || 'guest@example.com',
                userAvatar: voiceData.userAvatar || '',
                userName: voiceData.userName || voiceData.userEmail || 'کاربر',
                fileName: voiceData.fileName || '',
                uploaded: voiceData.uploaded || false,
                duration: voiceData.duration || 0,
                platform: voiceData.platform || 'unknown'
            };

            console.log('Saving voice to database:', completeVoiceData.voiceId, completeVoiceData.roomCode);
            const result = await db.voices.add(completeVoiceData);
            console.log('Voice saved successfully with ID:', result, 'voiceId:', completeVoiceData.voiceId);
            return result;
        } catch (error) {
            console.error('Error saving voice:', error);
            console.error('Voice data that failed to save:', voiceData ? voiceData.voiceId : 'unknown');
            
            // Log error details for debugging
            if (window.errorHandler) {
                window.errorHandler.logError('Database Save Voice Error', error, { voiceData });
            }
            
            throw error;
        }
    }

    static async getVoicesByRoom(roomCode) {
        try {
            console.log('Getting voices for room:', roomCode);
            
            // اطمینان از اینکه دیتابیس باز است
            if (!db.isOpen()) {
                await db.open();
                console.log('Database opened for getVoicesByRoom');
            }
            
            const voices = await db.voices
                .where('roomCode')
                .equals(roomCode)
                .reverse()
                .toArray();
            
            console.log('Found voices in database:', voices.length);
            
            // اطمینان از اینکه Blob ها معتبر هستند
            const validVoices = voices.filter(voice => {
                if (!voice.blob || !(voice.blob instanceof Blob)) {
                    console.warn('Invalid blob found for voice:', voice.voiceId);
                    return false;
                }
                return true;
            });
            
            console.log('Valid voices with blob:', validVoices.length);
            return validVoices;
        } catch (error) {
            console.error('Error loading voices for room', roomCode, ':', error);
            return [];
        }
    }

    // متد جدید برای دریافت تمام پیام‌های صوتی
    static async getAllVoices() {
        try {
            return await db.voices.toArray();
        } catch (error) {
            console.error('Error loading all voices:', error);
            return [];
        }
    }

    // متد جدید برای پاک کردن تمام پیام‌های صوتی
    static async clearAllVoices() {
        try {
            return await db.voices.clear();
        } catch (error) {
            console.error('Error clearing voices:', error);
            throw error;
        }
    }

    // متد جدید برای پاک کردن پیام‌های یک اتاق خاص
    static async clearVoicesByRoom(roomCode) {
        try {
            return await db.voices.where('roomCode').equals(roomCode).delete();
        } catch (error) {
            console.error('Error clearing room voices:', error);
            throw error;
        }
    }

    static async saveUser(userData) {
        try {
            return await db.users.put(userData);
        } catch (error) {
            console.error('Error saving user:', error);
            throw error;
        }
    }

    static async getUser(email) {
        try {
            return await db.users.where('email').equals(email).first();
        } catch (error) {
            console.error('Error getting user:', error);
            return null;
        }
    }

    // متد جدید برای پاک کردن تمام کاربران
    static async clearAllUsers() {
        try {
            return await db.users.clear();
        } catch (error) {
            console.error('Error clearing users:', error);
            throw error;
        }
    }

    // متد جدید برای دریافت آمار دیتابیس
    static async getDatabaseStats() {
        try {
            const voiceCount = await db.voices.count();
            const userCount = await db.users.count();
            
            return {
                voices: voiceCount,
                users: userCount,
                totalRecords: voiceCount + userCount
            };
        } catch (error) {
            console.error('Error getting database stats:', error);
            return { voices: 0, users: 0, totalRecords: 0 };
        }
    }

    // متد جدید برای پاک کردن کامل دیتابیس
    static async clearDatabase() {
        try {
            await db.voices.clear();
            await db.users.clear();
            console.log('Database completely cleared');
        } catch (error) {
            console.error('Error clearing database:', error);
            throw error;
        }
    }

    // حذف پیام صوتی مشخص
    static async deleteVoice(voiceId) {
        try {
            return await db.voices.where('voiceId').equals(voiceId).delete();
        } catch (error) {
            console.error('Error deleting voice:', error);
            throw error;
        }
    }

    // دریافت پیام صوتی مشخص
    static async getVoice(voiceId) {
        try {
            return await db.voices.where('voiceId').equals(voiceId).first();
        } catch (error) {
            console.error('Error getting voice:', error);
            return null;
        }
    }
}

window.db = db;
window.DatabaseManager = DatabaseManager;
