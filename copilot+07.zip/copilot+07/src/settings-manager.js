class SettingsManager {
    constructor() {
        this.currentPanel = null;
        this.initializeSettings();
        this.bindEvents();
    }

    initializeSettings() {
        document.addEventListener('DOMContentLoaded', () => {
            this.loadAllSettings();
            this.hideAllPanels();
        });
    }

    hideAllPanels() {
        const panels = [
            'accountSettingsPanel',
            'chatSettingsPanel', 
            'privacySettingsPanel',
            'clearCachePanel'
        ];
        
        panels.forEach(panelId => {
            const panel = document.getElementById(panelId);
            if (panel) {
                panel.style.display = 'none';
                panel.classList.remove('active');
            }
        });
    }

    loadAllSettings() {
        // بارگذاری نام کاربری
        const userName = localStorage.getItem('userName') || '';
        const userNameInput = document.getElementById('userNameInput');
        if (userNameInput) {
            userNameInput.value = userName;
        }

        // بارگذاری سایر تنظیمات
        const savedSettings = JSON.parse(localStorage.getItem('userSettings') || '{}');
        
        const displayNameInput = document.getElementById('displayNameInput');
        if (displayNameInput) {
            displayNameInput.value = savedSettings.displayName || userName;
        }

        const themeSelect = document.getElementById('themeSelect');
        if (themeSelect) {
            themeSelect.value = savedSettings.theme || 'light';
        }

        const audioQuality = document.getElementById('audioQuality');
        if (audioQuality) {
            audioQuality.value = savedSettings.audioQuality || 'high';
        }
        
        // اعمال تم بارگذاری شده
        this.applyTheme(savedSettings.theme || 'light');
    }

    bindEvents() {
        // ذخیره نام کاربری
        const saveUserNameBtn = document.getElementById('saveUserNameBtn');
        if (saveUserNameBtn) {
            saveUserNameBtn.onclick = () => this.saveUserName();
        }

        // تنظیمات حساب کاربری
        const accountSettings = document.getElementById('accountSettings');
        if (accountSettings) {
            accountSettings.onclick = () => this.showAccountSettings();
        }

        // تنظیمات چت
        const chatSettings = document.getElementById('chatSettings');
        if (chatSettings) {
            chatSettings.onclick = () => this.showChatSettings();
        }

        // تنظیمات حریم خصوصی
        const privacySettings = document.getElementById('privacySettings');
        if (privacySettings) {
            privacySettings.onclick = () => this.showPrivacySettings();
        }

        // تنظیمات پاک کردن کش
        const clearCacheSettings = document.getElementById('clearCacheSettings');
        if (clearCacheSettings) {
            clearCacheSettings.onclick = () => this.showClearCacheSettings();
        }

        // دکمه‌های بازگشت
        document.querySelectorAll('.back-button').forEach(btn => {
            btn.onclick = () => this.goBack();
        });

        // بازگشت به چت اصلی
        const backToMainChat = document.getElementById('backToMainChat');
        if (backToMainChat) {
            backToMainChat.onclick = () => this.backToMainChat();
        }

        // خروج از حساب
        const logoutButton = document.getElementById('logoutButton');
        if (logoutButton) {
            logoutButton.onclick = () => this.logout();
        }

        // ذخیره تنظیمات عمومی
        const saveSettings = document.getElementById('saveSettings');
        if (saveSettings) {
            saveSettings.onclick = () => this.saveGeneralSettings();
        }
        
        // تغییر فوری تم
        const themeSelect = document.getElementById('themeSelect');
        if (themeSelect) {
            themeSelect.onchange = (e) => {
                this.applyTheme(e.target.value);
                console.log('Theme changed to:', e.target.value);
            };
        }

        // دکمه‌های پاک کردن کش
        this.bindClearCacheEvents();
    }

    bindClearCacheEvents() {
        const clearSelectedBtn = document.getElementById('clearSelectedBtn');
        if (clearSelectedBtn) {
            clearSelectedBtn.onclick = () => this.clearSelectedData();
        }

        const clearAllBtn = document.getElementById('clearAllBtn');
        if (clearAllBtn) {
            clearAllBtn.onclick = () => this.clearAllData();
        }
    }

    showClearCacheSettings() {
        this.showPanel('clearCachePanel');
        // استفاده از then به جای await
        this.loadCacheStats().catch(error => {
            console.error('Error loading cache stats:', error);
        });
    }

    async loadCacheStats() {
        try {
            // محاسبه تعداد پیام‌های صوتی
            const voices = await DatabaseManager.getAllVoices();
            const voiceCount = voices.length;
            
            // محاسبه حجم کل
            let totalSize = 0;
            voices.forEach(voice => {
                if (voice.blob && voice.blob.size) {
                    totalSize += voice.blob.size;
                }
            });

            // محاسبه حجم localStorage
            let localStorageSize = 0;
            for (let key in localStorage) {
                if (localStorage.hasOwnProperty(key)) {
                    localStorageSize += localStorage[key].length;
                }
            }

            // آخرین بروزرسانی
            const lastUpdate = localStorage.getItem('lastUpdate') || 'نامشخص';

            // بروزرسانی UI
            const voiceCountEl = document.getElementById('voiceCount');
            const totalSizeEl = document.getElementById('totalSize');
            const lastUpdateEl = document.getElementById('lastUpdate');

            if (voiceCountEl) voiceCountEl.textContent = voiceCount + ' پیام';
            if (totalSizeEl) totalSizeEl.textContent = this.formatBytes(totalSize + localStorageSize);
            if (lastUpdateEl) lastUpdateEl.textContent = lastUpdate;

        } catch (error) {
            console.error('Error loading cache stats:', error);
            // نمایش مقادیر پیش‌فرض در صورت خطا
            const voiceCountEl = document.getElementById('voiceCount');
            const totalSizeEl = document.getElementById('totalSize');
            const lastUpdateEl = document.getElementById('lastUpdate');

            if (voiceCountEl) voiceCountEl.textContent = 'خطا در بارگذاری';
            if (totalSizeEl) totalSizeEl.textContent = 'خطا در بارگذاری';
            if (lastUpdateEl) lastUpdateEl.textContent = 'خطا در بارگذاری';
        }
    }

    formatBytes(bytes) {
        if (bytes === 0) return '0 بایت';
        const k = 1024;
        const sizes = ['بایت', 'کیلوبایت', 'مگابایت', 'گیگابایت'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    async clearSelectedData() {
        const clearVoices = document.getElementById('clearVoices')?.checked;
        const clearHistory = document.getElementById('clearHistory')?.checked;
        const clearSettings = document.getElementById('clearSettings')?.checked;
        const clearProfile = document.getElementById('clearProfile')?.checked;

        if (!clearVoices && !clearHistory && !clearSettings && !clearProfile) {
            alert('لطفا حداقل یک مورد را انتخاب کنید');
            return;
        }

        const confirmMessage = `آیا مطمئن هستید که می‌خواهید موارد انتخابی را پاک کنید؟\n\n` +
            `${clearVoices ? '• پیام‌های صوتی\n' : ''}` +
            `${clearHistory ? '• تاریخچه اتاق‌ها\n' : ''}` +
            `${clearSettings ? '• تنظیمات شخصی\n' : ''}` +
            `${clearProfile ? '• اطلاعات پروفایل\n' : ''}`;

        if (!confirm(confirmMessage)) return;

        try {
            const clearBtn = document.getElementById('clearSelectedBtn');
            if (clearBtn) {
                clearBtn.disabled = true;
                clearBtn.textContent = '🔄 در حال پاک کردن...';
            }

            // پاک کردن پیام‌های صوتی
            if (clearVoices) {
                await DatabaseManager.clearAllVoices();
                console.log('Voice messages cleared');
            }

            // پاک کردن تاریخچه اتاق‌ها
            if (clearHistory) {
                localStorage.removeItem('roomHistory');
                localStorage.removeItem('currentRoomCode');
                console.log('Room history cleared');
            }

            // پاک کردن تنظیمات
            if (clearSettings) {
                localStorage.removeItem('userSettings');
                console.log('Settings cleared');
            }

            // پاک کردن اطلاعات پروفایل
            if (clearProfile) {
                localStorage.removeItem('userAvatar');
                localStorage.removeItem('userName');
                console.log('Profile data cleared');
            }

            // بروزرسانی آمار
            await this.loadCacheStats();

            alert('✅ داده‌های انتخابی با موفقیت پاک شدند');

        } catch (error) {
            console.error('Error clearing selected data:', error);
            alert('❌ خطا در پاک کردن داده‌ها');
        } finally {
            const clearBtn = document.getElementById('clearSelectedBtn');
            if (clearBtn) {
                clearBtn.disabled = false;
                clearBtn.textContent = '🗑️ پاک کردن موارد انتخابی';
            }
        }
    }

    async clearAllData() {
        const confirmMessage = `⚠️ هشدار مهم!\n\nتمام داده‌های اپلیکیشن حذف خواهد شد:\n\n• تمام پیام‌های صوتی\n• اطلاعات حساب کاربری\n• تنظیمات شخصی\n• تاریخچه اتاق‌ها\n• تصویر پروفایل\n\nآیا مطمئن هستید؟`;

        if (!confirm(confirmMessage)) return;

        const finalConfirm = confirm('آخرین هشدار!\n\nاین عمل غیرقابل بازگشت است. آیا واقعاً می‌خواهید ادامه دهید؟');
        if (!finalConfirm) return;

        try {
            const clearBtn = document.getElementById('clearAllBtn');
            if (clearBtn) {
                clearBtn.disabled = true;
                clearBtn.textContent = '🔄 در حال پاک کردن همه چیز...';
            }

            // پاک کردن دیتابیس
            if (window.db) {
                await window.db.delete();
                console.log('Database cleared');
            }

            // پاک کردن localStorage
            localStorage.clear();
            console.log('LocalStorage cleared');

            // پاک کردن sessionStorage
            sessionStorage.clear();
            console.log('SessionStorage cleared');

            // پاک کردن کش مرورگر (اگر امکان دارد)
            if ('caches' in window) {
                try {
                    const cacheNames = await caches.keys();
                    await Promise.all(
                        cacheNames.map(cacheName => caches.delete(cacheName))
                    );
                    console.log('Browser cache cleared');
                } catch (cacheError) {
                    console.warn('Could not clear browser cache:', cacheError);
                }
            }

            // پاک کردن IndexedDB
            if (window.indexedDB) {
                try {
                    const databases = await indexedDB.databases();
                    await Promise.all(
                        databases.map(db => {
                            return new Promise((resolve, reject) => {
                                const deleteReq = indexedDB.deleteDatabase(db.name);
                                deleteReq.onsuccess = () => resolve();
                                deleteReq.onerror = () => reject(deleteReq.error);
                                deleteReq.onblocked = () => {
                                    console.warn('Database deletion blocked:', db.name);
                                    resolve(); // ادامه دادن حتی اگر مسدود شود
                                };
                            });
                        })
                    );
                    console.log('IndexedDB cleared');
                } catch (error) {
                    console.warn('Could not clear IndexedDB:', error);
                }
            }

            alert('✅ تمام داده‌ها با موفقیت پاک شدند!\n\nصفحه بازنشانی می‌شود...');
            
            // بازنشانی صفحه
            setTimeout(() => {
                window.location.href = 'index.html';
                window.location.reload();
            }, 1000);

        } catch (error) {
            console.error('Error clearing all data:', error);
            alert('❌ خطا در پاک کردن داده‌ها: ' + error.message);
        } finally {
            const clearBtn = document.getElementById('clearAllBtn');
            if (clearBtn) {
                clearBtn.disabled = false;
                clearBtn.textContent = '💥 پاک کردن همه چیز';
            }
        }
    }

    saveUserName() {
        const userNameInput = document.getElementById('userNameInput');
        if (!userNameInput) return;

        const newUserName = userNameInput.value.trim();
        
        if (!newUserName) {
            alert('لطفا یک نام معتبر وارد کنید');
            return;
        }

        localStorage.setItem('userName', newUserName);
        localStorage.setItem('lastUpdate', new Date().toLocaleString('fa-IR'));
        
        // بروزرسانی نام در پروفایل
        const profileName = document.getElementById('profileName');
        if (profileName) {
            profileName.textContent = newUserName;
        }

        alert('نام کاربری با موفقیت تغییر کرد');
    }

    saveGeneralSettings() {
        const settings = {
            displayName: document.getElementById('displayNameInput')?.value || '',
            theme: document.getElementById('themeSelect')?.value || 'light',
            audioQuality: document.getElementById('audioQuality')?.value || 'high',
            lastUpdate: new Date().toLocaleString('fa-IR')
        };

        localStorage.setItem('userSettings', JSON.stringify(settings));
        localStorage.setItem('lastUpdate', settings.lastUpdate);
        
        // اعمال تم
        this.applyTheme(settings.theme);
        
        alert('تنظیمات با موفقیت ذخیره شد');
    }

    applyTheme(theme) {
        // تغییر data-theme attribute برای هماهنگی با CSS
        document.documentElement.setAttribute('data-theme', theme || 'light');
        
        // ذخیره تم در localStorage
        const settings = JSON.parse(localStorage.getItem('userSettings') || '{}');
        settings.theme = theme || 'light';
        localStorage.setItem('userSettings', JSON.stringify(settings));
        
        console.log('Theme applied:', theme);
    }

    showAccountSettings() {
        this.showPanel('accountSettingsPanel');
    }

    showChatSettings() {
        this.showPanel('chatSettingsPanel');
    }

    showPrivacySettings() {
        this.showPanel('privacySettingsPanel');
    }

    showPanel(panelId) {
        // مخفی کردن پنل فعلی
        this.hideCurrentPanel();
        
        const panel = document.getElementById(panelId);
        const mainContent = document.getElementById('mainContent');
        const profileSection = document.getElementById('profileSection');

        if (panel) {
            if (mainContent) mainContent.style.display = 'none';
            if (profileSection) profileSection.style.display = 'none';
            
            panel.style.display = 'flex';
            panel.style.transform = 'translateX(0)';
            panel.classList.add('active');
            
            this.currentPanel = panel;
        }
    }

    hideCurrentPanel() {
        if (this.currentPanel) {
            this.currentPanel.style.transform = 'translateX(100%)';
            this.currentPanel.classList.remove('active');
            
            setTimeout(() => {
                if (this.currentPanel) {
                    this.currentPanel.style.display = 'none';
                }
            }, 300);
        }
    }

    goBack() {
        this.hideCurrentPanel();
        
        const profileSection = document.getElementById('profileSection');
        if (profileSection) {
            profileSection.style.display = 'flex';
        }
        
        this.currentPanel = null;
    }

    backToMainChat() {
        this.hideCurrentPanel();
        
        const profileSection = document.getElementById('profileSection');
        const mainContent = document.getElementById('mainContent');
        
        if (profileSection) profileSection.style.display = 'none';
        if (mainContent) mainContent.style.display = 'block';
        
        this.currentPanel = null;
    }

    logout() {
        if (confirm('آیا مطمئن هستید که می‌خواهید خارج شوید؟')) {
            console.log('SettingsManager: User confirmed logout');
            
            if (window.Auth && typeof window.Auth.logout === 'function') {
                // استفاده از متد logout کلاس Auth
                window.Auth.logout(true); // force logout
            } else {
                // fallback logout
                console.log('SettingsManager: Using fallback logout');
                localStorage.removeItem('userEmail');
                localStorage.removeItem('userName');
                localStorage.removeItem('userAvatar');
                localStorage.removeItem('userVerified');
                localStorage.removeItem('loginTimestamp');
                localStorage.removeItem('currentRoomCode');
                window.location.href = 'index.html';
            }
        }
    }

    // تنظیمات پیشرفته
    exportData() {
        try {
            const userData = {
                email: localStorage.getItem('userEmail'),
                userName: localStorage.getItem('userName'),
                settings: JSON.parse(localStorage.getItem('userSettings') || '{}'),
                exportDate: new Date().toISOString()
            };

            const dataStr = JSON.stringify(userData, null, 2);
            const dataBlob = new Blob([dataStr], { type: 'application/json' });
            
            const link = document.createElement('a');
            link.href = URL.createObjectURL(dataBlob);
            link.download = `globgram-data-${Date.now()}.json`;
            link.click();
            
            // پاک کردن URL بعد از دانلود
            setTimeout(() => {
                URL.revokeObjectURL(link.href);
            }, 100);
            
        } catch (error) {
            console.error('Error exporting data:', error);
            alert('خطا در صادر کردن داده‌ها');
        }
    }
}

window.SettingsManager = SettingsManager;

// راه‌اندازی خودکار
document.addEventListener('DOMContentLoaded', () => {
    new SettingsManager();
});