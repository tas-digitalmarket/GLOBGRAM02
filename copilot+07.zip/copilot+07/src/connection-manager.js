class ConnectionManager {
    constructor() {
        this.peer = null;
        this.connections = new Map();
        this.currentRoom = null;
        this.isRoomCreator = false;
        this.reconnectAttempts = 0;
        this.maxReconnectAttempts = 3;
        this.connectionTimeout = 30000; // 30 seconds
        this.becomingCreator = false; // flag برای جلوگیری از تداخل
        this.hasTriedBecomeCreator = false; // flag برای جلوگیری از تلاش مکرر
        this.processedSyncMessages = new Set(); // برای جلوگیری از sync تکراری
        this.lastConnectionAttempt = 0; // برای circuit breaker
        this.connectionCooldown = 5000; // 5 seconds cooldown بین اتصالات
    }

    async initializePeer(roomCode, isCreator = false) {
        this.currentRoom = roomCode;
        this.isRoomCreator = isCreator;
        
        // نمایش وضعیت در حال اتصال
        this.updateConnectionStatus('connecting');
        
        // تولید ID یکتا برای جلوگیری از تداخل
        const timestamp = Date.now();
        const randomSuffix = Math.random().toString(36).substring(2, 10);
        
        let peerId;
        if (isCreator) {
            // Creator فقط در اولین اتصال از room code ساده استفاده می‌کند
            // در تمام reconnection ها از ID یکتا استفاده می‌کند
            if (this.reconnectAttempts === 0 && !this.hasTriedBecomeCreator) {
                peerId = roomCode;
            } else {
                // در reconnection یا بعد از become creator، از ID کاملاً یکتا استفاده کن
                peerId = `creator-${roomCode}-${timestamp}-${randomSuffix}`;
            }
        } else {
            // Member همیشه از ID کاملاً یکتا استفاده می‌کند
            peerId = `member-${roomCode}-${timestamp}-${randomSuffix}`;
        }
        
        console.log('Initializing peer with unique ID:', peerId, 'for room:', roomCode, 'attempt:', this.reconnectAttempts);
        
        try {
            // بستن اتصال قبلی اگر وجود دارد
            if (this.peer && !this.peer.destroyed) {
                console.log('Destroying previous peer connection...');
                this.peer.destroy();
                this.connections.clear();
                // کمی صبر کنیم تا cleanup کامل شود
                await new Promise(resolve => setTimeout(resolve, 1000));
            }
            
            // پاک کردن تمام event listeners قبلی
            this.connections.clear();
            
            // ساخت Peer جدید با تنظیمات بهینه
            const peerOptions = {
                config: { 
                    iceServers: CONFIG.STUN_SERVERS,
                    sdpSemantics: 'unified-plan',
                    iceCandidatePoolSize: 10
                },
                debug: 1 // کاهش debug level
            };

            // تنظیم host فقط برای محیط‌های HTTP/HTTPS
            if (window.location.protocol === 'http:' || window.location.protocol === 'https:') {
                peerOptions.host = window.location.hostname || 'localhost';
                peerOptions.secure = window.location.protocol === 'https:';
                peerOptions.port = window.location.protocol === 'https:' ? 443 : 80;
            }

            this.peer = new Peer(peerId, peerOptions);

            this.peer.on('open', (id) => {
                console.log('✅ Peer connection established with unique ID:', id);
                this.reconnectAttempts = 0; // reset attempts on successful connection
                this.updateConnectionStatus('connected');
                
                // اگر creator نیستیم، سعی می‌کنیم به creator متصل شویم
                if (!this.isRoomCreator) {
                    this.findAndConnectToCreator(roomCode);
                }
                
                // ذخیره roomCode در localStorage برای سایر بخش‌ها
                localStorage.setItem('currentRoomCode', roomCode);
                
                // اعلام موفقیت در کنسول
                console.log('✅ اتصال برقرار شد - Room:', roomCode);
            });

            this.peer.on('connection', (conn) => {
                console.log('📞 Incoming connection from:', conn.peer);
                this.setupConnection(conn);
            });

            this.peer.on('error', (error) => {
                console.error('Peer error:', error);
                this.handleConnectionError(error);
            });

            // بهبود reconnection logic با exponential backoff
            this.peer.on('disconnected', () => {
                console.log('Peer disconnected');
                if (this.reconnectAttempts < this.maxReconnectAttempts && !this.becomingCreator) {
                    console.log(`Attempting reconnection... (${this.reconnectAttempts + 1}/${this.maxReconnectAttempts})`);
                    this.updateConnectionStatus('connecting');
                    
                    // Exponential backoff: 2s, 6s, 18s
                    const delay = 2000 * Math.pow(3, this.reconnectAttempts);
                    
                    setTimeout(() => {
                        this.reconnectAttempts++;
                        // تولید ID جدید برای reconnection
                        this.initializePeer(this.currentRoom, this.isRoomCreator);
                    }, delay);
                } else {
                    console.log('Max reconnection attempts reached or becoming creator');
                    this.updateConnectionStatus('failed');
                }
            });
            
            this.peer.on('close', () => {
                console.log('Peer connection closed');
                this.updateConnectionStatus('disconnected');
                this.connections.clear();
            });

        } catch (error) {
            console.error('Failed to initialize peer:', error);
            this.handleConnectionError(error);
        }
    }

    // جستجو و اتصال به creator
    async findAndConnectToCreator(roomCode) {
        // اگر در حال تبدیل شدن به creator هستیم، منتظر بمانیم
        if (this.becomingCreator) {
            console.log('Already becoming creator, skipping connection attempt');
            return;
        }
        
        // Circuit breaker: جلوگیری از اتصالات مکرر
        const now = Date.now();
        if (now - this.lastConnectionAttempt < this.connectionCooldown) {
            const remainingCooldown = this.connectionCooldown - (now - this.lastConnectionAttempt);
            console.log(`Connection cooldown active, waiting ${remainingCooldown}ms`);
            setTimeout(() => this.findAndConnectToCreator(roomCode), remainingCooldown);
            return;
        }
        
        this.lastConnectionAttempt = now;
        
        // Creator همیشه room code ساده را استفاده می‌کند
        const creatorId = roomCode;
        
        try {
            console.log(`Attempting to connect to room creator with ID: ${creatorId}`);
            
            // تاخیر کوتاه برای اطمینان از آماده بودن peer
            await new Promise(resolve => setTimeout(resolve, 500));
            
            // بررسی اینکه آیا creator ID در دسترس است
            if (this.peer.id === creatorId) {
                console.log('We are already the creator, no need to connect');
                return;
            }
            
            // اتصال به creator
            const conn = this.peer.connect(creatorId, {
                reliable: true,
                metadata: {
                    type: 'room-join',
                    roomCode: roomCode,
                    timestamp: Date.now(),
                    joinerPeerId: this.peer.id
                }
            });

            if (conn) {
                let connectionEstablished = false;
                
                // تنظیم timeout برای اتصال
                const connectionTimeout = setTimeout(() => {
                    if (!connectionEstablished && !this.becomingCreator) {
                        console.log('Connection to creator timed out, becoming creator myself');
                        conn.close();
                        this.becomeRoomCreator();
                    }
                }, 10000); // 10 seconds timeout (افزایش زمان)
                
                conn.on('open', () => {
                    connectionEstablished = true;
                    clearTimeout(connectionTimeout);
                    console.log('✅ Successfully connected to room creator');
                    // Reset cooldown on successful connection
                    this.lastConnectionAttempt = 0;
                });
                
                conn.on('error', (error) => {
                    connectionEstablished = true;
                    clearTimeout(connectionTimeout);
                    if (!this.becomingCreator) {
                        console.log('❌ Failed to connect to creator, becoming creator myself:', error.message);
                        // کمی صبر قبل از تبدیل شدن به creator
                        setTimeout(() => {
                            if (!this.becomingCreator) {
                                this.becomeRoomCreator();
                            }
                        }, 2000);
                    }
                });
                
                this.setupConnection(conn);
                console.log('Connection request sent to room creator');
                
            } else {
                if (!this.becomingCreator) {
                    console.log('Failed to create connection to room creator, becoming creator');
                    setTimeout(() => {
                        if (!this.becomingCreator) {
                            this.becomeRoomCreator();
                        }
                    }, 2000);
                }
            }
            
        } catch (error) {
            console.error('Error connecting to room creator:', error);
            if (!this.becomingCreator) {
                console.log('Attempting to become room creator due to connection error');
                setTimeout(() => {
                    if (!this.becomingCreator) {
                        this.becomeRoomCreator();
                    }
                }, 2000);
            }
        }
    }

    connectToRoom(roomCode) {
        try {
            console.log('Connecting to room:', roomCode);
            
            // اگر به همین اتاق متصل هستیم، نیازی به اتصال مجدد نیست
            const existingConn = Array.from(this.connections.values())
                .find(conn => conn.peer === roomCode || conn.peer.includes(roomCode));
                
            if (existingConn && existingConn.open) {
                console.log('Already connected to this room');
                return;
            }

            // اتصال مستقیم به room creator (که از room code استفاده می‌کند)
            const targetPeerId = roomCode;
            console.log('Attempting to connect to room creator:', targetPeerId);
            
            const conn = this.peer.connect(targetPeerId, {
                reliable: true,
                metadata: {
                    type: 'room-join',
                    roomCode: roomCode,
                    timestamp: Date.now(),
                    joinerPeerId: this.peer.id
                }
            });

            if (conn) {
                let connectionEstablished = false;
                
                // تنظیم timeout برای اتصال
                const connectionTimeout = setTimeout(() => {
                    if (!connectionEstablished) {
                        console.log('Connection to room creator timed out, becoming creator myself');
                        conn.close();
                        this.becomeRoomCreator();
                    }
                }, 8000); // 8 seconds timeout
                
                conn.on('open', () => {
                    connectionEstablished = true;
                    clearTimeout(connectionTimeout);
                    console.log('✅ Successfully connected to room creator');
                });
                
                conn.on('error', (error) => {
                    connectionEstablished = true;
                    clearTimeout(connectionTimeout);
                    console.log('❌ Failed to connect to creator, becoming creator myself:', error.message);
                    this.becomeRoomCreator();
                });
                
                this.setupConnection(conn);
                console.log('Connection request sent to room creator:', targetPeerId);
            } else {
                console.log('Failed to create connection, becoming creator');
                this.becomeRoomCreator();
            }

        } catch (error) {
            console.error('Error connecting to room:', error);
            this.handleConnectionError(error);
        }
    }

    setupConnection(conn) {
        console.log('Setting up connection with:', conn.peer);
        
        // بررسی اتصال تکراری
        if (this.connections.has(conn.peer)) {
            console.log('Connection already exists for:', conn.peer);
            const existingConn = this.connections.get(conn.peer);
            if (existingConn.open) {
                console.log('Existing connection is still open, closing new one');
                conn.close();
                return;
            } else {
                console.log('Existing connection is closed, replacing with new one');
                this.connections.delete(conn.peer);
            }
        }
        
        // تنظیم timeout برای اتصال
        const connectionTimeout = setTimeout(() => {
            if (!conn.open) {
                console.log('Connection timeout for:', conn.peer);
                conn.close();
            }
        }, this.connectionTimeout);

        conn.on('open', () => {
            clearTimeout(connectionTimeout);
            console.log('✅ Connection established with:', conn.peer);
            this.connections.set(conn.peer, conn);
            this.updateOnlineCount();
            
            // همگام‌سازی پیام‌های موجود فقط برای اتصالات جدید
            if (this.isRoomCreator && !conn.syncCompleted) {
                this.syncExistingMessages(conn);
            }
        });

        conn.on('data', (data) => {
            console.log('📨 Data received from:', conn.peer, 'Type:', data.type);
            this.handleIncomingData(data, conn);
        });

        conn.on('close', () => {
            console.log('❌ Connection closed with:', conn.peer);
            this.connections.delete(conn.peer);
            this.updateOnlineCount();
        });

        conn.on('error', (error) => {
            console.error('Connection error with', conn.peer, ':', error);
            clearTimeout(connectionTimeout);
            this.connections.delete(conn.peer);
            this.updateOnlineCount();
        });
    }

    async syncExistingMessages(conn) {
        try {
            // جلوگیری از sync تکراری برای همین connection
            if (conn.syncCompleted) {
                console.log('Sync already completed for this connection');
                return;
            }
            
            if (typeof DatabaseManager !== 'undefined' && DatabaseManager.getVoicesByRoom) {
                const messages = await DatabaseManager.getVoicesByRoom(this.currentRoom);
                
                if (messages.length > 0) {
                    console.log(`Syncing ${messages.length} existing messages`);
                    
                    // ارسال پیام‌های موجود به کاربر جدید
                    for (const message of messages.slice(-10)) { // فقط 10 پیام آخر
                        const syncData = {
                            type: 'sync-message',
                            voiceId: message.voiceId,
                            timestamp: message.timestamp,
                            userEmail: message.userEmail,
                            userName: message.userName,
                            userAvatar: message.userAvatar,
                            audioData: Array.from(new Uint8Array(await message.blob.arrayBuffer())),
                            isSync: true // flag برای تشخیص sync message
                        };
                        
                        conn.send(syncData);
                        
                        // کمی صبر بین هر پیام برای جلوگیری از spam
                        await new Promise(resolve => setTimeout(resolve, 100));
                    }
                    
                    // علامت گذاری که sync کامل شده
                    conn.syncCompleted = true;
                    console.log('Message sync completed for connection:', conn.peer);
                }
            }
        } catch (error) {
            console.error('Error syncing existing messages:', error);
        }
    }

    handleIncomingData(data, conn) {
        switch (data.type) {
            case 'audio':
                this.handleIncomingAudio(data);
                break;
            case 'sync-message':
                this.handleSyncMessage(data);
                break;
            case 'room-name-change':
                this.handleRoomNameChange(data);
                break;
            case 'user-status':
                this.handleUserStatus(data);
                break;
            default:
                console.log('Unknown data type received:', data.type);
        }
    }

    async handleIncomingAudio(data) {
        try {
            console.log('🎵 Processing incoming audio:', data.voiceId);
            
            if (!data || !data.audioData || !data.voiceId) {
                console.error('Invalid audio data received:', data);
                return;
            }

            // جلوگیری از پردازش تکراری پیام‌های sync
            if (data.isSync && this.processedSyncMessages && this.processedSyncMessages.has(data.voiceId)) {
                console.log('Sync message already processed:', data.voiceId);
                return;
            }

            // تبدیل آرایه به Blob
            const audioBlob = new Blob([new Uint8Array(data.audioData)], { 
                type: data.mimeType || 'audio/webm' 
            });
            
            // ذخیره در دیتابیس فقط اگر از قبل وجود نداشته باشد
            if (typeof DatabaseManager !== 'undefined' && DatabaseManager.saveVoice) {
                try {
                    // بررسی وجود پیام قبل از ذخیره
                    const existingMessages = await DatabaseManager.getVoicesByRoom(this.currentRoom);
                    const messageExists = existingMessages.some(msg => msg.voiceId === data.voiceId);
                    
                    if (!messageExists) {
                        await DatabaseManager.saveVoice({
                            voiceId: data.voiceId,
                            blob: audioBlob,
                            timestamp: data.timestamp || Date.now(),
                            roomCode: this.currentRoom,
                            userEmail: data.userEmail || 'unknown@example.com',
                            userAvatar: data.userAvatar || '',
                            userName: data.userName || data.userEmail || 'کاربر ناشناس'
                        });
                        console.log('Incoming audio saved to database');
                    } else {
                        console.log('Message already exists in database:', data.voiceId);
                    }
                } catch (dbError) {
                    console.error('Error saving incoming audio to database:', dbError);
                }
            }

            // اضافه کردن به لیست پیام‌های پردازش شده
            if (data.isSync) {
                if (!this.processedSyncMessages) {
                    this.processedSyncMessages = new Set();
                }
                this.processedSyncMessages.add(data.voiceId);
            }

            // نمایش پیام صوتی فقط اگر ChatRoom در دسترس باشد
            if (window.ChatRoom && typeof window.ChatRoom.displayRecording === 'function') {
                try {
                    window.ChatRoom.displayRecording(
                        URL.createObjectURL(audioBlob),
                        true, // isReceived
                        data.timestamp || Date.now(),
                        data.voiceId,
                        data.userEmail || 'unknown@example.com',
                        data.userAvatar || '',
                        data.userName || data.userEmail || 'کاربر ناشناس',
                        {
                            uploaded: data.uploaded || false,
                            fileName: data.fileName || '',
                            duration: data.duration || 0
                        }
                    );
                    console.log('Incoming audio displayed in UI');
                } catch (displayError) {
                    console.error('Error displaying incoming audio:', displayError);
                }
            } else {
                console.log('ChatRoom.displayRecording not available, using simple display');
                this.displaySimpleIncomingMessage({
                    voiceId: data.voiceId,
                    audioBlob: audioBlob,
                    timestamp: data.timestamp || Date.now(),
                    userEmail: data.userEmail || 'unknown@example.com',
                    userAvatar: data.userAvatar || '',
                    userName: data.userName || data.userEmail || 'کاربر ناشناس'
                });
            }

        } catch (error) {
            console.error('Error handling incoming audio:', error);
            if (window.errorHandler) {
                window.errorHandler.logError('Incoming Audio Error', error);
            }
        }
    }

    handleSyncMessage(data) {
        console.log('📥 Syncing message:', data.voiceId);
        // تبدیل sync message به audio message و پردازش
        this.handleIncomingAudio({
            ...data,
            type: 'audio'
        });
    }

    displaySimpleIncomingMessage(voiceMessage) {
        try {
            const messagesContainer = document.getElementById('chatMessages') || 
                                   document.getElementById('messages') || 
                                   document.querySelector('.chat-messages');
                                   
            if (!messagesContainer) {
                console.warn('No messages container found for simple display');
                return;
            }

            const messageDiv = document.createElement('div');
            messageDiv.className = 'voice-message received';
            messageDiv.innerHTML = `
                <div class="message-info">
                    <strong>${voiceMessage.userName}</strong>
                    <small>${new Date(voiceMessage.timestamp).toLocaleTimeString('fa-IR')}</small>
                </div>
                <audio controls>
                    <source src="${URL.createObjectURL(voiceMessage.audioBlob)}">
                </audio>
            `;

            messagesContainer.appendChild(messageDiv);
            messagesContainer.scrollTop = messagesContainer.scrollHeight;
            
        } catch (error) {
            console.error('Error in simple message display:', error);
        }
    }

    async broadcastAudio(audioBlob, voiceId, additionalInfo = {}) {
        try {
            console.log('🔊 Broadcasting audio to', this.connections.size, 'connections');
            
            if (this.connections.size === 0) {
                console.log('No connections available for broadcast');
                return;
            }

            // تبدیل Blob به Array برای انتقال
            const arrayBuffer = await audioBlob.arrayBuffer();
            const audioData = Array.from(new Uint8Array(arrayBuffer));
            
            const currentUser = (typeof Utils !== 'undefined' && Utils.getCurrentUser) ? 
                               Utils.getCurrentUser() : 
                               { 
                                   email: localStorage.getItem('userEmail') || 'guest@example.com',
                                   name: localStorage.getItem('userName') || 'مهمان',
                                   avatar: localStorage.getItem('userAvatar') || ''
                               };

            const broadcastData = {
                type: 'audio',
                voiceId: voiceId,
                audioData: audioData,
                mimeType: audioBlob.type,
                timestamp: Date.now(),
                userEmail: currentUser.email,
                userName: currentUser.name,
                userAvatar: currentUser.avatar,
                roomCode: this.currentRoom,
                isSync: false, // این یک پیام عادی است، نه sync
                ...additionalInfo
            };

            const failedConnections = [];
            
            // ارسال به تمام اتصالات فعال
            for (const [peerId, conn] of this.connections) {
                try {
                    if (conn.open) {
                        conn.send(broadcastData);
                        console.log('✅ Audio sent to:', peerId);
                        
                        // کمی صبر بین ارسال‌ها برای جلوگیری از spam
                        await new Promise(resolve => setTimeout(resolve, 50));
                    } else {
                        console.log('❌ Connection not open for:', peerId);
                        failedConnections.push(peerId);
                    }
                } catch (error) {
                    console.error('❌ Failed to send to', peerId, ':', error);
                    failedConnections.push(peerId);
                }
            }

            // پاک کردن اتصالات ناموفق
            failedConnections.forEach(peerId => {
                this.connections.delete(peerId);
            });

            if (failedConnections.length > 0) {
                console.log(`Removed ${failedConnections.length} failed connections`);
                this.updateOnlineCount();
            }

            console.log('✅ Audio broadcast completed');

        } catch (error) {
            console.error('❌ Error broadcasting audio:', error);
            throw error;
        }
    }

    handleConnectionError(error) {
        console.error('🚨 Connection error:', error);
        
        if (error.message.includes('ID') && error.message.includes('taken')) {
            console.log('Peer ID conflict detected, will retry with unique ID after delay');
            
            // در صورت ID conflict، بلافاسله reconnect نکن، صبر کن
            if (this.reconnectAttempts < this.maxReconnectAttempts && !this.becomingCreator) {
                // برای Creator ها که از room code ساده استفاده می‌کنند، مارک کن که دیگر نباید ساده استفاده کنند
                if (this.isRoomCreator && this.reconnectAttempts === 0) {
                    this.hasTriedBecomeCreator = true; // این باعث می‌شود از ID یکتا استفاده کند
                }
                
                const delay = 4000 + (this.reconnectAttempts * 3000); // 4s, 7s, 10s
                console.log(`Waiting ${delay}ms before retry due to ID conflict`);
                
                setTimeout(() => {
                    this.reconnectAttempts++;
                    this.initializePeer(this.currentRoom, this.isRoomCreator);
                }, delay);
            } else {
                console.log('Max ID conflict retries reached, switching to creator mode');
                if (!this.isRoomCreator && !this.becomingCreator) {
                    this.becomeRoomCreator();
                }
            }
            return;
        }
        
        if (error.message.includes('Could not connect to peer')) {
            console.log('Target peer not found, they may have disconnected');
            
            // اگر joiner هستیم و نمی‌توانیم به creator متصل شویم
            if (!this.isRoomCreator && !this.hasTriedBecomeCreator && !this.becomingCreator) {
                console.log('Unable to find room creator, switching to creator mode');
                this.hasTriedBecomeCreator = true;
                // تبدیل به creator شدن در صورت عدم دسترسی به creator اصلی
                this.becomeRoomCreator();
                return;
            }
        }
        
        // برای سایر خطاها، retry با exponential backoff
        if (this.reconnectAttempts < this.maxReconnectAttempts && !this.becomingCreator) {
            console.log(`Attempting to recover from error... (${this.reconnectAttempts + 1}/${this.maxReconnectAttempts})`);
            
            // Exponential backoff برای جلوگیری از spam
            const delay = 3000 * Math.pow(2, this.reconnectAttempts); // 3s, 6s, 12s
            
            setTimeout(() => {
                this.reconnectAttempts++;
                this.initializePeer(this.currentRoom, this.isRoomCreator);
            }, delay);
        } else {
            console.log('Max error recovery attempts reached');
            this.updateConnectionStatus('failed');
        }
    }

    // تبدیل شدن به creator اتاق در صورت عدم دسترسی به creator اصلی
    async becomeRoomCreator() {
        console.log('🔄 Becoming room creator due to original creator unavailability');
        
        try {
            // جلوگیری از تداخل - اگر در حال تبدیل شدن به creator هستیم، منتظر بمانیم
            if (this.becomingCreator) {
                console.log('Already becoming creator, waiting...');
                return;
            }
            
            this.becomingCreator = true;
            
            // تغییر وضعیت به creator
            this.isRoomCreator = true;
            this.reconnectAttempts = 0;
            
            // بستن اتصال فعلی و تمیز کردن
            if (this.peer && !this.peer.destroyed) {
                this.peer.destroy();
                this.connections.clear();
                await new Promise(resolve => setTimeout(resolve, 2000)); // زمان بیشتر برای cleanup کامل
            }
            
            // تولید ID یکتا برای creator جدید تا از ID conflict جلوگیری کنیم
            const timestamp = Date.now();
            const randomSuffix = Math.random().toString(36).substring(2, 10);
            const newCreatorId = `newcreator-${this.currentRoom}-${timestamp}-${randomSuffix}`;
            
            console.log('Creating new creator with unique ID:', newCreatorId);
            
            // راه‌اندازی مجدد به عنوان creator با ID یکتا
            const peerOptions = {
                config: { 
                    iceServers: CONFIG.STUN_SERVERS,
                    sdpSemantics: 'unified-plan',
                    iceCandidatePoolSize: 10
                },
                debug: 1
            };

            if (window.location.protocol === 'http:' || window.location.protocol === 'https:') {
                peerOptions.host = window.location.hostname || 'localhost';
                peerOptions.secure = window.location.protocol === 'https:';
                peerOptions.port = window.location.protocol === 'https:' ? 443 : 80;
            }

            this.peer = new Peer(newCreatorId, peerOptions);
            
            this.peer.on('open', (id) => {
                console.log('✅ New creator established with ID:', id);
                this.updateConnectionStatus('connected');
                this.becomingCreator = false;
                
                // اطلاع رسانی درباره تغییر creator
                this.broadcastCreatorChange();
                
                // به‌روزرسانی UI
                this.updateRoleDisplay();
                
                console.log('✅ Successfully became room creator');
            });

            this.peer.on('connection', (conn) => {
                console.log('📞 New connection to new creator from:', conn.peer);
                this.setupConnection(conn);
            });

            this.peer.on('error', (error) => {
                console.error('New creator peer error:', error);
                this.becomingCreator = false;
                this.updateConnectionStatus('failed');
            });
            
        } catch (error) {
            console.error('❌ Failed to become room creator:', error);
            this.becomingCreator = false;
            this.updateConnectionStatus('failed');
        }
    }

    // اطلاع رسانی درباره تغییر creator
    broadcastCreatorChange() {
        const changeMessage = {
            type: 'creator-change',
            newCreatorId: this.peer?.id,
            roomCode: this.currentRoom,
            timestamp: Date.now()
        };
        
        // ارسال به تمام اتصالات موجود
        for (const [peerId, conn] of this.connections) {
            try {
                if (conn.open) {
                    conn.send(changeMessage);
                }
            } catch (error) {
                console.warn('Failed to send creator change to:', peerId);
            }
        }
        console.log('📢 Broadcast creator change notification');
    }

    // به‌روزرسانی نمایش نقش کاربر
    updateRoleDisplay() {
        const roleElement = document.getElementById('roleInfo');
        if (roleElement) {
            roleElement.textContent = this.isRoomCreator ? 'Creator' : 'Joiner';
        }
        
        // اضافه کردن نشانگر بصری برای creator جدید
        if (this.isRoomCreator) {
            this.showCreatorNotification();
        }
    }

    // نمایش اطلاعیه تبدیل شدن به creator
    showCreatorNotification() {
        try {
            // ایجاد یا به‌روزرسانی notification
            let notification = document.getElementById('creatorNotification');
            if (!notification) {
                notification = document.createElement('div');
                notification.id = 'creatorNotification';
                notification.style.cssText = `
                    position: fixed;
                    top: 20px;
                    right: 20px;
                    background: linear-gradient(45deg, #4CAF50, #45a049);
                    color: white;
                    padding: 15px 20px;
                    border-radius: 8px;
                    box-shadow: 0 4px 12px rgba(0,0,0,0.3);
                    z-index: 1000;
                    font-family: 'Vazirmatn', sans-serif;
                    font-size: 14px;
                    max-width: 300px;
                    animation: slideIn 0.3s ease-out;
                `;
                document.body.appendChild(notification);
            }
            
            notification.innerHTML = `
                <div style="display: flex; align-items: center;">
                    <span style="font-size: 18px; margin-left: 10px;">👑</span>
                    <div>
                        <strong>شما اکنون مدیر اتاق هستید!</strong>
                        <br>
                        <small>creator اصلی در دسترس نبود</small>
                    </div>
                </div>
            `;
            
            // حذف notification بعد از 5 ثانیه
            setTimeout(() => {
                if (notification && notification.parentNode) {
                    notification.style.animation = 'slideOut 0.3s ease-in';
                    setTimeout(() => {
                        if (notification.parentNode) {
                            notification.parentNode.removeChild(notification);
                        }
                    }, 300);
                }
            }, 5000);
            
        } catch (error) {
            console.error('Error showing creator notification:', error);
        }
    }

    handleDisconnection() {
        console.log('Handling disconnection...');
        this.connections.clear();
        this.updateConnectionStatus('disconnected');
        this.updateOnlineCount();
    }

    updateConnectionStatus(status) {
        console.log('Connection status update:', status);
        
        const statusLight = document.getElementById('connectionLight');
        const statusText = document.getElementById('connectionText');
        
        if (statusLight && statusText) {
            switch (status) {
                case 'connected':
                    statusLight.className = 'connection-light connected';
                    statusText.textContent = 'متصل';
                    break;
                case 'connecting':
                    statusLight.className = 'connection-light connecting';
                    statusText.textContent = 'در حال اتصال...';
                    break;
                case 'failed':
                    statusLight.className = 'connection-light failed';
                    statusText.textContent = 'اتصال ناموفق';
                    break;
                case 'disconnected':
                default:
                    statusLight.className = 'connection-light disconnected';
                    statusText.textContent = 'قطع شده';
                    break;
            }
        }
        
        // اطلاع رسانی به سایر قسمت‌های برنامه
        if (typeof window.updateConnectionStatus === 'function') {
            window.updateConnectionStatus(status === 'connected');
        }
    }

    updateOnlineCount() {
        const count = this.getConnectionCount();
        console.log('📊 Online users count:', count + 1); // +1 برای خود کاربر
        
        const onlineCountElement = document.getElementById('onlineUsers');
        if (onlineCountElement) {
            onlineCountElement.textContent = count + 1;
        }
        
        // اطلاع رسانی به ChatRoom
        if (window.ChatRoom && typeof window.ChatRoom.updateOnlineUsers === 'function') {
            window.ChatRoom.updateOnlineUsers(count + 1);
        }
    }

    disconnect() {
        console.log('🔌 Disconnecting from peer network...');
        
        // Reset state
        this.resetConnectionState();
        
        if (this.peer && !this.peer.destroyed) {
            this.peer.destroy();
        }
        
        this.currentRoom = null;
        this.updateConnectionStatus('disconnected');
        this.updateOnlineCount();
        
        console.log('✅ Disconnected successfully');
    }

    getConnectionCount() {
        return this.connections.size;
    }

    handleRoomNameChange(data) {
        console.log('📝 Room name changed:', data.newName);
        
        if (window.ChatRoom && typeof window.ChatRoom.updateRoomName === 'function') {
            window.ChatRoom.updateRoomName(data.newName);
        }
    }

    handleUserStatus(data) {
        console.log('👤 User status update:', data);
        // اینجا می‌توانید وضعیت کاربران را مدیریت کنید
    }

    // Reset connection state
    resetConnectionState() {
        console.log('🔄 Resetting connection state');
        this.becomingCreator = false;
        this.hasTriedBecomeCreator = false;
        this.reconnectAttempts = 0;
        this.connections.clear();
        this.processedSyncMessages.clear(); // پاک کردن sync messages
        this.lastConnectionAttempt = 0; // reset circuit breaker
    }
}

// صادر کردن کلاس برای استفاده در سایر فایل‌ها
window.ConnectionManager = ConnectionManager;
