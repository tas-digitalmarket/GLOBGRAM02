// تست تنظیمات ویژه WebView اندروید
function testAndroidWebView() {
    console.log('🔍 Testing Android WebView Configuration...');
    
    // تشخیص محیط
    const isAndroid = /android/i.test(navigator.userAgent);
    const isWebView = /wv/i.test(navigator.userAgent) || 
                     !!window.AndroidAudio ||
                     document.URL.indexOf('file:///android_asset/') !== -1 ||
                     (document.URL.indexOf('http://') === -1 && document.URL.indexOf('https://') === -1);
    
    // بررسی وجود interface و متدهای آن
    const androidAudioMethods = [];
    if (window.AndroidAudio) {
        for (const prop in window.AndroidAudio) {
            if (typeof window.AndroidAudio[prop] === 'function') {
                androidAudioMethods.push(prop);
            }
        }
    }
    
    const results = {
        isAndroid,
        isWebView,
        hasAndroidAudio: !!window.AndroidAudio,
        androidAudioMethods,
        userAgent: navigator.userAgent,
        hasMediaDevices: !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia),
        documentURL: document.URL,
        // تست هر دو روش دسترسی به میکروفون
        webViewPermissions: testWebViewPermissions(),
        deviceInfo: getDeviceInfo()
    };
    
    console.log('📊 WebView Test Results:', results);
    
    // لاگ کامل نتایج در Java
    if (window.AndroidAudio && window.AndroidAudio.logDebug) {
        window.AndroidAudio.logDebug('WebView Test Results: ' + JSON.stringify(results, null, 2));
    }
    
    // نمایش نتایج
    showResults(results);
    
    return results;
}

// تست مجوزهای WebView
function testWebViewPermissions() {
    const permissions = {
        androidAudioAvailable: false,
        hasPermissionMethod: false,
        requestPermissionMethod: false,
        currentPermissionStatus: 'unknown'
    };
    
    // بررسی وجود interface
    if (window.AndroidAudio) {
        permissions.androidAudioAvailable = true;
        
        // بررسی متدهای مجوز
        if (typeof window.AndroidAudio.hasAudioPermission === 'function') {
            permissions.hasPermissionMethod = true;
            try {
                permissions.currentPermissionStatus = window.AndroidAudio.hasAudioPermission();
            } catch (e) {
                permissions.currentPermissionStatus = 'error: ' + e.message;
            }
        }
        
        if (typeof window.AndroidAudio.requestPermission === 'function') {
            permissions.requestPermissionMethod = true;
        }
        
        // ثبت نسخه
        if (typeof window.AndroidAudio.getDeviceInfo === 'function') {
            permissions.deviceInfo = window.AndroidAudio.getDeviceInfo();
        }
    }
    
    return permissions;
}

// دریافت اطلاعات دستگاه
function getDeviceInfo() {
    const info = {
        platform: navigator.platform,
        vendor: navigator.vendor,
        language: navigator.language,
        screenWidth: window.screen.width,
        screenHeight: window.screen.height,
        devicePixelRatio: window.devicePixelRatio || 1
    };
    
    // اطلاعات اضافی از AndroidAudio interface
    if (window.AndroidAudio && typeof window.AndroidAudio.getDeviceInfo === 'function') {
        info.androidDeviceInfo = window.AndroidAudio.getDeviceInfo();
    }
    
    return info;
}

// نمایش نتایج
function showResults(results) {
    let message = `
📱 تست WebView اندروید:

• اندروید: ${results.isAndroid ? '✅' : '❌'}
• WebView: ${results.isWebView ? '✅' : '❌'}
• AndroidAudio Interface: ${results.hasAndroidAudio ? '✅' : '❌'}
• MediaDevices API: ${results.hasMediaDevices ? '✅' : '❌'}

${results.hasAndroidAudio ? `
🔐 تست مجوزها:
• متد hasAudioPermission: ${results.webViewPermissions.hasPermissionMethod ? '✅' : '❌'}
• متد requestPermission: ${results.webViewPermissions.requestPermissionMethod ? '✅' : '❌'}
• وضعیت فعلی مجوز: ${results.webViewPermissions.currentPermissionStatus === true ? '✅ مجاز' : '❌ غیرمجاز'}
` : ''}

📋 اطلاعات دستگاه:
• پلتفرم: ${results.deviceInfo.platform}
• صفحه نمایش: ${results.deviceInfo.screenWidth}×${results.deviceInfo.screenHeight}
${results.deviceInfo.androidDeviceInfo ? '• جزئیات اندروید: ' + results.deviceInfo.androidDeviceInfo : ''}

🌐 User Agent:
${results.userAgent}
    `;
    
    // نمایش در alert یا toast
    if (window.AndroidAudio && window.AndroidAudio.showToast) {
        window.AndroidAudio.showToast('تست WebView انجام شد');
        console.log(message); // فقط در کنسول نمایش می‌دهیم
    } else {
        alert(message);
    }
}

// تست دسترسی میکروفون
async function testMicrophoneAccess() {
    console.log('🎤 Testing microphone access in WebView...');
    
    try {
        // تست دسترسی از طریق AndroidAudio
        if (window.AndroidAudio && typeof window.AndroidAudio.hasAudioPermission === 'function') {
            const hasPermission = window.AndroidAudio.hasAudioPermission();
            console.log('AndroidAudio permission check:', hasPermission);
            
            if (window.AndroidAudio.logDebug) {
                window.AndroidAudio.logDebug('Initial permission check: ' + hasPermission);
            }
            
            if (!hasPermission && typeof window.AndroidAudio.requestPermission === 'function') {
                console.log('Requesting permission through AndroidAudio...');
                
                if (window.AndroidAudio.logDebug) {
                    window.AndroidAudio.logDebug('Requesting permission via AndroidAudio interface');
                }
                
                try {
                    const result = window.AndroidAudio.requestPermission();
                    console.log('Permission request result:', result);
                    
                    if (window.AndroidAudio.logDebug) {
                        window.AndroidAudio.logDebug('Permission request result: ' + result);
                    }
                    
                    // دوباره چک می‌کنیم
                    setTimeout(() => {
                        try {
                            const newStatus = window.AndroidAudio.hasAudioPermission();
                            console.log('Permission status after request:', newStatus);
                            
                            if (window.AndroidAudio.logDebug) {
                                window.AndroidAudio.logDebug('Permission status after request: ' + newStatus);
                            }
                            
                            if (window.AndroidAudio.showToast) {
                                window.AndroidAudio.showToast('وضعیت مجوز: ' + (newStatus ? 'مجاز' : 'غیرمجاز'));
                            }
                            
                            // اگر مجوز تغییر کرده، نیاز به reload داریم
                            if (newStatus && !hasPermission) {
                                console.log('Permission granted, reloading page...');
                                if (window.AndroidAudio.logDebug) {
                                    window.AndroidAudio.logDebug('Reloading page to apply permission');
                                }
                                alert('مجوز میکروفون دریافت شد. برای اعمال تغییرات، صفحه بازنشانی می‌شود.');
                                setTimeout(() => window.location.reload(), 1000);
                            }
                        } catch (e) {
                            console.error('Error checking permission after request:', e);
                            if (window.AndroidAudio.logDebug) {
                                window.AndroidAudio.logDebug('Error checking permission: ' + e.message);
                            }
                        }
                    }, 1000);
                    
                    return;
                } catch (e) {
                    console.error('Error requesting permission:', e);
                    if (window.AndroidAudio.logDebug) {
                        window.AndroidAudio.logDebug('Error requesting permission: ' + e.message);
                    }
                }
            }
        }
        
        // تست دسترسی با getUserMedia
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        console.log('Microphone access successful:', stream);
        
        // لاگ اضافی برای دیباگ
        if (window.AndroidAudio && window.AndroidAudio.logDebug) {
            window.AndroidAudio.logDebug('getUserMedia successful');
        }
        
        // بستن stream
        stream.getTracks().forEach(track => track.stop());
        
        alert('✅ دسترسی به میکروفون موفقیت‌آمیز بود!');
        
    } catch (error) {
        console.error('Microphone access failed:', error);
        
        // لاگ در Java
        if (window.AndroidAudio && window.AndroidAudio.logDebug) {
            window.AndroidAudio.logDebug('Microphone access error: ' + error.name + ' - ' + error.message);
        }
        
        // پیام خطا با راه‌حل‌های مناسب بر اساس نوع خطا
        let errorMessage = `❌ خطا در دسترسی به میکروفون:
        
نام خطا: ${error.name}
پیام: ${error.message}

`;

        if (error.name === 'NotAllowedError' || error.name === 'PermissionDeniedError') {
            errorMessage += `راه‌حل‌ها:
1. مطمئن شوید مجوز میکروفون در اپلیکیشن فعال است
2. به تنظیمات برنامه بروید و دسترسی میکروفون را فعال کنید
3. اپلیکیشن را کامل ببندید و دوباره باز کنید`;
        } else if (error.name === 'NotFoundError') {
            errorMessage += `راه‌حل‌ها:
1. مطمئن شوید دستگاه شما میکروفون دارد
2. دسترسی میکروفون را در تنظیمات اندروید فعال کنید`;
        } else if (error.name === 'NotReadableError' || error.name === 'AbortError') {
            errorMessage += `راه‌حل‌ها:
1. اپلیکیشن دیگری ممکن است میکروفون را اشغال کرده باشد
2. دستگاه را restart کنید
3. اپلیکیشن را کامل ببندید و دوباره باز کنید`;
        } else {
            errorMessage += `راه‌حل‌ها:
1. در WebView مطمئن شوید setMediaPlaybackRequiresUserGesture(false) تنظیم شده
2. از onPermissionRequest در WebChromeClient استفاده کنید
3. اپلیکیشن را کامل ببندید و دوباره باز کنید`;
        }
        
        if (window.AndroidAudio && window.AndroidAudio.openSettings) {
            errorMessage += `\n\nبرای باز کردن تنظیمات برنامه و فعال کردن مجوز میکروفون، دکمه "تنظیمات" را بزنید.`;
            
            const userResponse = confirm(errorMessage + "\n\nآیا می‌خواهید تنظیمات برنامه را باز کنید؟");
            if (userResponse) {
                window.AndroidAudio.openSettings();
            }
        } else {
            alert(errorMessage);
        }
    }
}

// برای دسترسی از سایر بخش‌ها
window.testAndroidWebView = testAndroidWebView;
window.testMicrophoneAccess = testMicrophoneAccess;
