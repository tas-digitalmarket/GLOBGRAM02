// Environment Configuration Example
// این فایل را کپی کرده و به env-config.js تبدیل کنید
// کلیدهای واقعی خود را جایگزین کنید

const ENV_CONFIG = {
    // EmailJS Configuration
    // از https://www.emailjs.com دریافت کنید
    EMAIL: {
        PUBLIC_KEY: "YOUR_EMAILJS_PUBLIC_KEY",    // کلید عمومی EmailJS
        SERVICE_ID: "YOUR_EMAILJS_SERVICE_ID",    // شناسه سرویس
        TEMPLATE_ID: "YOUR_EMAILJS_TEMPLATE_ID"   // شناسه قالب
    },
    
    // Environment Type
    ENVIRONMENT: 'development', // 'development' | 'production'
    
    // API Endpoints (در صورت وجود backend)
    API: {
        BASE_URL: window.location.origin,
        ENDPOINTS: {
            AUTH: '/api/auth',
            VERIFY: '/api/verify',
            ROOMS: '/api/rooms'
        }
    },
    
    // Feature Flags
    FEATURES: {
        OFFLINE_MODE: true,           // حالت آفلاین
        PUSH_NOTIFICATIONS: false,    // اعلان‌های push
        ANALYTICS: false,             // آنالیتیکس
        DEBUG_LOGS: true              // لاگ‌های debug
    }
};

// Helper function برای دریافت config
function getConfig(path, fallback = null) {
    try {
        return path.split('.').reduce((obj, key) => obj?.[key], ENV_CONFIG) || fallback;
    } catch (error) {
        console.warn('Config path not found:', path);
        return fallback;
    }
}

// Export برای Node.js environment
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { ENV_CONFIG, getConfig };
}

// Global access
window.ENV_CONFIG = ENV_CONFIG;
window.getConfig = getConfig;
