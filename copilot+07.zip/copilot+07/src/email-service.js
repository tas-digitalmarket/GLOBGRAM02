  class EmailService {
      constructor() {
          this.config = CONFIG.EMAIL_CONFIG;
          console.log('EmailService config:', this.config);
        
          if (typeof emailjs !== 'undefined') {
              // استفاده از روش جدید initialization
              emailjs.init(this.config.publicKey);
              console.log('✅ EmailJS initialized successfully');
          } else {
              console.error('❌ EmailJS library not loaded');
          }
      }

      async sendVerificationCode(email) {
          if (!email || !email.includes('@')) {
              throw new Error('ایمیل نامعتبر است');
          }

          const verifyCode = Math.floor(100000 + Math.random() * 900000).toString();
        
          try {
              if (typeof emailjs === 'undefined') {
                  throw new Error('EmailJS library not loaded');
              }

              console.log('📧 Sending verification email...');
              console.log('Email:', email);
              console.log('Code:', verifyCode);
              console.log('Service ID:', this.config.serviceId);
              console.log('Template ID:', this.config.templateId);

              // Template parameters - مطابق با template شما
              const templateParams = {
                  to_email: email,
                  verification_code: verifyCode,
                  user_name: email.split('@')[0],
                  from_name: "Globgram"
              };

              console.log('📋 Template parameters:', templateParams);

              // ارسال ایمیل
              const response = await emailjs.send(
                  this.config.serviceId, 
                  this.config.templateId, 
                  templateParams
              );
            
              console.log('✅ Email sent successfully!');
              console.log('Response:', response);
            
              return verifyCode;
            
          } catch (error) {
              console.error('❌ Email sending failed:', error);
            
              // تجزیه و تحلیل خطا
              let errorMessage = 'خطا در ارسال ایمیل';
            
              if (error.status === 400) {
                  if (error.text?.includes('Public Key')) {
                      errorMessage = '🔑 Public Key نامعتبر است';
                  } else if (error.text?.includes('template')) {
                      errorMessage = '📄 Template پیدا نشد یا نامعتبر است';
                  } else if (error.text?.includes('service')) {
                      errorMessage = '⚙️ Service ID نامعتبر است';
                  } else {
                      errorMessage = '❌ ' + error.text;
                  }
              } else if (error.status === 422) {
                  errorMessage = '📧 ایمیل نامعتبر یا مسدود است';
              } else if (!error.status) {
                  errorMessage = '🌐 مشکل در اتصال به اینترنت';
              }
            
              console.error('Error details:', {
                  status: error.status,
                  text: error.text,
                  message: error.message
              });
            
              throw new Error(errorMessage);
          }
      }

      // Mock verification برای تست
      mockVerification(verifyCode) {
          console.log('🔧 Mock Email Service - Verification Code:', verifyCode);
        
          // نمایش کد در console و alert برای تست
          alert(`📧 کد تایید (حالت تست): ${verifyCode}\n\nاین کد را در فیلد تایید وارد کنید.`);
        
          return verifyCode;
      }

      // تست سریع سرویس
      async quickTest() {
          console.log('🧪 Testing EmailJS configuration...');
        
          try {
              // تست با ایمیل ساختگی
              const testResponse = await emailjs.send(
                  this.config.serviceId,
                  this.config.templateId,
                  {
                      to_email: 'test@example.com',
                      verification_code: '123456',
                      user_name: 'Test User',
                      from_name: 'Globgram Test'
                  }
              );
            
              console.log('✅ EmailJS test successful:', testResponse);
              return true;
          } catch (error) {
              console.error('❌ EmailJS test failed:', error);
              return false;
          }
      }
  }

  window.EmailService = EmailService;
