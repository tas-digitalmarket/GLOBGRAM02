// Environment Configuration
// ⚠️ این فایل باید در .gitignore قرار گیرد
// ⚠️ کلیدهای واقعی را از محیط production دریافت کنید

const ENV_CONFIG = {
    // EmailJS Configuration
    EMAIL: {
        PUBLIC_KEY: "mIlm34r7HHZ0hsr3Z",    // از environment variable بخوانید
        SERVICE_ID: "service_l5atf6s",      // از environment variable بخوانید  
        TEMPLATE_ID: "template_0ahwrci"     // از environment variable بخوانید
    },
    
    // Development vs Production
    ENVIRONMENT: 'development', // 'development' | 'production'
    
    // API Endpoints (در صورت وجود backend)
    API: {
        BASE_URL: window.location.origin,
        ENDPOINTS: {
            AUTH: '/api/auth',
            VERIFY: '/api/verify',
            ROOMS: '/api/rooms'
        }
    },
    
    // Feature Flags
    FEATURES: {
        OFFLINE_MODE: true,
        PUSH_NOTIFICATIONS: false,
        ANALYTICS: false,
        DEBUG_LOGS: true
    }
};

// Helper function برای دریافت config با fallback
function getConfig(path, fallback = null) {
    try {
        if (!path || typeof path !== 'string') {
            console.warn('Invalid config path:', path);
            return fallback;
        }
        
        const result = path.split('.').reduce((obj, key) => {
            return obj && obj[key] !== undefined ? obj[key] : null;
        }, ENV_CONFIG);
        
        return result !== null ? result : fallback;
    } catch (error) {
        console.warn('Error getting config for path:', path, error);
        return fallback;
    }
}

// Safe config access
function safeGetConfig(path, fallback = null) {
    try {
        if (typeof ENV_CONFIG === 'undefined') {
            console.warn('ENV_CONFIG not defined, using fallback');
            return fallback;
        }
        return getConfig(path, fallback);
    } catch (error) {
        console.error('Error in safeGetConfig:', error);
        return fallback;
    }
}

// Export برای سایر فایل‌ها
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { ENV_CONFIG, getConfig, safeGetConfig };
}

// Global access with error handling
try {
    if (typeof window !== 'undefined') {
        window.ENV_CONFIG = ENV_CONFIG;
        window.getConfig = getConfig;
        window.safeGetConfig = safeGetConfig;
    }
} catch (error) {
    console.error('Error setting global ENV_CONFIG:', error);
}
window.ENV_CONFIG = ENV_CONFIG;
window.getConfig = getConfig;
