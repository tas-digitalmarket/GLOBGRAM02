// اضافه کردن این کد به voice-manager.js موجود

// تشخیص محیط امن بهبود یافته
detectSecureContext() {
    const isSecureContext = window.isSecureContext;
    const isLocalhost = location.hostname === 'localhost' || 
                       location.hostname === '127.0.0.1' || 
                       location.hostname === '0.0.0.0';
    const isHTTPS = location.protocol === 'https:';
    const isFile = location.protocol === 'file:';
    
    // در Chrome، localhost روی HTTP هم Secure Context محسوب می‌شود
    const isEffectivelySecure = isSecureContext || (isLocalhost && location.protocol === 'http:');
    
    console.log('🔐 Secure Context Analysis:', {
        isSecureContext,
        isLocalhost,
        isHTTPS,
        isFile,
        isEffectivelySecure,
        protocol: location.protocol,
        hostname: location.hostname,
        href: location.href,
        userAgent: navigator.userAgent
    });
    
    // لاگ در اپلیکیشن اندروید
    if (window.AndroidAudio && window.AndroidAudio.logDebug) {
        window.AndroidAudio.logDebug('Secure Context: ' + JSON.stringify({
            isSecureContext,
            isLocalhost,
            isHTTPS,
            isEffectivelySecure,
            href: location.href
        }));
    }
    
    return {
        isSecureContext,
        isLocalhost,
        isHTTPS,
        isFile,
        isEffectivelySecure,
        canUseGetUserMedia: isEffectivelySecure && !!navigator.mediaDevices?.getUserMedia
    };
}

// بهبود متد startRecording
async startRecording() {
    if (this.isRecording) {
        console.log('⚠️ Already recording');
        return;
    }

    if (!window.connectionManager?.currentRoom) {
        this.showError('برای ضبط صدا ابتدا وارد اتاق شوید');
        return;
    }

    console.log('🎤 Starting recording process...');
    
    // بررسی Secure Context
    const secureContext = this.detectSecureContext();
    
    if (!secureContext.canUseGetUserMedia) {
        console.error('❌ getUserMedia not available - not in secure context');
        
        if (this.platform.isAndroidApp && window.AndroidAudio) {
            console.log('🤖 Trying Android native recording...');
            return this.startAndroidNativeRecording();
        } else {
            this.showSecureContextError(secureContext);
            return;
        }
    }

    try {
        // تلاش برای دریافت مجوز و شروع ضبط
        await this.requestPermissions();
        await this.initializeRecording();
        
    } catch (error) {
        console.error('❌ Recording failed:', error);
        this.handleRecordingError(error);
    }
}

// متد جدید برای نمایش خطای Secure Context
showSecureContextError(secureContext) {
    let message = `🔐 محیط امن مورد نیاز است

وضعیت فعلی:
• آدرس: ${location.href}
• پروتکل: ${location.protocol}
• میزبان: ${location.hostname}
• Secure Context: ${secureContext.isSecureContext ? 'بله' : 'خیر'}
• Localhost: ${secureContext.isLocalhost ? 'بله' : 'خیر'}

راه‌حل‌ها:`;

    if (!secureContext.isHTTPS && !secureContext.isLocalhost) {
        message += `
1. استفاده از https:// به جای http://
2. تست روی localhost
3. استفاده از اپلیکیشن موبایل`;
    } else if (secureContext.isFile) {
        message += `
1. استفاده از سرور HTTP محلی
2. استفاده از https://localhost
3. استفاده از اپلیکیشن موبایل`;
    } else {
        message += `
1. بررسی تنظیمات مرورگر
2. به‌روزرسانی مرورگر
3. تست در اپلیکیشن موبایل`;
    }

    // لاگ در اپلیکیشن اندروید
    if (window.AndroidAudio && window.AndroidAudio.logDebug) {
        window.AndroidAudio.logDebug('Secure Context Error: ' + message);
    }

    if (window.showWarning) {
        window.showWarning(message);
    } else {
        alert(message);
    }
    
    // نمایش گزینه‌های جایگزین
    this.showAlternativeOptions(new Error('Not in secure context'));
}

// بهبود متد requestPermissions
async requestPermissions() {
    console.log('🔐 Requesting microphone permissions...');
    
    // روش 1: Android App مجوزها
    if (this.platform.isAndroidApp || this.platform.requiresPermissionRequest) {
        const granted = await this.requestAndroidAppPermissions();
        if (!granted) {
            throw new Error('Android permission denied');
        }
    }

    // روش 2: Web API
    if (!this.stream) {
        const constraints = this.getConstraintsForPlatform();
        console.log('🎤 Requesting getUserMedia with constraints:', constraints);
        
        try {
            this.stream = await navigator.mediaDevices.getUserMedia(constraints);
            console.log('✅ getUserMedia successful, stream:', this.stream);
            
            // لاگ در اپلیکیشن اندروید
            if (window.AndroidAudio?.logDebug) {
                window.AndroidAudio.logDebug('getUserMedia successful - tracks: ' + this.stream.getTracks().length);
            }
            
        } catch (error) {
            console.error('❌ getUserMedia failed:', error);
            
            // لاگ خطا در اپلیکیشن اندروید
            if (window.AndroidAudio?.logDebug) {
                window.AndroidAudio.logDebug('getUserMedia failed: ' + error.name + ' - ' + error.message);
            }
            
            throw error;
        }
    }
}

// متد بهبود یافته requestAndroidAppPermissions
async requestAndroidAppPermissions() {
    console.log('🔐 Requesting Android app permissions...');
    
    try {
        // روش 1: Cordova Permissions Plugin
        if (this.cordovaPermissions) {
            return await this.requestCordovaPermission();
        }
        
        // روش 2: Android WebView Interface
        if (this.androidAudioInterface && this.androidAudioInterface.requestPermission) {
            console.log('🔐 Using AndroidAudio interface to request permission');
            
            // لاگ بیشتر برای دیباگ
            if (this.androidAudioInterface.logDebug) {
                this.androidAudioInterface.logDebug('Requesting microphone permission via AndroidAudio interface');
            }
            
            try {
                const result = this.androidAudioInterface.requestPermission();
                console.log('🎤 Permission request sent, result:', result);
                
                // اضافه کردن لاگ برای دیباگ
                if (this.androidAudioInterface.logDebug) {
                    this.androidAudioInterface.logDebug('Permission request result: ' + result);
                }
                
                // چک مجدد وضعیت مجوز بعد از درخواست
                if (this.androidAudioInterface.hasAudioPermission) {
                    // تاخیر بیشتر برای اطمینان از اعمال مجوز
                    await new Promise(resolve => setTimeout(resolve, 1500));
                    const hasPermission = this.androidAudioInterface.hasAudioPermission();
                    console.log('🔍 Permission status after request:', hasPermission);
                    
                    // اگر مجوز داده شده، صفحه را ریلود کنیم تا مجوز WebView اعمال شود
                    if (hasPermission && typeof window.location !== 'undefined') {
                        console.log('✅ Permission granted, reloading page to apply...');
                        if (this.androidAudioInterface.logDebug) {
                            this.androidAudioInterface.logDebug('Reloading page to apply permission');
                        }
                        
                        // نمایش پیام به کاربر
                        if (this.androidAudioInterface.showToast) {
                            this.androidAudioInterface.showToast('مجوز میکروفون اعطا شد. صفحه بازنشانی می‌شود...');
                        }
                        
                        // تاخیر قبل از reload
                        setTimeout(() => {
                            if (this.androidAudioInterface.reloadWebView) {
                                this.androidAudioInterface.reloadWebView();
                            } else {
                                window.location.reload();
                            }
                        }, 1000);
                    }
                    
                    return hasPermission;
                }
                
                return result === true || result === "true";
            } catch (error) {
                console.error('Error in AndroidAudio interface:', error);
                if (this.androidAudioInterface.logDebug) {
                    this.androidAudioInterface.logDebug('Error: ' + error.message);
                }
                return false;
            }
        }
        
        // روش 3: HTML5 getUserMedia (fallback)
        return await this.requestHTML5Permission();
        
    } catch (error) {
        console.error('Error requesting Android permissions:', error);
        
        // در صورت خطا، تلاش می‌کنیم راه‌حل جایگزین را نشان دهیم
        this.showAlternativeOptions(new Error('Android permission error: ' + error.message));
        return false;
    }
}

// متد کمکی برای تست Secure Context
async testSecureContext() {
    const secureContext = this.detectSecureContext();
    
    console.log('🧪 Testing Secure Context and Media Devices...');
    
    const result = {
        secureContext: secureContext,
        mediaDevicesAvailable: !!navigator.mediaDevices,
        getUserMediaAvailable: !!(navigator.mediaDevices?.getUserMedia),
        androidInterface: !!window.AndroidAudio,
        testResult: null,
        error: null,
        timestamp: new Date().toISOString()
    };

    if (secureContext.canUseGetUserMedia) {
        try {
            // تست کوتاه getUserMedia
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            const tracks = stream.getAudioTracks();
            
            result.testResult = 'SUCCESS';
            result.trackInfo = {
                count: tracks.length,
                label: tracks[0]?.label || 'نامشخص',
                settings: tracks[0]?.getSettings?.() || {}
            };
            
            // بستن stream
            stream.getTracks().forEach(track => track.stop());
            
            console.log('✅ Secure Context test passed');
        } catch (error) {
            result.error = {
                name: error.name,
                message: error.message
            };
            result.testResult = 'FAILED';
            console.error('❌ Secure Context test failed:', error);
        }
    } else {
        result.testResult = 'NOT_SECURE';
        result.error = {
            name: 'NotSecureContext',
            message: 'Not in secure context'
        };
        console.log('⚠️ Not in secure context');
    }

    // لاگ کامل در اپلیکیشن اندروید
    if (window.AndroidAudio?.logDebug) {
        window.AndroidAudio.logDebug('Secure Context test complete: ' + JSON.stringify(result, null, 2));
    }

    return result;
}

// بهبود handleRecordingError برای مدیریت بهتر خطاها
handleRecordingError(error) {
    console.error('🚨 Recording error:', error);
    
    let userMessage = '';
    let technicalInfo = `خطا: ${error.name} - ${error.message}`;
    let suggestedActions = [];
    
    switch (error.name) {
        case 'NotAllowedError':
        case 'PermissionDeniedError':
            userMessage = 'دسترسی به میکروفون رد شد';
            suggestedActions = [
                'مجوز میکروفون را در تنظیمات برنامه فعال کنید',
                'اپلیکیشن را ببندید و دوباره باز کنید',
                'دستگاه را restart کنید'
            ];
            break;
            
        case 'NotFoundError':
            userMessage = 'میکروفون یافت نشد';
            suggestedActions = [
                'مطمئن شوید دستگاه شما میکروفون دارد',
                'میکروفون را در تنظیمات سیستم فعال کنید'
            ];
            break;
            
        case 'NotReadableError':
        case 'AbortError':
            userMessage = 'میکروفون در حال استفاده است';
            suggestedActions = [
                'سایر برنامه‌هایی که از میکروفون استفاده می‌کنند را ببندید',
                'دستگاه را restart کنید'
            ];
            break;
            
        case 'NotSupportedError':
            const secureContext = this.detectSecureContext();
            if (!secureContext.isEffectivelySecure) {
                userMessage = 'محیط امن مورد نیاز است';
                suggestedActions = [
                    'استفاده از HTTPS یا localhost',
                    'استفاده از اپلیکیشن موبایل'
                ];
            } else {
                userMessage = 'مرورگر از ضبط صدا پشتیبانی نمی‌کند';
                suggestedActions = [
                    'مرورگر را به‌روزرسانی کنید',
                    'از مرورگر دیگری استفاده کنید'
                ];
            }
            break;
            
        case 'OverconstrainedError':
            userMessage = 'تنظیمات صوتی با دستگاه سازگار نیست';
            suggestedActions = [
                'تنظیمات کیفیت صدا را کاهش دهید'
            ];
            break;
            
        default:
            userMessage = 'خطای غیرمنتظره در ضبط صدا';
            suggestedActions = [
                'اپلیکیشن را ببندید و دوباره باز کنید',
                'دستگاه را restart کنید'
            ];
    }
    
    // ایجاد پیام کامل
    const fullMessage = `${userMessage}

${technicalInfo}

راه‌حل‌های پیشنهادی:
${suggestedActions.map((action, index) => `${index + 1}. ${action}`).join('\n')}`;

    // لاگ در اپلیکیشن اندروید
    if (window.AndroidAudio?.logDebug) {
        window.AndroidAudio.logDebug('Recording error details: ' + JSON.stringify({
            name: error.name,
            message: error.message,
            userMessage,
            suggestedActions
        }));
    }

    // نمایش خطا به کاربر
    if (this.platform.isAndroidApp && window.AndroidAudio?.showToast) {
        window.AndroidAudio.showToast(userMessage);
        
        // نمایش dialog با جزئیات بیشتر
        if (window.AndroidAudio.showNativeDialog) {
            window.AndroidAudio.showNativeDialog('خطا در ضبط صدا', fullMessage);
        }
    } else {
        if (window.showError) {
            window.showError(fullMessage);
        } else {
            alert(fullMessage);
        }
    }

    // پیشنهاد راه‌حل‌های جایگزین
    this.showAlternativeOptions(error);
}

// متدهای کمکی global
window.testSecureContext = async () => {
    if (window.voiceManager) {
        return await window.voiceManager.testSecureContext();
    } else {
        console.error('VoiceManager not initialized');
        return null;
    }
};

window.showSecureContextStatus = () => {
    if (window.voiceManager) {
        const secureContext = window.voiceManager.detectSecureContext();
        
        const status = `🔐 وضعیت Secure Context:

• Secure Context: ${secureContext.isSecureContext ? '✅' : '❌'}
• Localhost: ${secureContext.isLocalhost ? '✅' : '❌'}
• HTTPS: ${secureContext.isHTTPS ? '✅' : '❌'}
• قابلیت استفاده از میکروفون: ${secureContext.canUseGetUserMedia ? '✅' : '❌'}

📍 آدرس فعلی:
${location.href}

🔧 MediaDevices API: ${!!navigator.mediaDevices ? '✅' : '❌'}
🎤 getUserMedia: ${!!(navigator.mediaDevices?.getUserMedia) ? '✅' : '❌'}
📱 AndroidAudio Interface: ${!!window.AndroidAudio ? '✅' : '❌'}`;

        if (window.AndroidAudio?.showNativeDialog) {
            window.AndroidAudio.showNativeDialog('وضعیت Secure Context', status);
        } else {
            alert(status);
        }
    }
};
