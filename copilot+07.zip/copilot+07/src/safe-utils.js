// Safe utility functions to prevent null/undefined errors
class SafeUtils {
    // Safe element operations
    static safeGetElement(id) {
        try {
            return document.getElementById(id);
        } catch (error) {
            console.error('Error getting element:', id, error);
            return null;
        }
    }

    static safeSetText(elementId, text) {
        try {
            const element = this.safeGetElement(elementId);
            if (element) {
                element.textContent = text;
                return true;
            }
            return false;
        } catch (error) {
            console.error('Error setting text:', error);
            return false;
        }
    }

    static safeSetHTML(elementId, html) {
        try {
            const element = this.safeGetElement(elementId);
            if (element) {
                element.innerHTML = html;
                return true;
            }
            return false;
        } catch (error) {
            console.error('Error setting HTML:', error);
            return false;
        }
    }

    // Safe localStorage operations
    static safeLocalStorageSet(key, value) {
        try {
            localStorage.setItem(key, value);
            return true;
        } catch (error) {
            console.error('Error setting localStorage:', error);
            return false;
        }
    }

    static safeLocalStorageGet(key, defaultValue = null) {
        try {
            return localStorage.getItem(key) || defaultValue;
        } catch (error) {
            console.error('Error getting localStorage:', error);
            return defaultValue;
        }
    }

    // Safe function calls
    static safeCall(func, ...args) {
        try {
            if (typeof func === 'function') {
                return func(...args);
            }
            console.warn('Function is not callable:', func);
            return null;
        } catch (error) {
            console.error('Error calling function:', error);
            return null;
        }
    }

    // Safe async function calls
    static async safeAsyncCall(func, ...args) {
        try {
            if (typeof func === 'function') {
                return await func(...args);
            }
            console.warn('Function is not callable:', func);
            return null;
        } catch (error) {
            console.error('Error calling async function:', error);
            return null;
        }
    }

    // Safe object property access
    static safeGet(obj, path, defaultValue = null) {
        try {
            if (!obj || typeof path !== 'string') {
                return defaultValue;
            }

            return path.split('.').reduce((current, key) => {
                return current && current[key] !== undefined ? current[key] : defaultValue;
            }, obj);
        } catch (error) {
            console.error('Error getting safe property:', error);
            return defaultValue;
        }
    }

    // Safe URL creation
    static safeCreateObjectURL(blob) {
        try {
            if (blob && typeof URL !== 'undefined' && URL.createObjectURL) {
                return URL.createObjectURL(blob);
            }
            console.warn('Cannot create object URL');
            return null;
        } catch (error) {
            console.error('Error creating object URL:', error);
            return null;
        }
    }

    // Safe JSON operations
    static safeJsonParse(jsonString, defaultValue = null) {
        try {
            return JSON.parse(jsonString);
        } catch (error) {
            console.error('Error parsing JSON:', error);
            return defaultValue;
        }
    }

    static safeJsonStringify(obj, defaultValue = '{}') {
        try {
            return JSON.stringify(obj);
        } catch (error) {
            console.error('Error stringifying JSON:', error);
            return defaultValue;
        }
    }

    // Safe event handling
    static safeAddEventListener(element, event, handler) {
        try {
            if (element && typeof element.addEventListener === 'function') {
                element.addEventListener(event, handler);
                return true;
            }
            return false;
        } catch (error) {
            console.error('Error adding event listener:', error);
            return false;
        }
    }

    // Safe timeout/interval operations
    static safeSetTimeout(func, delay) {
        try {
            return setTimeout(() => {
                this.safeCall(func);
            }, delay);
        } catch (error) {
            console.error('Error setting timeout:', error);
            return null;
        }
    }

    static safeSetInterval(func, interval) {
        try {
            return setInterval(() => {
                this.safeCall(func);
            }, interval);
        } catch (error) {
            console.error('Error setting interval:', error);
            return null;
        }
    }

    // Safe clearTimeout/clearInterval
    static safeClearTimeout(timeoutId) {
        try {
            if (timeoutId) {
                clearTimeout(timeoutId);
            }
        } catch (error) {
            console.error('Error clearing timeout:', error);
        }
    }

    static safeClearInterval(intervalId) {
        try {
            if (intervalId) {
                clearInterval(intervalId);
            }
        } catch (error) {
            console.error('Error clearing interval:', error);
        }
    }
}

// Make SafeUtils globally available
if (typeof window !== 'undefined') {
    window.SafeUtils = SafeUtils;
}

// Export for module usage
if (typeof module !== 'undefined' && module.exports) {
    module.exports = SafeUtils;
}
