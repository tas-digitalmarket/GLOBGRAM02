console.log('Database schema initialized');

// تنظیم اطلاعات کاربر
const userEmail = localStorage.getItem('userEmail');
window.currentUser = { email: userEmail || 'guest@example.com' };

// Unique voice ID generator
function generateVoiceId() {
    const voiceId = `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    console.log('Generated voice ID:', voiceId);
    return voiceId;
}

class VoiceManager {
    constructor() {
        this.recorder = null;
        this.chunks = [];
        this.isRecording = false;
        this.stream = null;
        this.recordingStartTime = null;
        this.maxRecordingTime = 60000; // 60 seconds
        this.platform = this.detectPlatform();
        
        console.log('VoiceManager initialized - Platform:', this.platform);
        
        // تنظیمات خاص اندروید
        if (this.platform.isAndroid) {
            this.setupAndroidOptimizations();
        }
    }

    // تشخیص پلتفرم
    detectPlatform() {
        const userAgent = navigator.userAgent.toLowerCase();
        const platform = navigator.platform?.toLowerCase() || '';
        
        // تشخیص دقیق‌تر Android WebView
        const isWebView = /wv/.test(userAgent) || 
                         userAgent.includes('webview') ||
                         userAgent.includes('crosswalk') ||
                         !!window.AndroidAudio ||        // JavaScriptInterface سفارشی
                         document.URL.indexOf('file:///android_asset/') !== -1;  // فایل داخلی اندروید
        
        // تشخیص دقیق‌تر Android App
        const isAndroidApp = /android/.test(userAgent) && (
            isWebView ||                              // WebView
            !!window.cordova ||                       // Cordova
            !!window.PhoneGap ||                      // PhoneGap
            !!window.AndroidAudio ||                  // JavaScriptInterface سفارشی
            !!window.plugins ||                       // Native plugins
            document.URL.indexOf('http://') === -1 && // بدون http
            document.URL.indexOf('https://') === -1   // بدون https
        );
        
        // لاگ دیباگ
        console.log('🔍 Platform detection:', {
            userAgent,
            isWebView,
            isAndroidApp,
            hasAndroidAudio: !!window.AndroidAudio,
            url: document.URL
        });
        
        // تشخیص و لاگ بیشتر برای اندروید 
        if (!!window.AndroidAudio && window.AndroidAudio.logDebug) {
            window.AndroidAudio.logDebug('Platform detected: ' + 
                `Android: ${/android/.test(userAgent)}, ` + 
                `WebView: ${isWebView}, ` + 
                `URL: ${document.URL}`
            );
        }
        
        return {
            isAndroid: /android/.test(userAgent),
            isAndroidApp: isAndroidApp,
            isIOS: /iphone|ipad|ipod/.test(userAgent),
            isMobile: /android|iphone|ipad|ipod|blackberry|iemobile|opera mini/.test(userAgent),
            isDesktopApp: userAgent.includes('electron') || userAgent.includes('nwjs') || window.process || window.require,
            isCordova: !!window.cordova,
            isWebView: isWebView,
            isNativeApp: !!(window.cordova || window.PhoneGap || isAndroidApp),
            userAgent: userAgent,
            platform: platform,
            // اطلاعات اضافی
            supportsMediaDevices: !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia),
            requiresPermissionRequest: isAndroidApp || !!window.cordova || isWebView
        };
    }

    // تنظیمات بهینه سازی برای اندروید
    setupAndroidOptimizations() {
        console.log('🤖 Setting up Android optimizations...');
        
        // تشخیص نوع اپلیکیشن
        if (this.platform.isAndroidApp || this.platform.isCordova) {
            console.log('📱 Detected Android App environment');
            this.setupNativeAudioSupport();
        }
        
        // تنظیم AudioContext برای اندروید
        if (typeof AudioContext !== 'undefined') {
            this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
        }
        
        // مدیریت وضعیت صفحه برای اندروید
        document.addEventListener('visibilitychange', () => {
            if (document.hidden && this.isRecording) {
                console.log('App went to background, stopping recording');
                this.stopRecording();
            }
        });
        
        // تنظیمات خاص WebView
        if (this.platform.isWebView) {
            this.setupWebViewOptimizations();
            this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
        }
        
        // مدیریت وضعیت صفحه برای اندروید
        document.addEventListener('visibilitychange', () => {
            if (document.hidden && this.isRecording) {
                console.log('App went to background, stopping recording');
                this.stopRecording();
            }
        });
        
        // تنظیمات خاص WebView
        if (this.platform.isWebView) {
            this.setupWebViewOptimizations();
        }
    }
    
    // راه‌اندازی پشتیبانی صدا در اپ‌های Native
    setupNativeAudioSupport() {
        console.log('🎤 Setting up native audio support...');
        
        // چک کردن Cordova plugins
        if (window.cordova) {
            document.addEventListener('deviceready', () => {
                this.setupCordovaAudio();
            }, false);
        } else {
            // Fallback برای Android WebView
            this.setupWebViewAudio();
        }
    }
    
    // تنظیم صدا برای Cordova
    setupCordovaAudio() {
        console.log('📱 Setting up Cordova audio...');
        
        // چک کردن Media plugin
        if (window.Media) {
            console.log('✅ Cordova Media plugin available');
            this.useCordovaMedia = true;
        }
        
        // چک کردن permission plugin
        if (window.cordova.plugins && window.cordova.plugins.permissions) {
            console.log('✅ Cordova permissions plugin available');
            this.cordovaPermissions = window.cordova.plugins.permissions;
        }
    }
    
    // تنظیم صدا برای Android WebView
    setupWebViewAudio() {
        console.log('🌐 Setting up WebView audio...');
        
        // چک کردن Android WebView interface
        if (window.AndroidAudio) {
            console.log('✅ Android WebView audio interface available');
            this.androidAudioInterface = window.AndroidAudio;
            
            // بررسی متدهای موجود در interface
            const methods = [];
            for (const prop in this.androidAudioInterface) {
                if (typeof this.androidAudioInterface[prop] === 'function') {
                    methods.push(prop);
                }
            }
            console.log('📱 AndroidAudio interface methods:', methods);
            
            // لاگ برای دیباگ
            if (this.androidAudioInterface.logDebug) {
                this.androidAudioInterface.logDebug('WebViewAudio interface initialized');
                this.androidAudioInterface.logDebug('Available methods: ' + methods.join(', '));
            }
            
            // چک کردن مجوز میکروفون
            if (this.androidAudioInterface.hasAudioPermission && typeof this.androidAudioInterface.hasAudioPermission === 'function') {
                try {
                    const hasPermission = this.androidAudioInterface.hasAudioPermission();
                    console.log('🎤 Microphone permission status:', hasPermission);
                    
                    if (this.androidAudioInterface.logDebug) {
                        this.androidAudioInterface.logDebug('Initial permission status: ' + hasPermission);
                    }
                    
                    if (hasPermission) {
                        console.log('✅ Android app already has microphone permission');
                    } else {
                        console.log('⚠️ Android app needs microphone permission');
                        
                        // پیام کوتاه برای کاربر
                        if (this.androidAudioInterface.showToast) {
                            this.androidAudioInterface.showToast('برای ضبط صدا، مجوز میکروفون را تایید کنید');
                        }
                    }
                } catch (error) {
                    console.error('Error checking permission:', error);
                }
            } else {
                console.log('⚠️ hasAudioPermission method not available');
            }
            
            // آیا صفحه را باید ریلود کنیم؟
            if (this.androidAudioInterface.getReloadRequired && this.androidAudioInterface.getReloadRequired()) {
                console.log('🔄 Page reload required for permissions');
                if (this.androidAudioInterface.logDebug) {
                    this.androidAudioInterface.logDebug('Reloading page for permissions');
                }
                // تاخیر کوتاه قبل از reload
                setTimeout(() => window.location.reload(), 500);
            }
        } else {
            console.log('⚠️ Android WebView interface not available, using HTML5 fallback');
        }
        
        // Fallback: استفاده از HTML5 Audio با تنظیمات خاص
        this.setupHTML5AudioFallback();
    }
    
    // تنظیمات بهینه WebView
    setupWebViewOptimizations() {
        console.log('🔧 Setting up WebView optimizations...');
        
        // تنظیمات مخصوص WebView
        if (window.chrome && window.chrome.webstore === undefined) {
            // در WebView قرار داریم
            this.webViewMode = true;
            
            // تنظیمات audio برای WebView
            this.audioConstraints = {
                audio: {
                    echoCancellation: true,
                    noiseSuppression: true,
                    autoGainControl: true,
                    sampleRate: 22050, // کاهش کیفیت برای بهتر کار کردن
                    channelCount: 1
                }
            };
        }
    }
    
    // HTML5 Audio Fallback
    setupHTML5AudioFallback() {
        console.log('🎵 Setting up HTML5 audio fallback...');
        
        // تنظیمات محدود برای compatibility
        this.fallbackAudioConstraints = {
            audio: {
                channelCount: 1,
                sampleRate: 16000,
                echoCancellation: false,
                noiseSuppression: false
            }
        };
    }

    // شروع ضبط با پشتیبانی Android App
    async startRecording() {
        if (this.isRecording) return;
        
        if (!window.connectionManager?.currentRoom) {
            alert('لطفا ابتدا وارد یک اتاق شوید');
            return;
        }

        // مدیریت تغییر orientation برای موبایل
        if (this.platform.isMobile) {
            window.addEventListener('orientationchange', () => {
                setTimeout(() => {
                    if (this.isRecording) {
                        console.log('Orientation changed during recording');
                    }
                }, 500);
            });
        }

        // درخواست مجوز برای اندروید
        if (this.platform.isAndroid) {
            await this.requestAndroidPermissions();
        }

        // درخواست مجوز برای اندروید App
        if (this.platform.isAndroidApp || this.platform.requiresPermissionRequest) {
            const permissionGranted = await this.requestAndroidAppPermissions();
            if (!permissionGranted) {
                this.showAndroidPermissionGuide();
                return;
            }
        }

        try {
            const constraints = this.getConstraintsForPlatform();
            console.log('Requesting microphone access with constraints:', constraints);

            this.stream = await this.requestMicrophoneAccess(constraints);
            
            if (!this.stream) {
                throw new Error('Unable to access microphone');
            }

            await this.initializeRecorder();
            
        } catch (error) {
            console.error('Error accessing microphone:', error);
            this.handleMicrophoneError(error);
        }
    }

    // درخواست مجوزهای اندروید
    async requestAndroidPermissions() {
        if (this.platform.isCordova && window.cordova?.plugins?.permissions) {
            try {
                const permissions = window.cordova.plugins.permissions;
                const permission = permissions.RECORD_AUDIO;
                
                const hasPermission = await new Promise(resolve => {
                    permissions.hasPermission(permission, resolve);
                });
                
                if (!hasPermission.hasPermission) {
                    await new Promise((resolve, reject) => {
                        permissions.requestPermission(permission, resolve, reject);
                    });
                }
            } catch (error) {
                console.warn('Cordova permissions not available:', error);
            }
        }
    }

    // درخواست مجوز برای Android App
    async requestAndroidAppPermissions() {
        console.log('🔐 Requesting Android app permissions...');
        
        try {
            // روش 1: Cordova Permissions Plugin
            if (this.cordovaPermissions) {
                const permission = this.cordovaPermissions.RECORD_AUDIO;
                
                return new Promise((resolve) => {
                    this.cordovaPermissions.checkPermission(permission, 
                        (status) => {
                            if (status.hasPermission) {
                                console.log('✅ Audio permission already granted');
                                resolve(true);
                            } else {
                                this.cordovaPermissions.requestPermission(permission,
                                    (success) => {
                                        console.log('✅ Audio permission granted');
                                        resolve(success.hasPermission);
                                    },
                                    (error) => {
                                        console.log('❌ Audio permission denied:', error);
                                        resolve(false);
                                    }
                                );
                            }
                        },
                        (error) => {
                            console.log('❌ Permission check failed:', error);
                            resolve(false);
                        }
                    );
                });
            }
            
            // روش 2: Android WebView Interface
            if (this.androidAudioInterface && this.androidAudioInterface.requestPermission) {
                console.log('🔐 Using AndroidAudio interface to request permission');
                
                // لاگ بیشتر برای دیباگ
                if (this.androidAudioInterface.logDebug) {
                    this.androidAudioInterface.logDebug('Requesting microphone permission via AndroidAudio interface');
                }
                
                try {
                    // در برخی پیاده‌سازی‌ها، این متد ممکن است مستقیماً یک boolean برنگرداند
                    const result = this.androidAudioInterface.requestPermission();
                    
                    console.log('🎤 Permission request sent, result:', result);
                    
                    // اضافه کردن لاگ برای دیباگ
                    if (this.androidAudioInterface.logDebug) {
                        this.androidAudioInterface.logDebug('Permission request result: ' + result);
                    }
                    
                    // چک مجدد وضعیت مجوز بعد از درخواست
                    if (this.androidAudioInterface.hasAudioPermission) {
                        // گاهی اوقات نیاز به تأخیر بیشتر داریم تا مجوز اعمال شود
                        await new Promise(resolve => setTimeout(resolve, 1000));
                        const hasPermission = this.androidAudioInterface.hasAudioPermission();
                        console.log('🔍 Permission status after request:', hasPermission);
                        
                        // اگر مجوز داده شده، صفحه را ریلود کنیم تا مجوز WebView اعمال شود
                        if (hasPermission && typeof window.location !== 'undefined') {
                            console.log('✅ Permission granted, reloading page to apply...');
                            if (this.androidAudioInterface.logDebug) {
                                this.androidAudioInterface.logDebug('Reloading page to apply permission');
                            }
                            // تاخیر کوتاه قبل از reload
                            setTimeout(() => window.location.reload(), 500);
                        }
                        
                        return hasPermission;
                    }
                    
                    return result === true || result === "true";
                } catch (error) {
                    console.error('Error in AndroidAudio interface:', error);
                    if (this.androidAudioInterface.logDebug) {
                        this.androidAudioInterface.logDebug('Error: ' + error.message);
                    }
                    return false;
                }
            }
            
            // روش 3: HTML5 getUserMedia (fallback)
            return await this.requestHTML5Permission();
            
        } catch (error) {
            console.error('Error requesting Android permissions:', error);
            
            // در صورت خطا، تلاش می‌کنیم راه‌حل جایگزین را نشان دهیم
            this.showAlternativeOptions(new Error('Android permission error: ' + error.message));
            return false;
        }
    }
    
    // درخواست مجوز HTML5 (fallback)
    async requestHTML5Permission() {
        try {
            console.log('🌐 Trying HTML5 permission request...');
            
            const constraints = this.getConstraintsForPlatform();
            const stream = await navigator.mediaDevices.getUserMedia(constraints);
            
            // بستن stream فوری (فقط برای تست permission)
            stream.getTracks().forEach(track => track.stop());
            
            console.log('✅ HTML5 permission granted');
            return true;
            
        } catch (error) {
            console.error('❌ HTML5 permission failed:', error);
            return false;
        }
    }
    
    // راهنمای فعال‌سازی مجوز برای Android
    showAndroidPermissionGuide() {
        const message = `
🎤 برای ضبط صدا در این اپلیکیشن:

📱 روش 1 - تنظیمات اپ:
• Settings > Apps > ${document.title || 'این اپ'} > Permissions > Microphone ✅

🔧 روش 2 - تنظیمات عمومی:
• Settings > Privacy > Permission Manager > Microphone > ${document.title || 'این اپ'} ✅

⚠️ اگر باز مشکل دارید:
• اپ را ببندید و دوباره باز کنید
• گوشی را restart کنید

❓ نیاز به کمک دارید؟
دکمه "تست میکروفون" را امتحان کنید.
        `;
        
        if (window.showWarning) {
            window.showWarning(message);
        } else {
            alert(message);
        }
        
        // باز کردن تنظیمات (اگر امکان‌پذیر باشد)
        this.openAndroidSettings();
    }
    
    // باز کردن تنظیمات Android (اگر ممکن باشد)
    openAndroidSettings() {
        try {
            // Cordova approach
            if (window.cordova && window.cordova.plugins.settings) {
                window.cordova.plugins.settings.open("application_details_settings");
                return;
            }
            
            // Android WebView approach
            if (this.androidAudioInterface && this.androidAudioInterface.openSettings) {
                this.androidAudioInterface.openSettings();
                return;
            }
            
            // Intent approach (اگر امکان‌پذیر باشد)
            if (window.open) {
                window.open('intent://settings/application_details_settings#Intent;end');
            }
            
        } catch (error) {
            console.log('Could not open Android settings:', error);
        }
    }

    // انتخاب constraints مناسب بر اساس پلتفرم
    getConstraintsForPlatform() {
        console.log('🎛️ Getting constraints for platform:', this.platform);
        
        if (this.platform.isAndroidApp) {
            return this.getAndroidAppConstraints();
        } else if (this.platform.isAndroid) {
            return this.getAndroidBrowserConstraints();
        } else if (this.platform.isIOS) {
            return this.getIOSConstraints();
        } else if (this.platform.isDesktopApp) {
            return this.getDesktopConstraints();
        } else {
            return this.getBrowserConstraints();
        }
    }
    
    // تنظیمات خاص Android App
    getAndroidAppConstraints() {
        return {
            audio: {
                channelCount: 1,
                sampleRate: 22050,  // بهینه برای Android App
                echoCancellation: true,
                noiseSuppression: true,
                autoGainControl: true,
                // تنظیمات خاص Android
                volume: 1.0,
                latency: "interactive"
            }
        };
    }
    
    // تنظیمات Android Browser
    getAndroidBrowserConstraints() {
        return {
            audio: {
                channelCount: 1,
                sampleRate: 44100,
                echoCancellation: true,
                noiseSuppression: true,
                autoGainControl: true,
                volume: 1.0
            }
        };
    }
    
    // تنظیمات iOS
    getIOSConstraints() {
        return {
            audio: {
                channelCount: 1,
                sampleRate: 44100,
                echoCancellation: true,
                noiseSuppression: true,
                autoGainControl: false  // iOS بهتر خودش مدیریت می‌کند
            }
        };
    }
    
    // تنظیمات مرورگر معمولی
    getBrowserConstraints() {
        return {
            audio: {
                channelCount: 2,
                sampleRate: 48000,
                echoCancellation: true,
                noiseSuppression: true,
                autoGainControl: true
            }
        };
    }
    
    // تنظیمات دسکتاپ
    getDesktopConstraints() {
        return {
            audio: {
                channelCount: 2,
                sampleRate: 48000,
                echoCancellation: true,
                noiseSuppression: true,
                autoGainControl: true,
                latency: "playback"
            }
        };
    }

    async requestMicrophoneAccess(constraints) {
        const methods = [
            // روش استاندارد
            () => navigator.mediaDevices.getUserMedia(constraints),
            
            // روش ساده برای موبایل
            () => navigator.mediaDevices.getUserMedia({ 
                audio: {
                    echoCancellation: true,
                    noiseSuppression: true
                }
            }),
            
            // روش حداقلی
            () => navigator.mediaDevices.getUserMedia({ audio: true }),
            
            // روش قدیمی برای سازگاری
            () => new Promise((resolve, reject) => {
                const getUserMedia = navigator.getUserMedia || 
                                  navigator.webkitGetUserMedia || 
                                  navigator.mozGetUserMedia;
                
                if (getUserMedia) {
                    getUserMedia.call(navigator, { audio: true }, resolve, reject);
                } else {
                    reject(new Error('getUserMedia not supported'));
                }
            }),

            // روش بدون تنظیمات پیشرفته
            () => navigator.mediaDevices.getUserMedia({
                audio: {
                    echoCancellation: false,
                    noiseSuppression: false,
                    autoGainControl: false
                }
            })
        ];

        for (let i = 0; i < methods.length; i++) {
            try {
                console.log(`Trying microphone access method ${i + 1}...`);
                const stream = await methods[i]();
                console.log(`Method ${i + 1} successful!`);
                return stream;
            } catch (error) {
                console.warn(`Method ${i + 1} failed:`, error.message);
                if (i === methods.length - 1) {
                    throw error;
                }
                await new Promise(resolve => setTimeout(resolve, 500));
            }
        }
    }

    async initializeRecorder() {
        const audioTracks = this.stream.getAudioTracks();
        console.log('Audio tracks:', audioTracks.length);
        
        if (audioTracks.length === 0) {
            throw new Error('No audio tracks available');
        }

        audioTracks.forEach((track, index) => {
            console.log(`Track ${index}:`, {
                label: track.label,
                enabled: track.enabled,
                readyState: track.readyState,
                settings: track.getSettings()
            });
        });

        // انتخاب MIME type مناسب برای پلتفرم
        const mimeType = this.selectMimeTypeForPlatform();
        console.log('Selected MIME type:', mimeType);
        
        this.recorder = new MediaRecorder(this.stream, {
            mimeType: mimeType,
            audioBitsPerSecond: this.platform.isMobile ? 64000 : 128000
        });
        
        this.chunks = [];
        this.isRecording = true;
        this.recordingStartTime = Date.now();

        this.recorder.ondataavailable = (e) => {
            if (e.data.size > 0) {
                this.chunks.push(e.data);
                console.log('Data chunk received:', e.data.size, 'bytes');
            }
        };
        
        this.recorder.onstop = async () => {
            console.log('Recording stopped');
            await this.handleRecordingStop();
            this.cleanup();
        };

        this.recorder.onerror = (error) => {
            console.error('Recording error:', error);
            this.cleanup();
            alert('خطا در ضبط صدا');
        };

        // تنظیم timeout کوتاه تر برای موبایل
        const timeout = this.platform.isMobile ? 30000 : this.maxRecordingTime;
        setTimeout(() => {
            if (this.isRecording) {
                this.stopRecording();
            }
        }, timeout);

        // شروع ضبط با interval مناسب برای موبایل
        const interval = this.platform.isMobile ? 500 : 1000;
        this.recorder.start(interval);
        this.updateUI(true);
        this.startRecordingTimer();

        console.log('Recording started successfully');
    }

    // انتخاب MIME type مناسب برای پلتفرم
    selectMimeTypeForPlatform() {
        let mimeTypes = [];
        
        if (this.platform.isAndroid) {
            mimeTypes = [
                'audio/webm;codecs=opus',
                'audio/webm',
                'audio/ogg;codecs=opus',
                'audio/mp4',
                'audio/wav'
            ];
        } else if (this.platform.isIOS) {
            mimeTypes = [
                'audio/mp4',
                'audio/webm;codecs=opus',
                'audio/webm',
                'audio/wav'
            ];
        } else {
            mimeTypes = [
                'audio/webm;codecs=opus',
                'audio/webm',
                'audio/mp4',
                'audio/ogg;codecs=opus',
                'audio/wav'
            ];
        }
        
        for (const mimeType of mimeTypes) {
            if (MediaRecorder.isTypeSupported(mimeType)) {
                return mimeType;
            }
        }
        
        return 'audio/webm'; // fallback
    }

    handleMicrophoneError(error) {
        console.error('Microphone error details:', {
            name: error.name,
            message: error.message,
            constraint: error.constraint,
            platform: this.platform,
            isHTTP: !window.location.protocol.startsWith('https'),
            location: window.location.href
        });

        // تشخیص محیط HTTP و نمایش راه‌حل‌های جایگزین
        const isHTTP = !window.location.protocol.startsWith('https');
        const isLocalFile = window.location.protocol === 'file:';
        
        if (error.name === 'NotAllowedError' || error.name === 'SecurityError' || isHTTP || isLocalFile) {
            this.showAlternativeOptions(error);
            return;
        }

        // مدیریت سایر خطاها
        let message = 'خطا در دسترسی به میکروفون';
        
        if (error.name === 'NotFoundError') {
            message = 'میکروفون یافت نشد. لطفا میکروفون را بررسی کنید';
        } else if (error.name === 'NotReadableError') {
            if (this.platform.isAndroid) {
                message = 'میکروفون در حال استفاده است.\n\nراه حل:\n1. سایر برنامه‌های ضبط صدا را ببندید\n2. تماس‌های فعال را قطع کنید\n3. برنامه را مجدداً راه‌اندازی کنید';
            } else {
                message = 'میکروفون در حال استفاده توسط برنامه دیگری است';
            }
        } else if (error.name === 'AbortError') {
            message = 'درخواست دسترسی به میکروفون لغو شد';
        }
        
        alert(message);
        this.cleanup();
    }

    // نمایش راه‌حل‌های جایگزین برای دسترسی به میکروفون
    showAlternativeOptions(error) {
        const isHTTP = !window.location.protocol.startsWith('https');
        const isLocalFile = window.location.protocol === 'file:';
        
        // حذف modal قبلی (اگر وجود داشته باشد)
        const existingModal = document.querySelector('.microphone-alternatives-modal');
        if (existingModal) existingModal.remove();
        
        const modal = document.createElement('div');
        modal.className = 'microphone-alternatives-modal';
        modal.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 10000;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        `;
        
        // محتوای متناسب با نوع خطا
        let title, description, solutions;
        
        if (isHTTP || isLocalFile) {
            title = '🔒 محدودیت امنیتی';
            description = isHTTP ? 
                'دسترسی به میکروفون در محیط HTTP (غیر امن) محدود است.' :
                'دسترسی به میکروفون در فایل‌های محلی محدود است.';
            
            solutions = `
                <div class="solution-option">
                    <h4>🎤 آپلود فایل صوتی</h4>
                    <p>یک فایل صوتی از گوشی خود انتخاب کنید</p>
                    <input type="file" accept="audio/*" class="audio-file-input" style="
                        width: 100%;
                        padding: 10px;
                        border: 2px dashed #007bff;
                        border-radius: 8px;
                        background: #f8f9fa;
                        cursor: pointer;
                        text-align: center;
                        margin-top: 10px;
                    ">
                </div>
                
                <div class="solution-option">
                    <h4>🌐 استفاده از HTTPS</h4>
                    <p>برای دسترسی کامل میکروفون، از نسخه HTTPS استفاده کنید</p>
                    <button class="https-suggestion-btn" style="
                        background: #28a745;
                        color: white;
                        border: none;
                        padding: 10px 20px;
                        border-radius: 5px;
                        cursor: pointer;
                        margin-top: 10px;
                        width: 100%;
                    ">راهنمای استفاده از HTTPS</button>
                </div>
                
                ${this.platform.isAndroid ? `
                <div class="solution-option">
                    <h4>📱 اپلیکیشن اندروید</h4>
                    <p>برای بهترین تجربه، از اپلیکیشن اندروید استفاده کنید</p>
                    <button class="android-app-guide-btn" style="
                        background: #17a2b8;
                        color: white;
                        border: none;
                        padding: 10px 20px;
                        border-radius: 5px;
                        cursor: pointer;
                        margin-top: 10px;
                        width: 100%;
                    ">راهنمای ساخت اپ اندروید</button>
                </div>
                ` : ''}
            `;
        } else {
            title = '🎤 مشکل دسترسی میکروفون';
            description = 'دسترسی به میکروفون مسدود یا محدود است.';
            
            solutions = `
                <div class="solution-option">
                    <h4>🔧 تنظیمات مرورگر</h4>
                    <p>مجوز میکروفون را در تنظیمات مرورگر فعال کنید</p>
                    <button class="browser-settings-btn" style="
                        background: #007bff;
                        color: white;
                        border: none;
                        padding: 10px 20px;
                        border-radius: 5px;
                        cursor: pointer;
                        margin-top: 10px;
                        width: 100%;
                    ">راهنمای تنظیمات مرورگر</button>
                </div>
                
                <div class="solution-option">
                    <h4>🎤 آپلود فایل صوتی</h4>
                    <p>به عنوان جایگزین، یک فایل صوتی آپلود کنید</p>
                    <input type="file" accept="audio/*" class="audio-file-input" style="
                        width: 100%;
                        padding: 10px;
                        border: 2px dashed #007bff;
                        border-radius: 8px;
                        background: #f8f9fa;
                        cursor: pointer;
                        text-align: center;
                        margin-top: 10px;
                    ">
                </div>
            `;
        }
        
        modal.innerHTML = `
            <div style="
                background: white;
                border-radius: 15px;
                padding: 30px;
                max-width: 500px;
                width: 90%;
                max-height: 80vh;
                overflow-y: auto;
                box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            ">
                <div style="text-align: center; margin-bottom: 20px;">
                    <h2 style="margin: 0 0 10px 0; color: #333; font-size: 24px;">${title}</h2>
                    <p style="margin: 0; color: #666; font-size: 16px; line-height: 1.4;">${description}</p>
                </div>
                
                <div style="space-y: 20px;">
                    ${solutions}
                </div>
                
                <div style="text-align: center; margin-top: 20px;">
                    <button class="close-modal-btn" style="
                        background: #6c757d;
                        color: white;
                        border: none;
                        padding: 10px 30px;
                        border-radius: 25px;
                        cursor: pointer;
                        font-size: 16px;
                    ">بستن</button>
                </div>
            </div>
        `;
        
        // اضافه کردن استایل‌های اضافی
        const style = document.createElement('style');
        style.textContent = `
            .solution-option {
                background: #f8f9fa;
                border-radius: 10px;
                padding: 20px;
                margin-bottom: 15px;
                border: 1px solid #e9ecef;
            }
            .solution-option h4 {
                margin: 0 0 8px 0;
                color: #333;
                font-size: 18px;
            }
            .solution-option p {
                margin: 0 0 10px 0;
                color: #666;
                font-size: 14px;
                line-height: 1.4;
            }
            .solution-option button:hover,
            .close-modal-btn:hover {
                opacity: 0.9;
                transform: translateY(-1px);
                transition: all 0.2s;
            }
        `;
        document.head.appendChild(style);
        
        // Event listeners
        modal.addEventListener('click', (e) => {
            if (e.target === modal) modal.remove();
        });
        
        modal.querySelector('.close-modal-btn').addEventListener('click', () => {
            modal.remove();
        });
        
        // مدیریت آپلود فایل
        const fileInput = modal.querySelector('.audio-file-input');
        if (fileInput) {
            fileInput.addEventListener('change', (e) => {
                this.handleFileUpload(e.target);
            });
        }
        
        // راهنمای HTTPS
        const httpsBtn = modal.querySelector('.https-suggestion-btn');
        if (httpsBtn) {
            httpsBtn.addEventListener('click', () => {
                this.showHTTPSGuide();
            });
        }
        
        // راهنمای اپ اندروید
        const androidBtn = modal.querySelector('.android-app-guide-btn');
        if (androidBtn) {
            androidBtn.addEventListener('click', () => {
                this.showAndroidAppGuide();
            });
        }
        
        // راهنمای تنظیمات مرورگر
        const browserBtn = modal.querySelector('.browser-settings-btn');
        if (browserBtn) {
            browserBtn.addEventListener('click', () => {
                this.showBrowserSettingsGuide();
            });
        }
        
        document.body.appendChild(modal);
    }

    async testMicrophone() {
        console.log('Testing microphone access...');
        
        try {
            const constraints = this.getConstraintsForPlatform();
            const stream = await navigator.mediaDevices.getUserMedia(constraints);
            const tracks = stream.getAudioTracks();
            
            console.log('Microphone test successful:', {
                platform: this.platform,
                tracksCount: tracks.length,
                firstTrackLabel: tracks[0]?.label,
                firstTrackSettings: tracks[0]?.getSettings()
            });
            
            tracks.forEach(track => track.stop());
            
            return true;
        } catch (error) {
            console.error('Microphone test failed:', error);
            return false;
        }
    }

    stopRecording() {
        if (this.recorder && this.isRecording) {
            this.recorder.stop();
        }
    }

    async handleRecordingStop() {
        if (!this.chunks || this.chunks.length === 0) {
            this.showError('هیچ صدایی ضبط نشده است');
            return;
        }

        if (!this.recordingStartTime) {
            this.showError('خطا در زمان‌سنجی ضبط');
            return;
        }

        const recordingDuration = Date.now() - this.recordingStartTime;
        if (recordingDuration < 1000) {
            this.showError('ضبط باید حداقل 1 ثانیه باشد');
            return;
        }

        try {
            const audioBlob = new Blob(this.chunks, { type: 'audio/webm' });
            const timestamp = Date.now();
            const voiceId = (typeof Utils !== 'undefined' && Utils.generateVoiceId) ? 
                           Utils.generateVoiceId() : 
                           generateVoiceId() || `voice-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
            const currentUser = (typeof Utils !== 'undefined' && Utils.getCurrentUser) ? 
                               Utils.getCurrentUser() : 
                               { email: 'guest@example.com', name: 'مهمان', avatar: '' };

            // Check if required objects exist
            if (!window.connectionManager) {
                console.warn('ConnectionManager not available');
                this.showError('مدیر اتصال در دسترس نیست');
                return;
            }

            if (!window.connectionManager.currentRoom) {
                this.showError('ابتدا وارد اتاق شوید');
                return;
            }

            // Save to database with error handling
            if (typeof DatabaseManager !== 'undefined' && DatabaseManager.saveVoice) {
                try {
                    await DatabaseManager.saveVoice({
                        voiceId,
                        blob: audioBlob,
                        timestamp,
                        roomCode: window.connectionManager.currentRoom,
                        userEmail: currentUser.email,
                        userAvatar: currentUser.avatar,
                        userName: currentUser.name,
                        duration: recordingDuration,
                        platform: this.platform.isAndroid ? 'android' : 
                                 this.platform.isIOS ? 'ios' : 
                                 this.platform.isDesktopApp ? 'desktop' : 'web'
                    });
                } catch (dbError) {
                    console.error('Error saving to database:', dbError);
                    // Continue without database save
                }
            }

            // Display in UI with error handling
            if (window.ChatRoom && typeof window.ChatRoom.displayRecording === 'function') {
                try {
                    window.ChatRoom.displayRecording(
                        URL.createObjectURL(audioBlob),
                        false,
                        timestamp,
                        voiceId,
                        currentUser.email,
                        currentUser.avatar,
                        currentUser.name
                    );
                } catch (displayError) {
                    console.error('Error displaying recording:', displayError);
                    this.showError('خطا در نمایش پیام صوتی');
                }
            }

            // Broadcast with error handling
            try {
                await window.connectionManager.broadcastAudio(audioBlob, voiceId);
            } catch (broadcastError) {
                console.error('Error broadcasting audio:', broadcastError);
                this.showWarning('پیام ضبط شد اما ارسال به سایرین ممکن نباشد');
            }

            // به‌روزرسانی تعداد پیام‌ها در localStorage
            if (typeof window.updateRoomMessageCount === 'function') {
                await window.updateRoomMessageCount(window.connectionManager.currentRoom);
            }

            this.showRecordingSuccess();

        } catch (error) {
            console.error('Error handling recording:', error);
            this.showError('خطا در ذخیره ضبط: ' + (error.message || 'خطای نامشخص'));
        }
    }

    // Helper methods for user messages
    showError(message) {
        if (window.errorHandler && typeof window.errorHandler.showUserMessage === 'function') {
            window.errorHandler.showUserMessage(message, 'error');
        } else {
            alert('❌ ' + message);
        }
    }

    showWarning(message) {
        if (window.errorHandler && typeof window.errorHandler.showUserMessage === 'function') {
            window.errorHandler.showUserMessage(message, 'warning');
        } else {
            alert('⚠️ ' + message);
        }
    }

    showSuccess(message) {
        if (window.errorHandler && typeof window.errorHandler.showUserMessage === 'function') {
            window.errorHandler.showUserMessage(message, 'success');
        } else {
            console.log('✅ ' + message);
        }
    }

    startRecordingTimer() {
        const timerElement = document.getElementById('recordingTimer');
        if (!timerElement) return;

        timerElement.style.display = 'block';
        timerElement.classList.add('active');

        const startTime = Date.now();
        const timer = setInterval(() => {
            if (!this.isRecording) {
                clearInterval(timer);
                timerElement.style.display = 'none';
                timerElement.classList.remove('active');
                timerElement.textContent = '';
                return;
            }

            const elapsed = Date.now() - startTime;
            const seconds = Math.floor(elapsed / 1000);
            const minutes = Math.floor(seconds / 60);
            const remainingSeconds = seconds % 60;
            
            timerElement.textContent = `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
            
            // تغییر رنگ در 10 ثانیه آخر برای موبایل
            const maxTime = this.platform.isMobile ? 30 : 60;
            if (seconds >= maxTime - 10) {
                timerElement.style.color = 'orange';
            }
        }, 1000);
    }

    showRecordingSuccess() {
        const message = document.createElement('div');
        message.className = 'recording-success';
        message.textContent = '✅ پیام صوتی ارسال شد';
        message.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: #28a745;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            z-index: 10000;
            animation: slideInRight 0.3s ease;
            font-size: ${this.platform.isMobile ? '14px' : '16px'};
        `;
        
        document.body.appendChild(message);
        
        setTimeout(() => {
            if (message.parentNode) {
                message.remove();
            }
        }, 3000);
    }

    cleanup() {
        if (this.stream) {
            this.stream.getTracks().forEach(track => {
                console.log('Stopping track:', track.label);
                track.stop();
            });
            this.stream = null;
        }
        
        if (this.recorder) {
            this.recorder = null;
        }
        
        this.chunks = [];
        this.isRecording = false;
        this.updateUI(false);
        
        const timerElement = document.getElementById('recordingTimer');
        if (timerElement) {
            timerElement.style.display = 'none';
            timerElement.classList.remove('active');
            timerElement.textContent = '';
            timerElement.style.color = '';
        }
    }

    updateUI(isRecording) {
        const recordButton = document.getElementById('recordButton');
        const stopButton = document.getElementById('stopButton');
        
        if (recordButton && stopButton) {
            recordButton.disabled = isRecording;
            stopButton.disabled = !isRecording;
            
            if (isRecording) {
                recordButton.textContent = 'در حال ضبط...';
                recordButton.classList.add('recording');
                recordButton.style.background = '#ff4444';
                
                // ویبریشن برای موبایل
                if (this.platform.isMobile && navigator.vibrate) {
                    navigator.vibrate(100);
                }
            } else {
                recordButton.textContent = 'شروع ضبط';
                recordButton.classList.remove('recording');
                recordButton.style.background = '#007bff';
            }
        }
    }

    // متد برای تست و تشخیص مشکلات میکروفون
    async diagnose() {
        console.log('🔍 Diagnosing microphone issues...');
        
        const results = {
            platform: this.platform,
            mediaDevicesSupported: !!navigator.mediaDevices,
            getUserMediaSupported: !!navigator.mediaDevices?.getUserMedia,
            devices: [],
            permissions: null,
            testResult: null,
            supportedMimeTypes: []
        };

        try {
            // بررسی دستگاه های موجود
            if (navigator.mediaDevices?.enumerateDevices) {
                const devices = await navigator.mediaDevices.enumerateDevices();
                results.devices = devices.filter(device => device.kind === 'audioinput');
            }

            // بررسی مجوزها
            if (navigator.permissions?.query) {
                try {
                    const permission = await navigator.permissions.query({ name: 'microphone' });
                    results.permissions = permission.state;
                } catch (e) {
                    console.log('Permission query not supported');
                }
            }

            // بررسی MIME types پشتیبانی شده
            const mimeTypes = [
                'audio/webm;codecs=opus',
                'audio/webm',
                'audio/mp4',
                'audio/ogg;codecs=opus',
                'audio/wav'
            ];
            
            results.supportedMimeTypes = mimeTypes.filter(type => 
                MediaRecorder.isTypeSupported(type)
            );

            // تست میکروفون
            results.testResult = await this.testMicrophone();

        } catch (error) {
            console.error('Diagnosis error:', error);
            results.error = error.message;
        }

        console.log('📊 Diagnosis results:', results);
        return results;
    }

    // متد کمکی برای نمایش راهنمای حل مشکل
    showTroubleshootingGuide() {
        let guide = '🎤 راهنمای حل مشکل میکروفون:\n\n';
        
        if (this.platform.isAndroid) {
            guide += `برای اندروید:
1. تنظیمات > برنامه‌ها > ${document.title || 'این برنامه'}
2. مجوزها > میکروفون را فعال کنید
3. سایر برنامه‌های ضبط صدا را ببندید
4. تماس‌های فعال را قطع کنید
5. برنامه را مجدداً راه‌اندازی کنید

اگر در Chrome:
- آدرس بار > آیکون قفل > میکروفون > اجازه دادن
- chrome://settings/content/microphone

اگر مشکل ادامه دارد:
- گوشی را ری‌استارت کنید
- حافظه کش برنامه را پاک کنید`;
        } else if (this.platform.isIOS) {
            guide += `برای iOS:
1. تنظیمات > حریم خصوصی > میکروفون
2. برنامه را در لیست فعال کنید
3. Safari > تنظیمات > میکروفون

اگر در Safari:
- تنظیمات > Safari > دوربین و میکروفون`;
        } else if (this.platform.isDesktopApp) {
            guide += `برای اپلیکیشن دسکتاپ:
1. تنظیمات ویندوز > حریم خصوصی > میکروفون
2. "اجازه دسترسی برنامه‌ها به میکروفون" را فعال کنید
3. برنامه‌های دیگر که از میکروفون استفاده می‌کنند را ببندید
4. اپلیکیشن را به عنوان Administrator اجرا کنید`;
        } else {
            guide += `برای مرورگر:
1. آیکون قفل کنار آدرس سایت را کلیک کنید
2. میکروفون را "اجازه دادن" کنید
3. صفحه را رفرش کنید`;
        }
        
        guide += `\n\nاگر مشکل ادامه دارد:
- میکروفون را بررسی کنید
- درایور صدا را بروزرسانی کنید
- سیستم را ری‌استارت کنید`;
        
        alert(guide);
    }

    // متد برای مدیریت کلیدهای میانبر
    setupKeyboardShortcuts() {
        document.addEventListener('keydown', (e) => {
            // Ctrl + Space برای شروع/توقف ضبط
            if (e.ctrlKey && e.code === 'Space') {
                e.preventDefault();
                if (this.isRecording) {
                    this.stopRecording();
                } else {
                    this.startRecording();
                }
            }
        });

        // برای موبایل - لمس طولانی دکمه ضبط
        if (this.platform.isMobile) {
            const recordButton = document.getElementById('recordButton');
            if (recordButton) {
                let longPressTimer;
                
                recordButton.addEventListener('touchstart', (e) => {
                    if (!this.isRecording) {
                        longPressTimer = setTimeout(() => {
                            this.startRecording();
                            if (navigator.vibrate) {
                                navigator.vibrate(200);
                            }
                        }, 500);
                    }
                });
                
                recordButton.addEventListener('touchend', () => {
                    clearTimeout(longPressTimer);
                });
                
                recordButton.addEventListener('touchcancel', () => {
                    clearTimeout(longPressTimer);
                });
            }
        }
    }

    // بررسی دسترسی میکروفون با توجه به محدودیت‌های HTTP
    async checkMicrophoneAccess() {
        console.log('🎤 Checking microphone access...');
        
        const protocol = location.protocol;
        const hostname = location.hostname;
        const isSecureContext = window.isSecureContext;
        
        console.log('Environment:', {
            protocol,
            hostname,
            isSecureContext,
            platform: this.platform
        });
        
        // اگر HTTPS یا localhost است، روش معمولی
        if (protocol === 'https:' || hostname === 'localhost' || hostname === '127.0.0.1') {
            return this.requestMicrophonePermission();
        }
        
        // اگر Android App است، سعی کن روش‌های native
        if (this.platform.isAndroidApp || this.platform.isCordova) {
            return this.requestNativeAudioPermission();
        }
        
        // در غیر این صورت، نمایش راهنمای جایگزین
        return this.showAlternativeAudioOptions();
    }
    
    // درخواست مجوز میکروفون در محیط‌های native
    async requestNativeAudioPermission() {
        try {
            console.log('📱 Requesting native audio permission...');
            
            // اگر Cordova plugin موجود است
            if (window.cordova && window.cordova.plugins && window.cordova.plugins.permissions) {
                const permissions = window.cordova.plugins.permissions;
                const permission = permissions.RECORD_AUDIO;
                
                return new Promise((resolve, reject) => {
                    permissions.checkPermission(permission, (status) => {
                        if (status.hasPermission) {
                            console.log('✅ Audio permission already granted');
                            resolve(true);
                        } else {
                            permissions.requestPermission(permission, (status) => {
                                if (status.hasPermission) {
                                    console.log('✅ Audio permission granted');
                                    resolve(true);
                                } else {
                                    console.log('❌ Audio permission denied');
                                    resolve(false);
                                }
                            }, reject);
                        }
                    }, reject);
                });
            }
            
            // تلاش برای getUserMedia حتی در HTTP (ممکن است در برخی WebView ها کار کند)
            try {
                const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
                console.log('✅ Microphone access granted in native app');
                stream.getTracks().forEach(track => track.stop()); // بستن stream فعلی
                return true;
            } catch (error) {
                console.log('❌ Native microphone access failed:', error.message);
                return false;
            }
            
        } catch (error) {
            console.error('Error requesting native audio permission:', error);
            return false;
        }
    }
    
    // نمایش گزینه‌های جایگزین برای ضبط صدا
    showAlternativeAudioOptions() {
        console.log('🔄 Showing alternative audio options...');
        
        const modal = document.createElement('div');
        modal.className = 'audio-alternative-modal';
        modal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h3>🎤 راه‌حل‌های جایگزین ضبط صدا</h3>
                    <button class="close-btn" onclick="this.parentElement.parentElement.parentElement.remove()">×</button>
                </div>
                <div class="modal-body">
                    <div class="alert alert-info">
                        <h4>📋 به دلیل محدودیت‌های امنیتی، میکروفون در HTTP دسترس نیست</h4>
                        <p>لطفاً یکی از راه‌حل‌های زیر را انتخاب کنید:</p>
                    </div>
                    
                    <div class="option-card">
                        <h4>📱 استفاده از اپلیکیشن موبایل</h4>
                        <p>اپلیکیشن اندروید Globgram را نصب کنید</p>
                        <button onclick="window.location.href='${window.location.origin}/app.zip'" class="download-btn">
                            📥 دانلود اپ اندروید
                        </button>
                    </div>
                    
                    <div class="option-card">
                        <h4>🌐 استفاده از HTTPS</h4>
                        <p>سایت را روی سرور HTTPS میزبانی کنید</p>
                        <small>برای توسعه‌دهندگان: از GitHub Pages یا Netlify استفاده کنید</small>
                    </div>
                    
                    <div class="option-card">
                        <h4>🏠 استفاده محلی</h4>
                        <p>فایل‌ها را روی localhost اجرا کنید</p>
                        <button onclick="this.showLocalInstruction()" class="info-btn">
                            📖 راهنمای نصب محلی
                        </button>
                    </div>
                    
                    <div class="option-card">
                        <h4>📁 استفاده از File Input (موقت)</h4>
                        <p>فایل صوتی از گالری انتخاب کنید</p>
                        <input type="file" accept="audio/*" onchange="window.voiceManager?.handleFileUpload(this)" class="file-input">
                    </div>
                </div>
            </div>
        `;
        
        // اضافه کردن CSS
        if (!document.querySelector('#alternative-audio-styles')) {
            const styles = document.createElement('style');
            styles.id = 'alternative-audio-styles';
            styles.textContent = `
                .audio-alternative-modal {
                    position: fixed;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    background: rgba(0,0,0,0.7);
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    z-index: 10000;
                }
                .modal-content {
                    background: white;
                    border-radius: 12px;
                    max-width: 500px;
                    width: 90%;
                    max-height: 80vh;
                    overflow-y: auto;
                    direction: rtl;
                }
                .modal-header {
                    padding: 20px;
                    border-bottom: 1px solid #eee;
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                }
                .modal-body {
                    padding: 20px;
                }
                .option-card {
                    border: 1px solid #ddd;
                    border-radius: 8px;
                    padding: 15px;
                    margin: 15px 0;
                }
                .option-card h4 {
                    margin: 0 0 10px 0;
                    color: #007bff;
                }
                .download-btn, .info-btn {
                    background: #007bff;
                    color: white;
                    border: none;
                    padding: 10px 20px;
                    border-radius: 6px;
                    cursor: pointer;
                    margin-top: 10px;
                }
                .file-input {
                    width: 100%;
                    padding: 10px;
                    border: 2px dashed #007bff;
                    border-radius: 6px;
                    margin-top: 10px;
                }
                .alert-info {
                    background: #d1ecf1;
                    border: 1px solid #bee5eb;
                    border-radius: 6px;
                    padding: 15px;
                    margin-bottom: 20px;
                }
                .close-btn {
                    background: none;
                    border: none;
                    font-size: 24px;
                    cursor: pointer;
                    padding: 0;
                    width: 30px;
                    height: 30px;
                }
            `;
            document.head.appendChild(styles);
        }
        
        document.body.appendChild(modal);
        return false; // نشان می‌دهد که میکروفون دسترس نیست
    }
    
    // مدیریت آپلود فایل صوتی
    handleFileUpload(input) {
        const file = input.files[0];
        if (!file) return;
        
        console.log('📁 File selected:', file.name, file.type, file.size);
        
        // بررسی نوع فایل
        if (!file.type.startsWith('audio/')) {
            alert('لطفا یک فایل صوتی انتخاب کنید (MP3, WAV, M4A, ...)');
            return;
        }
        
        // بررسی اندازه فایل (حداکثر 10 مگابایت)
        const maxSize = 10 * 1024 * 1024; // 10MB
        if (file.size > maxSize) {
            alert('حجم فایل نباید بیشتر از 10 مگابایت باشد');
            return;
        }
        
        // نمایش پیام بارگذاری
        this.showLoadingMessage('در حال پردازش فایل صوتی...');
        
        // پردازش فایل
        this.processUploadedAudio(file);
        
        // بستن modal
        const modal = input.closest('.microphone-alternatives-modal');
        if (modal) modal.remove();
    }
    
    // نمایش پیام بارگذاری
    showLoadingMessage(message) {
        // حذف پیام قبلی
        const existingLoading = document.querySelector('.audio-loading-message');
        if (existingLoading) existingLoading.remove();
        
        const loadingDiv = document.createElement('div');
        loadingDiv.className = 'audio-loading-message';
        loadingDiv.style.cssText = `
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: rgba(0, 0, 0, 0.8);
            color: white;
            padding: 20px 40px;
            border-radius: 10px;
            z-index: 10002;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            text-align: center;
        `;
        
        loadingDiv.innerHTML = `
            <div style="display: flex; align-items: center; gap: 15px;">
                <div style="
                    width: 20px;
                    height: 20px;
                    border: 2px solid #fff;
                    border-top: 2px solid transparent;
                    border-radius: 50%;
                    animation: spin 1s linear infinite;
                "></div>
                <span>${message}</span>
            </div>
            <style>
                @keyframes spin {
                    0% { transform: rotate(0deg); }
                    100% { transform: rotate(360deg); }
                }
            </style>
        `;
        
        document.body.appendChild(loadingDiv);
        
        // حذف خودکار بعد از 5 ثانیه
        setTimeout(() => {
            if (loadingDiv.parentNode) {
                loadingDiv.remove();
            }
        }, 5000);
    }
    
    // پردازش فایل صوتی آپلود شده
    async processUploadedAudio(file) {
        try {
            console.log('🎵 Processing uploaded audio:', file.name);
            
            // تبدیل فایل به AudioBuffer برای اطلاعات بیشتر
            const arrayBuffer = await file.arrayBuffer();
            let duration = 0;
            
            try {
                if (this.audioContext) {
                    const audioBuffer = await this.audioContext.decodeAudioData(arrayBuffer.slice());
                    duration = audioBuffer.duration;
                    console.log('Audio duration:', duration, 'seconds');
                }
            } catch (error) {
                console.warn('Could not decode audio for duration:', error);
            }
            
            // تبدیل به Blob مناسب
            const blob = new Blob([arrayBuffer], { 
                type: file.type || 'audio/webm' 
            });
            
            console.log('Created blob from uploaded file:', {
                originalFile: {
                    name: file.name,
                    type: file.type,
                    size: file.size
                },
                blob: {
                    type: blob.type,
                    size: blob.size
                }
            });
            
            // ایجاد voice message
            const voiceMessage = {
                voiceId: (typeof Utils !== 'undefined' && Utils.generateVoiceId) ? 
                        Utils.generateVoiceId() : 
                        generateVoiceId() || `upload-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
                audioBlob: blob,
                timestamp: Date.now(),
                userEmail: (typeof Utils !== 'undefined' && Utils.getCurrentUser) ? 
                          Utils.getCurrentUser().email : 
                          window.currentUser?.email || 
                          localStorage.getItem('userEmail') || 
                          'guest@example.com',
                userName: (typeof Utils !== 'undefined' && Utils.getCurrentUser) ? 
                         Utils.getCurrentUser().name : 
                         window.currentUser?.name || 
                         localStorage.getItem('userName') || 
                         'مهمان',
                userAvatar: (typeof Utils !== 'undefined' && Utils.getCurrentUser) ? 
                           Utils.getCurrentUser().avatar : 
                           window.currentUser?.avatar || 
                           localStorage.getItem('userAvatar') || 
                           '',
                roomCode: localStorage.getItem('currentRoomCode') || window.connectionManager?.currentRoom,
                fileName: file.name,
                uploaded: true,
                duration: duration * 1000 || 0, // تبدیل به میلی‌ثانیه
                platform: this.platform.isAndroid ? 'android-upload' : 'web-upload'
            };
            
            // Save to database with proper error handling
            if (typeof DatabaseManager !== 'undefined' && DatabaseManager.saveVoice) {
                try {
                    await DatabaseManager.saveVoice({
                        voiceId: voiceMessage.voiceId,
                        blob: voiceMessage.audioBlob,
                        timestamp: voiceMessage.timestamp,
                        roomCode: voiceMessage.roomCode,
                        userEmail: voiceMessage.userEmail,
                        userAvatar: voiceMessage.userAvatar,
                        userName: voiceMessage.userName,
                        duration: voiceMessage.duration,
                        fileName: voiceMessage.fileName,
                        uploaded: true,
                        platform: voiceMessage.platform
                    });
                    console.log('Voice message saved to database');
                } catch (dbError) {
                    console.warn('Could not save to database:', dbError);
                    // Continue without database save
                }
            }
            
            // ذخیره در localStorage برای سازگاری
            try {
                const voiceData = {
                    voiceId: voiceMessage.voiceId,
                    timestamp: voiceMessage.timestamp,
                    userEmail: voiceMessage.userEmail,
                    userName: voiceMessage.userName,
                    userAvatar: voiceMessage.userAvatar,
                    roomCode: voiceMessage.roomCode,
                    fileName: voiceMessage.fileName,
                    uploaded: true,
                    duration: voiceMessage.duration
                };
                
                localStorage.setItem(`voice_${voiceMessage.voiceId}`, JSON.stringify(voiceData));
                console.log('Voice data saved to localStorage');
            } catch (error) {
                console.warn('Could not save to localStorage:', error);
            }
            
            // نمایش در UI
            this.displayUploadedVoiceMessage(voiceMessage);
            
            // ارسال به سایر کاربران با error handling
            if (window.connectionManager && window.connectionManager.currentRoom) {
                try {
                    await window.connectionManager.broadcastAudio(blob, voiceMessage.voiceId);
                    console.log('Uploaded audio broadcasted to other users');
                } catch (broadcastError) {
                    console.warn('Could not broadcast uploaded audio:', broadcastError);
                    this.showWarning('فایل ذخیره شد اما ممکن است به سایرین ارسال نشده باشد');
                }
                
                // به‌روزرسانی تعداد پیام‌ها در localStorage
                if (typeof window.updateRoomMessageCount === 'function') {
                    await window.updateRoomMessageCount(window.connectionManager.currentRoom);
                }
            }
            
            // حذف پیام بارگذاری
            const loadingMsg = document.querySelector('.audio-loading-message');
            if (loadingMsg) loadingMsg.remove();
            
            // نمایش پیام موفقیت
            this.showSuccess('فایل صوتی با موفقیت ارسال شد! 🎉');
            
            console.log('✅ Uploaded audio processed successfully');
            
        } catch (error) {
            console.error('❌ Error processing uploaded audio:', error);
            
            // حذف پیام بارگذاری
            const loadingMsg = document.querySelector('.audio-loading-message');
            if (loadingMsg) loadingMsg.remove();
            
            this.showError('خطا در پردازش فایل صوتی: ' + (error.message || 'خطای نامشخص'));
        }
    }
    
    // نمایش فایل صوتی آپلود شده در UI
    displayUploadedVoiceMessage(voiceMessage) {
        try {
            // بررسی وجود audioBlob
            if (!voiceMessage.audioBlob) {
                throw new Error('audioBlob is missing');
            }
            
            // بررسی معتبر بودن audioBlob
            if (!(voiceMessage.audioBlob instanceof Blob)) {
                throw new Error('audioBlob is not a valid Blob');
            }
            
            const audioUrl = URL.createObjectURL(voiceMessage.audioBlob);
            console.log('Created audio URL for uploaded file:', audioUrl);
            console.log('AudioBlob details:', {
                type: voiceMessage.audioBlob.type,
                size: voiceMessage.audioBlob.size,
                url: audioUrl
            });
            
            // اطمینان از تولید URL معتبر
            if (!audioUrl || audioUrl === 'null' || audioUrl === 'undefined') {
                throw new Error('Failed to create valid audio URL');
            }
            
            // استفاده از ChatRoom برای نمایش (اگر موجود باشد)
            if (window.ChatRoom && typeof window.ChatRoom.displayRecording === 'function') {
                console.log('Using ChatRoom.displayRecording...');
                
                // فراخوانی با پارامترهای صحیح شامل اطلاعات اضافی
                window.ChatRoom.displayRecording(
                    audioUrl,
                    false, // isReceived
                    voiceMessage.timestamp,
                    voiceMessage.voiceId,
                    voiceMessage.userEmail,
                    voiceMessage.userAvatar,
                    voiceMessage.userName,
                    {
                        uploaded: true,
                        fileName: voiceMessage.fileName,
                        duration: voiceMessage.duration,
                        platform: voiceMessage.platform
                    }
                );
                
                console.log('✅ Voice message displayed via ChatRoom.displayRecording');
            } else {
                console.log('ChatRoom.displayRecording not available, using simple display...');
                // نمایش ساده اگر ChatRoom در دسترس نباشد
                this.displaySimpleVoiceMessage(voiceMessage, audioUrl);
                console.log('✅ Voice message displayed via simple display');
            }
            
            // تست URL با تولید یک audio element موقت
            const testAudio = document.createElement('audio');
            testAudio.src = audioUrl;
            testAudio.addEventListener('loadedmetadata', () => {
                console.log('✅ Audio URL is valid and loadable');
            });
            testAudio.addEventListener('error', (error) => {
                console.error('❌ Audio URL test failed:', error);
                this.showError('فایل صوتی آپلود شد اما قابل پخش نیست');
            });
            
        } catch (error) {
            console.error('Error displaying uploaded voice message:', error);
            this.showError('خطا در نمایش فایل صوتی: ' + error.message);
            
            // نمایش اطلاعات debug
            console.log('VoiceMessage debug info:', {
                hasAudioBlob: !!voiceMessage.audioBlob,
                audioBlobType: voiceMessage.audioBlob?.type,
                audioBlobSize: voiceMessage.audioBlob?.size,
                voiceId: voiceMessage.voiceId,
                fileName: voiceMessage.fileName
            });
        }
    }
    
    // نمایش ساده پیام صوتی
    displaySimpleVoiceMessage(voiceMessage, audioUrl) {
        const messagesContainer = document.getElementById('messages') || 
                                document.querySelector('.messages') || 
                                document.querySelector('.chat-messages') ||
                                document.getElementById('recordings'); // backup option
        
        if (!messagesContainer) {
            console.warn('Messages container not found, creating temporary container');
            this.createTemporaryMessagesContainer();
            return;
        }
        
        const messageDiv = document.createElement('div');
        messageDiv.className = 'voice-message sent uploaded';
        messageDiv.style.cssText = `
            margin: 10px 0;
            padding: 15px;
            background: #007bff;
            color: white;
            border-radius: 15px;
            max-width: 80%;
            margin-left: auto;
            display: flex;
            flex-direction: column;
            gap: 8px;
            direction: rtl;
        `;
        
        messageDiv.innerHTML = `
            <div style="display: flex; align-items: center; gap: 10px; font-size: 12px; opacity: 0.9;">
                <span>📁 ${voiceMessage.fileName || 'فایل صوتی'}</span>
                ${voiceMessage.duration ? `<span>${Math.round(voiceMessage.duration / 1000)}s</span>` : ''}
                <span>${new Date(voiceMessage.timestamp).toLocaleTimeString('fa-IR', {hour: '2-digit', minute: '2-digit'})}</span>
            </div>
            <audio controls style="width: 100%; height: 40px;" preload="metadata">
                <source src="${audioUrl}" type="${voiceMessage.audioBlob.type}">
                مرورگر شما از پخش صوت پشتیبانی نمی‌کند.
            </audio>
        `;
        
        // تست audio element
        const audioElement = messageDiv.querySelector('audio');
        if (audioElement) {
            audioElement.addEventListener('loadedmetadata', () => {
                console.log('✅ Audio loaded successfully in UI');
            });
            audioElement.addEventListener('error', (error) => {
                console.error('❌ Audio loading error in UI:', error);
                this.showError('خطا در بارگذاری فایل صوتی');
            });
            audioElement.addEventListener('play', () => {
                console.log('🔊 Audio playback started');
                // متوقف کردن سایر صداها
                document.querySelectorAll('audio').forEach(otherAudio => {
                    if (otherAudio !== audioElement && !otherAudio.paused) {
                        otherAudio.pause();
                    }
                });
            });
        }
        
        // اضافه کردن به container
        messagesContainer.appendChild(messageDiv);
        
        // انیمیشن ورود
        requestAnimationFrame(() => {
            messageDiv.style.opacity = '0';
            messageDiv.style.transform = 'translateY(20px)';
            messageDiv.style.transition = 'all 0.3s ease-out';
            
            requestAnimationFrame(() => {
                messageDiv.style.opacity = '1';
                messageDiv.style.transform = 'translateY(0)';
            });
        });
        
        // اسکرول به پایین
        setTimeout(() => {
            messagesContainer.scrollTop = messagesContainer.scrollHeight;
        }, 100);
        
        console.log('✅ Simple voice message displayed successfully');
    }
    
    // ایجاد container موقت برای پیام‌ها
    createTemporaryMessagesContainer() {
        const tempContainer = document.createElement('div');
        tempContainer.id = 'temp-messages';
        tempContainer.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            width: 300px;
            max-height: 400px;
            overflow-y: auto;
            background: white;
            border: 1px solid #ddd;
            border-radius: 10px;
            padding: 15px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            z-index: 10000;
            direction: rtl;
        `;
        
        tempContainer.innerHTML = `
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; border-bottom: 1px solid #eee; padding-bottom: 10px;">
                <h4 style="margin: 0; color: #333;">📁 فایل‌های آپلود شده</h4>
                <button onclick="this.parentElement.parentElement.remove()" style="background: none; border: none; font-size: 18px; cursor: pointer; color: #999;">×</button>
            </div>
        `;
        
        document.body.appendChild(tempContainer);
        
        // حذف خودکار بعد از 30 ثانیه
        setTimeout(() => {
            if (tempContainer.parentNode) {
                tempContainer.remove();
            }
        }, 30000);
        
        return tempContainer;
    }

    // راهنمای استفاده از HTTPS
    showHTTPSGuide() {
        const modal = document.createElement('div');
        modal.className = 'https-guide-modal';
        modal.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 10001;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        `;
        
        modal.innerHTML = `
            <div style="
                background: white;
                border-radius: 15px;
                padding: 30px;
                max-width: 600px;
                width: 90%;
                max-height: 80vh;
                overflow-y: auto;
                box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            ">
                <h2 style="margin: 0 0 20px 0; color: #333; text-align: center;">🌐 راهنمای استفاده از HTTPS</h2>
                
                <div style="margin-bottom: 20px;">
                    <h3 style="color: #007bff; margin-bottom: 10px;">چرا HTTPS ضروری است؟</h3>
                    <p style="color: #666; line-height: 1.6;">
                        مرورگرهای مدرن برای امنیت، دسترسی به میکروفون و دوربین را فقط در محیط‌های امن (HTTPS) مجاز می‌کنند.
                    </p>
                </div>
                
                <div style="margin-bottom: 20px;">
                    <h3 style="color: #007bff; margin-bottom: 10px;">🚀 راه‌حل‌های سریع:</h3>
                    
                    <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; margin-bottom: 15px;">
                        <h4 style="margin: 0 0 10px 0; color: #333;">1. سرویس‌های رایگان هاستینگ:</h4>
                        <ul style="margin: 0; padding-right: 20px; color: #666;">
                            <li><strong>GitHub Pages:</strong> github.io - رایگان و HTTPS خودکار</li>
                            <li><strong>Netlify:</strong> netlify.app - رایگان و آسان</li>
                            <li><strong>Vercel:</strong> vercel.app - سریع و رایگان</li>
                        </ul>
                    </div>
                    
                    <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; margin-bottom: 15px;">
                        <h4 style="margin: 0 0 10px 0; color: #333;">2. تست محلی با HTTPS:</h4>
                        <p style="margin: 0; color: #666;">
                            <code style="background: #e9ecef; padding: 2px 6px; border-radius: 3px;">
                                npx serve -s . --ssl-cert
                            </code>
                        </p>
                    </div>
                    
                    <div style="background: #f8f9fa; padding: 15px; border-radius: 8px;">
                        <h4 style="margin: 0 0 10px 0; color: #333;">3. Cloudflare (توصیه شده):</h4>
                        <p style="margin: 0; color: #666;">
                            Cloudflare Pages برای هاستینگ رایگان با HTTPS خودکار
                        </p>
                    </div>
                </div>
                
                <div style="text-align: center;">
                    <button onclick="this.closest('.https-guide-modal').remove()" style="
                        background: #007bff;
                        color: white;
                        border: none;
                        padding: 10px 30px;
                        border-radius: 25px;
                        cursor: pointer;
                        font-size: 16px;
                    ">متوجه شدم</button>
                </div>
            </div>
        `;
        
        modal.addEventListener('click', (e) => {
            if (e.target === modal) modal.remove();
        });
        
        document.body.appendChild(modal);
    }
    
    // راهنمای اپ اندروید
    showAndroidAppGuide() {
        const modal = document.createElement('div');
        modal.className = 'android-guide-modal';
        modal.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 10001;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        `;
        
        modal.innerHTML = `
            <div style="
                background: white;
                border-radius: 15px;
                padding: 30px;
                max-width: 600px;
                width: 90%;
                max-height: 80vh;
                overflow-y: auto;
                box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            ">
                <h2 style="margin: 0 0 20px 0; color: #333; text-align: center;">📱 راهنمای اپ اندروید</h2>
                
                <div style="margin-bottom: 20px;">
                    <h3 style="color: #17a2b8; margin-bottom: 10px;">مزایای اپ اندروید:</h3>
                    <ul style="color: #666; line-height: 1.6; padding-right: 20px;">
                        <li>دسترسی کامل به میکروفون بدون محدودیت</li>
                        <li>عملکرد بهتر و سریع‌تر</li>
                        <li>قابلیت کار آفلاین</li>
                        <li>تجربه کاربری بهتر</li>
                    </ul>
                </div>
                
                <div style="margin-bottom: 20px;">
                    <h3 style="color: #17a2b8; margin-bottom: 10px;">🔧 مراحل ساخت اپ:</h3>
                    
                    <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; margin-bottom: 15px;">
                        <h4 style="margin: 0 0 10px 0; color: #333;">1. نصب Android Studio</h4>
                        <p style="margin: 0; color: #666;">
                            از سایت developer.android.com دانلود کنید
                        </p>
                    </div>
                    
                    <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; margin-bottom: 15px;">
                        <h4 style="margin: 0 0 10px 0; color: #333;">2. ایجاد پروژه WebView</h4>
                        <p style="margin: 0; color: #666;">
                            یک پروژه اندروید جدید با WebView ایجاد کنید
                        </p>
                    </div>
                    
                    <div style="background: #f8f9fa; padding: 15px; border-radius: 8px;">
                        <h4 style="margin: 0 0 10px 0; color: #333;">3. تنظیم مجوزها</h4>
                        <p style="margin: 0; color: #666;">
                            مجوز RECORD_AUDIO را در AndroidManifest.xml اضافه کنید
                        </p>
                    </div>
                </div>
                
                <div style="background: #e8f4fd; padding: 15px; border-radius: 8px; margin-bottom: 20px;">
                    <p style="margin: 0; color: #0066cc; text-align: center;">
                        📄 راهنمای کامل در فایل <strong>ANDROID_BUILD_GUIDE.md</strong> موجود است
                    </p>
                </div>
                
                <div style="text-align: center;">
                    <button onclick="this.closest('.android-guide-modal').remove()" style="
                        background: #17a2b8;
                        color: white;
                        border: none;
                        padding: 10px 30px;
                        border-radius: 25px;
                        cursor: pointer;
                        font-size: 16px;
                    ">متوجه شدم</button>
                </div>
            </div>
        `;
        
        modal.addEventListener('click', (e) => {
            if (e.target === modal) modal.remove();
        });
        
        document.body.appendChild(modal);
    }
    
    // راهنمای تنظیمات مرورگر
    showBrowserSettingsGuide() {
        const modal = document.createElement('div');
        modal.className = 'browser-guide-modal';
        modal.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 10001;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        `;
        
        const userAgent = navigator.userAgent.toLowerCase();
        let browserSpecificGuide = '';
        
        if (userAgent.includes('chrome')) {
            browserSpecificGuide = `
                <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; margin-bottom: 15px;">
                    <h4 style="margin: 0 0 10px 0; color: #333;">🔧 Chrome/Edge:</h4>
                    <ol style="margin: 0; padding-right: 20px; color: #666;">
                        <li>روی آیکون قفل کنار آدرس کلیک کنید</li>
                        <li>گزینه "Microphone" را پیدا کنید</li>
                        <li>روی "Allow" کلیک کنید</li>
                        <li>صفحه را refresh کنید</li>
                    </ol>
                </div>
            `;
        } else if (userAgent.includes('firefox')) {
            browserSpecificGuide = `
                <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; margin-bottom: 15px;">
                    <h4 style="margin: 0 0 10px 0; color: #333;">🦊 Firefox:</h4>
                    <ol style="margin: 0; padding-right: 20px; color: #666;">
                        <li>Settings > Privacy & Security</li>
                        <li>Permissions > Microphone > Settings</li>
                        <li>سایت را به لیست مجاز اضافه کنید</li>
                        <li>صفحه را refresh کنید</li>
                    </ol>
                </div>
            `;
        } else {
            browserSpecificGuide = `
                <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; margin-bottom: 15px;">
                    <h4 style="margin: 0 0 10px 0; color: #333;">🌐 مرورگر شما:</h4>
                    <p style="margin: 0; color: #666;">
                        در تنظیمات مرورگر، بخش Privacy یا Permissions را پیدا کرده و دسترسی میکروفون را فعال کنید.
                    </p>
                </div>
            `;
        }
        
        modal.innerHTML = `
            <div style="
                background: white;
                border-radius: 15px;
                padding: 30px;
                max-width: 600px;
                width: 90%;
                max-height: 80vh;
                overflow-y: auto;
                box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            ">
                <h2 style="margin: 0 0 20px 0; color: #333; text-align: center;">🔧 راهنمای تنظیمات مرورگر</h2>
                
                ${browserSpecificGuide}
                
                <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; margin-bottom: 15px;">
                    <h4 style="margin: 0 0 10px 0; color: #333;">📱 اندروید Chrome:</h4>
                    <ol style="margin: 0; padding-right: 20px; color: #666;">
                        <li>تنظیمات > Site settings > Microphone</li>
                        <li>سایت را پیدا کرده و "Allow" کنید</li>
                        <li>یا روی آیکون قفل در آدرس بار کلیک کنید</li>
                    </ol>
                </div>
                
                <div style="background: #fff3cd; padding: 15px; border-radius: 8px; margin-bottom: 20px; border-right: 4px solid #ffc107;">
                    <p style="margin: 0; color: #856404;">
                        <strong>نکته:</strong> اگر باز هم کار نکرد، مرورگر را بسته و دوباره باز کنید.
                    </p>
                </div>
                
                <div style="text-align: center;">
                    <button onclick="this.closest('.browser-guide-modal').remove()" style="
                        background: #007bff;
                        color: white;
                        border: none;
                        padding: 10px 30px;
                        border-radius: 25px;
                        cursor: pointer;
                        font-size: 16px;
                    ">متوجه شدم</button>
                </div>
            </div>
        `;
        
        modal.addEventListener('click', (e) => {
            if (e.target === modal) modal.remove();
        });
        
        document.body.appendChild(modal);
    }
}

// Export VoiceManager to global scope
window.VoiceManager = VoiceManager;
