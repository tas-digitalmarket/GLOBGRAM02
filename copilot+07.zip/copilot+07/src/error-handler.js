// مدیریت مرکزی خطاها و notifications
class ErrorHandler {
    constructor() {
        this.errorCount = 0;
        this.maxErrors = 10;
        this.errorHistory = [];
        this.setupGlobalErrorHandling();
    }

    // تنظیم global error handling
    setupGlobalErrorHandling() {
        // JavaScript errors
        window.addEventListener('error', (event) => {
            this.logError('JavaScript Error', event.error, {
                filename: event.filename,
                lineno: event.lineno,
                colno: event.colno
            });
        });

        // Promise rejections
        window.addEventListener('unhandledrejection', (event) => {
            this.logError('Unhandled Promise Rejection', event.reason);
            event.preventDefault(); // جلوگیری از console error
        });

        // Network errors
        window.addEventListener('offline', () => {
            this.showUserMessage('اتصال اینترنت قطع شد', 'warning');
        });

        window.addEventListener('online', () => {
            this.showUserMessage('اتصال اینترنت برقرار شد', 'success');
        });
    }

    // ثبت خطا
    logError(type, error, context = {}) {
        const errorInfo = {
            type,
            message: error?.message || error,
            stack: error?.stack,
            timestamp: new Date().toISOString(),
            userAgent: navigator.userAgent,
            url: window.location.href,
            context
        };

        // ذخیره در تاریخچه
        this.errorHistory.push(errorInfo);
        if (this.errorHistory.length > 50) {
            this.errorHistory.shift(); // حفظ 50 خطای آخر
        }

        // لاگ در console
        console.error(`[${type}]`, error, context);

        // افزایش شمارنده
        this.errorCount++;

        // در صورت خطاهای زیاد، نمایش warning
        if (this.errorCount > this.maxErrors) {
            this.showUserMessage('خطاهای زیادی رخ داده، لطفاً صفحه را رفرش کنید', 'error');
        }

        // ارسال به analytics (در آینده)
        if (ENV_CONFIG?.FEATURES?.ANALYTICS) {
            this.sendErrorToAnalytics(errorInfo);
        }
    }

    // نمایش پیام به کاربر
    showUserMessage(message, type = 'info', duration = 5000) {
        // حذف پیام‌های قبلی از همین نوع
        const existingToasts = document.querySelectorAll(`.toast.${type}`);
        existingToasts.forEach(toast => toast.remove());

        // ایجاد المنت toast
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.textContent = message;
        
        // استایل
        Object.assign(toast.style, {
            position: 'fixed',
            top: '20px',
            right: '20px',
            padding: '12px 20px',
            borderRadius: '8px',
            color: 'white',
            fontWeight: 'bold',
            zIndex: '10000',
            maxWidth: '300px',
            wordWrap: 'break-word',
            direction: 'rtl',
            fontFamily: 'Arial, sans-serif',
            fontSize: '14px',
            boxShadow: '0 4px 12px rgba(0,0,0,0.3)',
            transform: 'translateX(100%)',
            transition: 'transform 0.3s ease'
        });

        // رنگ بر اساس نوع
        const colors = {
            success: '#4CAF50',
            error: '#F44336', 
            warning: '#FF9800',
            info: '#2196F3'
        };
        toast.style.backgroundColor = colors[type] || colors.info;

        // اضافه کردن به DOM
        document.body.appendChild(toast);

        // انیمیشن ورود
        setTimeout(() => {
            toast.style.transform = 'translateX(0)';
        }, 100);

        // حذف خودکار
        setTimeout(() => {
            toast.style.transform = 'translateX(100%)';
            setTimeout(() => {
                if (toast.parentNode) {
                    toast.parentNode.removeChild(toast);
                }
            }, 300);
        }, duration);

        return toast;
    }

    // مدیریت خطاهای شبکه
    handleNetworkError(error, operation = 'عملیات') {
        console.error('Network Error:', error);
        
        if (!navigator.onLine) {
            this.showUserMessage('اتصال اینترنت موجود نیست', 'error');
            return 'offline';
        }

        if (error.name === 'TimeoutError') {
            this.showUserMessage(`${operation} به دلیل کندی شبکه متوقف شد`, 'warning');
            return 'timeout';
        }

        this.showUserMessage(`خطا در ${operation}، لطفاً دوباره تلاش کنید`, 'error');
        return 'error';
    }

    // مدیریت خطاهای MediaRecorder
    handleMediaError(error, context = '') {
        console.error('Media Error:', error, context);
        
        const errorMessages = {
            'NotAllowedError': 'دسترسی به میکروفون رد شد',
            'NotFoundError': 'میکروفون پیدا نشد',
            'NotSupportedError': 'مرورگر از ضبط صدا پشتیبانی نمی‌کند',
            'SecurityError': 'مشکل امنیتی در دسترسی به میکروفون',
            'AbortError': 'ضبط صدا متوقف شد'
        };

        const message = errorMessages[error.name] || 'خطا در ضبط صدا';
        this.showUserMessage(message, 'error');
        
        this.logError('Media Error', error, { context });
        return error.name;
    }

    // مدیریت خطاهای PeerJS
    handlePeerError(error, context = '') {
        console.error('Peer Error:', error, context);
        
        const errorMessages = {
            'browser-incompatible': 'مرورگر شما پشتیبانی نمی‌شود',
            'disconnected': 'اتصال قطع شد',
            'invalid-id': 'شناسه اتاق نامعتبر است',
            'invalid-key': 'کلید اتصال نامعتبر است',
            'network': 'مشکل شبکه',
            'peer-unavailable': 'کاربر در دسترس نیست',
            'ssl-unavailable': 'اتصال امن موجود نیست',
            'server-error': 'خطای سرور',
            'socket-error': 'خطای اتصال',
            'socket-closed': 'اتصال بسته شد'
        };

        const message = errorMessages[error.type] || 'خطا در برقراری ارتباط';
        this.showUserMessage(message, 'error');
        
        this.logError('Peer Error', error, { context });
        return error.type;
    }

    // ارسال خطا به analytics (پیاده‌سازی آینده)
    sendErrorToAnalytics(errorInfo) {
        // TODO: ارسال به سرویس analytics
        console.log('Analytics Error:', errorInfo);
    }

    // گرفتن آمار خطاها
    getErrorStats() {
        return {
            totalErrors: this.errorCount,
            recentErrors: this.errorHistory.slice(-10),
            errorTypes: this.errorHistory.reduce((acc, error) => {
                acc[error.type] = (acc[error.type] || 0) + 1;
                return acc;
            }, {})
        };
    }

    // پاک کردن تاریخچه خطاها
    clearErrorHistory() {
        this.errorHistory = [];
        this.errorCount = 0;
        console.log('Error history cleared');
    }
}

// ایجاد instance global
window.errorHandler = new ErrorHandler();

// Shortcuts برای استفاده آسان
window.showSuccess = (msg) => window.errorHandler.showUserMessage(msg, 'success');
window.showError = (msg) => window.errorHandler.showUserMessage(msg, 'error');
window.showWarning = (msg) => window.errorHandler.showUserMessage(msg, 'warning');
window.showInfo = (msg) => window.errorHandler.showUserMessage(msg, 'info');
