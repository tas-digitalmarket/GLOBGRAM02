// تنظیمات مشترک پروژه
const CONFIG = {
    STUN_SERVERS: [
        { urls: 'stun:stun.l.google.com:19302' },
        { urls: 'stun:stun.stunprotocol.org:3478' }
    ],
    DEFAULT_AVATAR: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48Y2lyY2xlIGN4PSIxMDAiIGN5PSIxMDAiIHI9IjEwMCIgZmlsbD0iI2UwZTBlMCIvPjxjaXJjbGUgY3g9IjEwMCIgY3k9IjgwIiByPSI0MCIgZmlsbD0iI2JkYmRiZCIvPjxwYXRoIGQ9Ik0xODAsMTgwYzAtNDQtNDAtODAtODAtODBzLTgwLDM2LTgwLDgwIiBmaWxsPSIjYmRiZGJkIi8+PC9zdmc+',
    
    // ⚠️ تنظیمات ایمیل حالا از environment config می‌آید
    get EMAIL_CONFIG() {
        if (typeof ENV_CONFIG !== 'undefined') {
            return {
                publicKey: ENV_CONFIG.EMAIL.PUBLIC_KEY,
                serviceId: ENV_CONFIG.EMAIL.SERVICE_ID,
                templateId: ENV_CONFIG.EMAIL.TEMPLATE_ID
            };
        }
        // Fallback در صورت عدم دسترسی به ENV_CONFIG
        console.warn('⚠️ ENV_CONFIG not loaded, using fallback email config');
        return {
            publicKey: process.env.EMAILJS_PUBLIC_KEY || "demo_key",
            serviceId: process.env.EMAILJS_SERVICE_ID || "demo_service",
            templateId: process.env.EMAILJS_TEMPLATE_ID || "demo_template"
        };
    },
    
    // تنظیمات عمومی
    APP: {
        NAME: 'Globgram',
        VERSION: '1.0.0',
        MAX_RECORDING_TIME: 60000, // 60 seconds
        MAX_RECONNECT_ATTEMPTS: 3,
        HEARTBEAT_INTERVAL: 30000, // 30 seconds
        MAX_FILE_SIZE: 10 * 1024 * 1024, // 10MB
        SUPPORTED_AUDIO_FORMATS: ['audio/webm', 'audio/mp4', 'audio/wav']
    },
    
    // تنظیمات امنیتی
    SECURITY: {
        MAX_LOGIN_ATTEMPTS: 5,
        SESSION_TIMEOUT: 24 * 60 * 60 * 1000, // 24 hours
        VERIFY_CODE_EXPIRY: 10 * 60 * 1000, // 10 minutes
        RATE_LIMIT_WINDOW: 60 * 1000, // 1 minute
        RATE_LIMIT_MAX_REQUESTS: 10
    }
};

// Helper functions
const Utils = {
    generateRoomCode() {
        return Math.floor(100000 + Math.random() * 900000).toString();
    },
    
    generateVoiceId() {
        return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    },
    
    getCurrentUser() {
        try {
            const email = localStorage.getItem('userEmail') || 'guest@example.com';
            const name = localStorage.getItem('userName') || 
                        localStorage.getItem('userEmail')?.split('@')[0] || 
                        'کاربر';
            const avatar = localStorage.getItem('userAvatar') || CONFIG.DEFAULT_AVATAR;
            
            return { email, name, avatar };
        } catch (error) {
            console.error('Error getting current user:', error);
            return {
                email: 'guest@example.com',
                name: 'کاربر',
                avatar: CONFIG.DEFAULT_AVATAR
            };
        }
    },

    // Safe local storage operations
    safeSetItem(key, value) {
        try {
            localStorage.setItem(key, value);
            return true;
        } catch (error) {
            console.error('Error setting localStorage item:', error);
            return false;
        }
    },

    safeGetItem(key, defaultValue = null) {
        try {
            return localStorage.getItem(key) || defaultValue;
        } catch (error) {
            console.error('Error getting localStorage item:', error);
            return defaultValue;
        }
    },

    // Format timestamp for display
    formatTime(timestamp) {
        try {
            return new Date(timestamp).toLocaleString('fa-IR', {
                hour: '2-digit',
                minute: '2-digit',
                day: '2-digit',
                month: '2-digit'
            });
        } catch (error) {
            console.error('Error formatting time:', error);
            return 'نامشخص';
        }
    },

    // Validate email format
    isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }
};
