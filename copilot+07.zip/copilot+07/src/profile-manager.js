class ProfileManager {
    constructor() {
        console.log('ProfileManager: Constructor called');
        this.isInitialized = false;
        
        // انتظار برای آماده شدن DOM
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => this.safeInitialize());
        } else {
            this.safeInitialize();
        }
    }

    safeInitialize() {
        // تأخیر برای اطمینان از بارگذاری کامل
        setTimeout(() => {
            if (document.body && !this.isInitialized) {
                this.initialize();
            } else {
                console.warn('Body not ready, retrying...');
                setTimeout(() => this.safeInitialize(), 1000);
            }
        }, 500);
    }

    initialize() {
        console.log('ProfileManager: Initializing...');
        
        // فقط دکمه profile را پیدا کن و bind کن، profile را نمایش نده
        this.findAndBindProfileButton();
        this.isInitialized = true;
        
        console.log('ProfileManager: Initialized successfully (profile not shown)');
    }

    findAndBindProfileButton() {
        console.log('ProfileManager: Looking for profile button...');
        
        // جستجوی دکمه پروفایل
        let profileButton = this.searchForProfileButton();
        
        if (profileButton) {
            this.setupProfileButton(profileButton);
        } else {
            console.warn('Profile button not found, creating one...');
            this.createProfileButton();
        }
    }

    searchForProfileButton() {
        // جستجو با ID و کلاس
        const selectors = [
            '#openProfileBtn', '#profileButton', '#userProfileBtn',
            '.profile-button', '.user-profile-btn'
        ];

        for (const selector of selectors) {
            const element = document.querySelector(selector);
            if (element) {
                console.log(`Found profile button: ${selector}`);
                return element;
            }
        }

        // جستجو بر اساس محتوا
        const allButtons = document.querySelectorAll('button, a, [role="button"]');
        for (const button of allButtons) {
            const text = button.textContent || button.innerText || '';
            if (text.includes('👤') || text.includes('پروفایل') || text.includes('Profile')) {
                console.log('Found profile button by text:', text);
                return button;
            }
        }

        return null;
    }

    setupProfileButton(button) {
        console.log('Setting up existing profile button...');
        
        if (!button || !button.parentNode) {
            console.error('Invalid button');
            this.createProfileButton();
            return;
        }

        try {
            // حذف event listeners قبلی
            const newButton = button.cloneNode(true);
            button.parentNode.replaceChild(newButton, button);
            
            // تنظیم استایل
            newButton.style.pointerEvents = 'auto';
            newButton.style.cursor = 'pointer';
            newButton.style.zIndex = '1000';
            
            // اضافه کردن event listener
            newButton.onclick = (e) => {
                e.preventDefault();
                e.stopPropagation();
                console.log('Profile button clicked!');
                this.showProfile();
            };
            
            console.log('Profile button setup complete');
        } catch (error) {
            console.error('Error setting up button:', error);
            this.createProfileButton();
        }
    }

    createProfileButton() {
        console.log('Creating new profile button...');
        
        if (!document.body) {
            console.error('Document body not available');
            return;
        }

        try {
            const button = document.createElement('button');
            button.id = 'dynamicProfileBtn';
            button.innerHTML = '👤 پروفایل';
            
            // استایل کامل
            button.style.cssText = `
                position: fixed !important;
                top: 20px !important;
                right: 20px !important;
                z-index: 9999 !important;
                background: #2a5298 !important;
                color: white !important;
                border: none !important;
                padding: 12px 20px !important;
                border-radius: 25px !important;
                cursor: pointer !important;
                font-size: 16px !important;
                box-shadow: 0 4px 12px rgba(0,0,0,0.3) !important;
                pointer-events: auto !important;
            `;
            
            // event handler
            button.onclick = (e) => {
                e.preventDefault();
                console.log('Dynamic profile button clicked!');
                this.showProfile();
            };
            
            // اضافه کردن به صفحه
            document.body.appendChild(button);
            console.log('Dynamic profile button created');
            
        } catch (error) {
            console.error('Error creating button:', error);
        }
    }

    showProfile() {
        console.log('Showing profile...');
        
        try {
            // مخفی کردن محتوای اصلی
            this.hideMainContent();
            
            // نمایش پروفایل
            let profileSection = document.getElementById('profileSection');
            if (!profileSection) {
                this.createProfileSection();
                profileSection = document.getElementById('profileSection');
            }
            
            if (profileSection) {
                profileSection.style.display = 'flex';
                this.loadUserInfo();
                console.log('Profile shown successfully');
            }
            
        } catch (error) {
            console.error('Error showing profile:', error);
            alert('خطا در نمایش پروفایل');
        }
    }

    hideMainContent() {
        const selectors = [
            '#mainContent', 
            '#welcomeContainer', 
            '.container',
            '.welcome-container'
        ];
        
        selectors.forEach(selector => {
            const element = document.querySelector(selector);
            if (element) {
                element.style.display = 'none';
            }
        });
    }

    createProfileSection() {
        if (!document.body) {
            console.error('Cannot create profile section - no body');
            return;
        }

        try {
            // حذف پروفایل قبلی
            const existing = document.getElementById('profileSection');
            if (existing) existing.remove();

            // ایجاد HTML
            const profileHTML = `
                <div id="profileSection" style="
                    position: fixed;
                    top: 0; left: 0; right: 0; bottom: 0;
                    background: rgba(0,0,0,0.8);
                    display: none;
                    justify-content: center;
                    align-items: center;
                    z-index: 10000;
                    padding: 20px;
                ">
                    <div style="
                        background: white;
                        border-radius: 20px;
                        padding: 30px;
                        width: 100%;
                        max-width: 500px;
                        max-height: 90vh;
                        overflow-y: auto;
                    ">
                        <h2 style="text-align: center; color: #2a5298; margin-bottom: 30px;">
                            👤 پروفایل کاربری
                        </h2>
                        
                        <div style="text-align: center; margin-bottom: 30px;">
                            <img id="profileAvatar" 
                                 src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48Y2lyY2xlIGN4PSIxMDAiIGN5PSIxMDAiIHI9IjEwMCIgZmlsbD0iI2UwZTBlMCIvPjxjaXJjbGUgY3g9IjEwMCIgY3k9IjgwIiByPSI0MCIgZmlsbD0iI2JkYmRiZCIvPjxwYXRoIGQ9Ik0xODAsMTgwYzAtNDQtNDAtODAtODAtODBzLTgwLDM2LTgwLDgwIiBmaWxsPSIjYmRiZGJkIi8+PC9zdmc+"
                                 style="width: 100px; height: 100px; border-radius: 50%; border: 3px solid #2a5298;">
                            <br><br>
                            <button id="avatarUploadBtn" style="
                                background: #2a5298; color: white; border: none;
                                padding: 8px 16px; border-radius: 20px; cursor: pointer;
                            ">تغییر تصویر</button>
                        </div>
                        
                        <div style="margin-bottom: 30px;">
                            <p><strong>نام:</strong> <span id="profileName">کاربر</span></p>
                            <p><strong>ایمیل:</strong> <span id="profileEmail">user@example.com</span></p>
                        </div>
                        
                        <button id="backToMainChat" style="
                            background: #6c757d; color: white; border: none;
                            padding: 15px; border-radius: 10px; cursor: pointer;
                            width: 100%; font-size: 16px;
                        ">بازگشت</button>
                    </div>
                </div>
            `;
            
            // اضافه کردن به صفحه
            document.body.insertAdjacentHTML('beforeend', profileHTML);
            
            // bind کردن events
            this.bindProfileEvents();
            
            console.log('Profile section created');
            
        } catch (error) {
            console.error('Error creating profile section:', error);
        }
    }

    bindProfileEvents() {
        // دکمه بازگشت
        const backBtn = document.getElementById('backToMainChat');
        if (backBtn) {
            backBtn.onclick = () => this.hideProfile();
        }

        // دکمه آواتار
        const avatarBtn = document.getElementById('avatarUploadBtn');
        if (avatarBtn) {
            avatarBtn.onclick = () => this.handleAvatarChange();
        }
    }

    hideProfile() {
        const profileSection = document.getElementById('profileSection');
        if (profileSection) {
            profileSection.style.display = 'none';
        }
        
        // نمایش محتوای اصلی
        const mainContent = document.getElementById('mainContent') || 
                           document.querySelector('.container');
        if (mainContent) {
            mainContent.style.display = 'block';
        }
    }

    loadUserInfo() {
        try {
            const user = this.getCurrentUser();
            
            const nameEl = document.getElementById('profileName');
            const emailEl = document.getElementById('profileEmail');
            const avatarEl = document.getElementById('profileAvatar');
            const changeAvatarBtn = document.getElementById('changeAvatarBtn');
            
            if (nameEl) nameEl.textContent = user.name;
            if (emailEl) emailEl.textContent = user.email;
            if (avatarEl) avatarEl.src = user.avatar;
            
            // اضافه کردن event listener برای دکمه تغییر آواتار
            if (changeAvatarBtn) {
                // حذف event listener قبلی
                changeAvatarBtn.replaceWith(changeAvatarBtn.cloneNode(true));
                const newChangeAvatarBtn = document.getElementById('changeAvatarBtn');
                
                newChangeAvatarBtn.onclick = (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    console.log('Change avatar button clicked!');
                    this.handleAvatarChange();
                };
                
                // اطمینان از اینکه دکمه قابل کلیک است
                newChangeAvatarBtn.style.pointerEvents = 'auto';
                newChangeAvatarBtn.style.cursor = 'pointer';
                newChangeAvatarBtn.style.zIndex = '1000';
                
                console.log('✅ Change avatar button event listener added');
            } else {
                console.warn('⚠️ Change avatar button not found');
                
                // Backup: اگر دکمه پیدا نشد، ایجاد کن
                if (!changeAvatarBtn) {
                    console.log('🔧 Creating missing avatar button...');
                    const avatarContainer = document.querySelector('.profile-avatar');
                    if (avatarContainer) {
                        const newBtn = document.createElement('button');
                        newBtn.id = 'changeAvatarBtn';
                        newBtn.className = 'icon-button';
                        newBtn.textContent = '📷';
                        newBtn.title = 'تغییر تصویر پروفایل';
                        
                        newBtn.onclick = (e) => {
                            e.preventDefault();
                            e.stopPropagation();
                            console.log('📷 Backup avatar button clicked!');
                            this.handleAvatarChange();
                        };
                        
                        avatarContainer.appendChild(newBtn);
                        console.log('✅ Backup avatar button created');
                    }
                }
            }
            
        } catch (error) {
            console.error('Error loading user info:', error);
        }
    }

    getCurrentUser() {
        return {
            name: localStorage.getItem('userName') || 'کاربر',
            email: localStorage.getItem('userEmail') || 'user@example.com',
            avatar: localStorage.getItem('userAvatar') || 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1zbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48Y2lyY2xlIGN4PSIxMDAiIGN5PSIxMDAiIHI9IjEwMCIgZmlsbD0iI2UwZTBlMCIvPjxjaXJjbGUgY3g9IjEwMCIgY3k9IjgwIiByPSI0MCIgZmlsbD0iI2JkYmRiZCIvPjxwYXRoIGQ9Ik0xODAsMTgwYzAtNDQtNDAtODAtODAtODBzLTgwLDM2LTgwLDgwIiBmaWxsPSIjYmRiZGJkIi8+PC9zdmc+'
        };
    }

    handleAvatarChange() {
        console.log('📷 Avatar change requested');
        
        try {
            const input = document.createElement('input');
            input.type = 'file';
            input.accept = 'image/*';
            input.style.display = 'none';
            
            input.onchange = (e) => {
                const file = e.target.files[0];
                if (file) {
                    // بررسی اندازه فایل (حداکثر 5MB)
                    if (file.size > 5 * 1024 * 1024) {
                        if (window.showError) {
                            window.showError('حجم تصویر نباید بیشتر از 5 مگابایت باشد');
                        } else {
                            alert('حجم تصویر نباید بیشتر از 5 مگابایت باشد');
                        }
                        return;
                    }
                    
                    // بررسی نوع فایل
                    if (!file.type.startsWith('image/')) {
                        if (window.showError) {
                            window.showError('لطفاً یک فایل تصویری انتخاب کنید');
                        } else {
                            alert('لطفاً یک فایل تصویری انتخاب کنید');
                        }
                        return;
                    }
                    
                    // نمایش loading
                    const avatarEl = document.getElementById('profileAvatar');
                    const changeBtn = document.getElementById('changeAvatarBtn');
                    
                    if (changeBtn) {
                        changeBtn.textContent = '⏳';
                        changeBtn.disabled = true;
                    }
                    
                    const reader = new FileReader();
                    reader.onload = (e) => {
                        try {
                            if (avatarEl) {
                                avatarEl.src = e.target.result;
                                localStorage.setItem('userAvatar', e.target.result);
                                console.log('✅ Avatar updated successfully');
                                
                                if (window.showSuccess) {
                                    window.showSuccess('تصویر پروفایل با موفقیت تغییر کرد');
                                }
                            }
                        } catch (error) {
                            console.error('Error updating avatar:', error);
                            if (window.showError) {
                                window.showError('خطا در تغییر تصویر پروفایل');
                            }
                        } finally {
                            // بازگردانی دکمه
                            if (changeBtn) {
                                changeBtn.textContent = '📷';
                                changeBtn.disabled = false;
                            }
                        }
                    };
                    
                    reader.onerror = () => {
                        console.error('Error reading file');
                        if (window.showError) {
                            window.showError('خطا در خواندن فایل');
                        }
                        
                        // بازگردانی دکمه
                        if (changeBtn) {
                            changeBtn.textContent = '📷';
                            changeBtn.disabled = false;
                        }
                    };
                    
                    reader.readAsDataURL(file);
                }
            };
            
            // اضافه کردن به DOM موقتی و کلیک
            document.body.appendChild(input);
            input.click();
            
            // حذف از DOM بعد از استفاده
            setTimeout(() => {
                if (input.parentNode) {
                    input.parentNode.removeChild(input);
                }
            }, 1000);
            
        } catch (error) {
            console.error('Error in handleAvatarChange:', error);
            if (window.showError) {
                window.showError('خطا در باز کردن انتخابگر فایل');
            }
        }
    }
}

// تنظیم global
window.ProfileManager = ProfileManager;

// Debug: تست دکمه تغییر آواتار
        console.log('🔍 Debugging avatar button...');
        setTimeout(() => {
            const avatarBtn = document.getElementById('changeAvatarBtn');
            if (avatarBtn) {
                console.log('✅ Avatar button found');
                console.log('Button properties:', {
                    tagName: avatarBtn.tagName,
                    className: avatarBtn.className,
                    style: avatarBtn.style.cssText,
                    onclick: !!avatarBtn.onclick,
                    disabled: avatarBtn.disabled
                });
            } else {
                console.log('❌ Avatar button NOT found');
            }
        }, 2000);