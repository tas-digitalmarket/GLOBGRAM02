// ویژگی‌های اضافی voice-manager.js برای کار با localhost Secure Context

// اضافه کردن این متدها به کلاس VoiceManager

// تشخیص Secure Context بهتر
detectSecureContext() {
    const isSecureContext = window.isSecureContext;
    const isLocalhost = location.hostname === 'localhost' || location.hostname === '127.0.0.1';
    const isHTTPS = location.protocol === 'https:';
    const isFile = location.protocol === 'file:';
    
    // در Chrome، localhost روی HTTP هم Secure Context محسوب می‌شود
    const isEffectivelySecure = isSecureContext || (isLocalhost && location.protocol === 'http:');
    
    console.log('🔐 Secure Context Analysis:', {
        isSecureContext,
        isLocalhost,
        isHTTPS,
        isFile,
        isEffectivelySecure,
        protocol: location.protocol,
        hostname: location.hostname,
        href: location.href
    });
    
    return {
        isSecureContext,
        isLocalhost,
        isHTTPS,
        isFile,
        isEffectivelySecure,
        canUseGetUserMedia: isEffectivelySecure && !!navigator.mediaDevices?.getUserMedia
    };
}

// بهبود متد startRecording برای کار با localhost
async startRecording() {
    if (this.isRecording) {
        console.log('⚠️ Already recording');
        return;
    }

    if (!window.connectionManager?.currentRoom) {
        this.showError('برای ضبط صدا ابتدا وارد اتاق شوید');
        return;
    }

    console.log('🎤 Starting recording process...');
    
    // بررسی Secure Context
    const secureContext = this.detectSecureContext();
    
    if (!secureContext.canUseGetUserMedia) {
        console.error('❌ getUserMedia not available - not in secure context');
        
        if (this.platform.isAndroidApp && window.AndroidAudio) {
            console.log('🤖 Trying Android native recording...');
            return this.startAndroidNativeRecording();
        } else {
            this.showNotSecureContextWarning();
            return;
        }
    }

    try {
        // تلاش برای دریافت مجوز و شروع ضبط
        await this.requestPermissions();
        await this.initializeRecording();
        
    } catch (error) {
        console.error('❌ Recording failed:', error);
        this.handleRecordingError(error);
    }
}

// متد جدید برای مدیریت خطاهای Secure Context
showNotSecureContextWarning() {
    const message = `🔐 محیط امن مورد نیاز

برای استفاده از میکروفون، نیاز به محیط امن (Secure Context) است.

وضعیت فعلی:
• آدرس: ${location.href}
• پروتکل: ${location.protocol}
• Secure Context: ${window.isSecureContext ? 'بله' : 'خیر'}

راه‌حل‌ها:
1. استفاده از https://
2. استفاده از localhost
3. استفاده از اپلیکیشن موبایل`;

    if (window.showWarning) {
        window.showWarning(message);
    } else {
        alert(message);
    }
}

// بهبود متد requestPermissions
async requestPermissions() {
    console.log('🔐 Requesting microphone permissions...');
    
    // روش 1: Android App مجوزها
    if (this.platform.isAndroidApp || this.platform.requiresPermissionRequest) {
        const granted = await this.requestAndroidAppPermissions();
        if (!granted) {
            throw new Error('Android permission denied');
        }
    }

    // روش 2: Web API
    if (!this.stream) {
        const constraints = this.getConstraintsForPlatform();
        console.log('🎤 Requesting getUserMedia with constraints:', constraints);
        
        try {
            this.stream = await navigator.mediaDevices.getUserMedia(constraints);
            console.log('✅ getUserMedia successful, stream:', this.stream);
            
            // لاگ در اپلیکیشن اندروید
            if (window.AndroidAudio?.logDebug) {
                window.AndroidAudio.logDebug('getUserMedia successful');
            }
            
        } catch (error) {
            console.error('❌ getUserMedia failed:', error);
            
            // لاگ خطا در اپلیکیشن اندروید
            if (window.AndroidAudio?.logDebug) {
                window.AndroidAudio.logDebug('getUserMedia failed: ' + error.message);
            }
            
            throw error;
        }
    }
}

// بهبود متد getConstraintsForPlatform
getConstraintsForPlatform() {
    const secureContext = this.detectSecureContext();
    
    let constraints = {
        audio: {
            echoCancellation: true,
            noiseSuppression: true,
            autoGainControl: true,
            channelCount: 1
        }
    };

    // تنظیمات خاص برای محیط‌های مختلف
    if (this.platform.isAndroidApp || this.platform.isWebView) {
        // تنظیمات محافظه‌کارانه برای Android WebView
        constraints.audio = {
            ...constraints.audio,
            sampleRate: 16000,
            echoCancellation: false, // ممکن است مشکل ایجاد کند
            noiseSuppression: false
        };
    } else if (secureContext.isLocalhost) {
        // تنظیمات بهتر برای localhost
        constraints.audio = {
            ...constraints.audio,
            sampleRate: 44100
        };
    }

    console.log('🔧 Audio constraints for platform:', constraints);
    return constraints;
}

// متد جدید برای تست Secure Context
async testSecureContext() {
    const secureContext = this.detectSecureContext();
    
    console.log('🧪 Testing Secure Context and Media Devices...');
    
    const result = {
        secureContext: secureContext,
        mediaDevicesAvailable: !!navigator.mediaDevices,
        getUserMediaAvailable: !!(navigator.mediaDevices?.getUserMedia),
        androidInterface: !!window.AndroidAudio,
        testResult: null,
        error: null
    };

    if (secureContext.canUseGetUserMedia) {
        try {
            // تست کوتاه getUserMedia
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            stream.getTracks().forEach(track => track.stop());
            result.testResult = 'SUCCESS';
            console.log('✅ Secure Context test passed');
        } catch (error) {
            result.error = error.message;
            result.testResult = 'FAILED';
            console.error('❌ Secure Context test failed:', error);
        }
    } else {
        result.testResult = 'NOT_SECURE';
        result.error = 'Not in secure context';
        console.log('⚠️ Not in secure context');
    }

    // لاگ در اپلیکیشن اندروید
    if (window.AndroidAudio?.logDebug) {
        window.AndroidAudio.logDebug('Secure Context test: ' + JSON.stringify(result, null, 2));
    }

    return result;
}

// افزودن به constructor کلاس VoiceManager
constructor() {
    // ... existing code ...
    
    // تست Secure Context در شروع
    this.testSecureContext().then(result => {
        console.log('🔐 Initial Secure Context test:', result);
        
        if (result.testResult !== 'SUCCESS' && this.platform.isAndroidApp) {
            console.log('⚠️ getUserMedia not working, will rely on Android interface');
        }
    });
}

// متد کمکی برای نمایش وضعیت فنی
showTechnicalStatus() {
    const secureContext = this.detectSecureContext();
    const platform = this.platform;
    
    const status = `
🔧 وضعیت فنی سیستم

محیط:
• Platform: ${platform.isAndroid ? 'Android' : 'Other'}
• WebView: ${platform.isWebView ? 'بله' : 'خیر'}
• App: ${platform.isAndroidApp ? 'بله' : 'خیر'}

امنیت:
• Secure Context: ${secureContext.isSecureContext ? 'بله' : 'خیر'}
• Localhost: ${secureContext.isLocalhost ? 'بله' : 'خیر'}
• HTTPS: ${secureContext.isHTTPS ? 'بله' : 'خیر'}
• Can Use Microphone: ${secureContext.canUseGetUserMedia ? 'بله' : 'خیر'}

API ها:
• MediaDevices: ${!!navigator.mediaDevices ? 'موجود' : 'ناموجود'}
• getUserMedia: ${!!navigator.mediaDevices?.getUserMedia ? 'موجود' : 'ناموجود'}
• AndroidAudio: ${!!window.AndroidAudio ? 'موجود' : 'ناموجود'}

آدرس:
• URL: ${location.href}
• Origin: ${location.origin}
    `;
    
    if (window.showInfo) {
        window.showInfo(status);
    } else {
        alert(status);
    }
}

// اصلاح متد handleRecordingError برای مدیریت بهتر خطاها
handleRecordingError(error) {
    console.error('🚨 Recording error:', error);
    
    let userMessage = '';
    let technicalInfo = `خطا: ${error.name} - ${error.message}`;
    
    switch (error.name) {
        case 'NotAllowedError':
        case 'PermissionDeniedError':
            userMessage = 'دسترسی به میکروفون رد شد. لطفاً مجوز میکروفون را در تنظیمات برنامه فعال کنید.';
            break;
            
        case 'NotFoundError':
            userMessage = 'میکروفون یافت نشد. مطمئن شوید دستگاه شما میکروفون دارد.';
            break;
            
        case 'NotReadableError':
        case 'AbortError':
            userMessage = 'میکروفون در حال استفاده توسط برنامه دیگر است. لطفاً سایر برنامه‌ها را ببندید.';
            break;
            
        case 'NotSupportedError':
            const secureContext = this.detectSecureContext();
            if (!secureContext.isEffectivelySecure) {
                userMessage = 'برای استفاده از میکروفون، نیاز به محیط امن (HTTPS یا localhost) است.';
            } else {
                userMessage = 'مرورگر شما از ضبط صدا پشتیبانی نمی‌کند.';
            }
            break;
            
        case 'OverconstrainedError':
            userMessage = 'تنظیمات صوتی با دستگاه شما سازگار نیست.';
            break;
            
        default:
            userMessage = 'خطای غیرمنتظره در ضبط صدا رخ داد.';
    }
    
    // نمایش خطا به کاربر
    const fullMessage = `${userMessage}

${technicalInfo}

برای حل مشکل:
1. مجوز میکروفون را در تنظیمات بررسی کنید
2. اپلیکیشن را ببندید و دوباره باز کنید
3. گوشی را restart کنید`;

    if (this.platform.isAndroidApp && window.AndroidAudio?.showToast) {
        window.AndroidAudio.showToast(userMessage);
        
        if (window.AndroidAudio.logDebug) {
            window.AndroidAudio.logDebug('Recording error: ' + technicalInfo);
        }
    } else {
        if (window.showError) {
            window.showError(fullMessage);
        } else {
            alert(fullMessage);
        }
    }

    // پیشنهاد راه‌حل‌های جایگزین
    this.showAlternativeOptions(error);
}

// برای دسترسی global
window.testSecureContext = () => {
    if (window.voiceManager) {
        return window.voiceManager.testSecureContext();
    }
};

window.showTechnicalStatus = () => {
    if (window.voiceManager) {
        window.voiceManager.showTechnicalStatus();
    }
};
