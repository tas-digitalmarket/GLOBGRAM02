// تست تشخیص محیط Android App
function testAndroidEnvironment() {
    console.log('🔍 Testing Android Environment Detection...');
    
    const platform = {
        userAgent: navigator.userAgent.toLowerCase(),
        isAndroid: /android/.test(navigator.userAgent.toLowerCase()),
        isWebView: /wv/.test(navigator.userAgent.toLowerCase()),
        isCordova: !!window.cordova,
        isApp: document.URL.indexOf('http://') === -1 && document.URL.indexOf('https://') === -1,
        hasAndroidInterface: !!window.AndroidAudio,
        hasPermissionsAPI: !!(navigator.permissions),
        hasMediaDevices: !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia)
    };
    
    console.log('📊 Platform Detection Results:', platform);
    
    // نمایش نتایج در UI
    const results = `
🔍 محیط تشخیص داده شده:

📱 Android: ${platform.isAndroid ? '✅' : '❌'}
🌐 WebView: ${platform.isWebView ? '✅' : '❌'}  
📦 Cordova: ${platform.isCordova ? '✅' : '❌'}
🏠 App Mode: ${platform.isApp ? '✅' : '❌'}
🔗 Android Interface: ${platform.hasAndroidInterface ? '✅' : '❌'}
🔐 Permissions API: ${platform.hasPermissionsAPI ? '✅' : '❌'}
🎤 Media Devices: ${platform.hasMediaDevices ? '✅' : '❌'}

📋 User Agent: ${platform.userAgent}

${platform.isApp ? '🎉 در حالت اپلیکیشن اجرا می‌شود' : '🌐 در مرورگر اجرا می‌شود'}
    `;
    
    if (window.showInfo) {
        window.showInfo(results);
    } else {
        alert(results);
    }
    
    return platform;
}

// اجرای تست در صورت لود شدن
if (typeof window !== 'undefined') {
    window.testAndroidEnvironment = testAndroidEnvironment;
    
    // تست خودکار غیرفعال شد
    // setTimeout(() => {
    //     console.log('🚀 Running automatic Android environment test...');
    //     testAndroidEnvironment();
    // }, 2000);
}
