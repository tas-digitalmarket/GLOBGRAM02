class Auth {
    constructor() {
        console.log('Auth constructor called');
        this.emailService = new EmailService();
        console.log('EmailService initialized:', this.emailService);
        this.initEventListeners();
    }

    initEventListeners() {
        console.log('Auth: Setting up event listeners');
        
        // بجای انتظار برای DOMContentLoaded، مستقیماً event listener اضافه می‌کنیم
        this.bindAuthEvents();
        
        // همچنین یک بار دیگر بعد از نمایش auth container
        document.addEventListener('DOMContentLoaded', () => {
            console.log('Auth: DOM loaded, trying to bind events again');
            setTimeout(() => this.bindAuthEvents(), 100);
        });
    }

    bindAuthEvents() {
        const sendCodeBtn = document.getElementById('sendCodeBtn');
        const verifyBtn = document.getElementById('verifyBtn');
        
        console.log('Auth: Binding events - sendCodeBtn:', !!sendCodeBtn, 'verifyBtn:', !!verifyBtn);
        
        if (sendCodeBtn) {
            // حذف event listener قبلی
            sendCodeBtn.replaceWith(sendCodeBtn.cloneNode(true));
            const newSendBtn = document.getElementById('sendCodeBtn');
            
            newSendBtn.onclick = async (e) => {
                e.preventDefault();
                console.log('Send code button clicked!');
                await this.sendVerificationCode();
            };
            console.log('Send code button event bound successfully');
        }

        if (verifyBtn) {
            verifyBtn.replaceWith(verifyBtn.cloneNode(true));
            const newVerifyBtn = document.getElementById('verifyBtn');
            
            newVerifyBtn.onclick = async (e) => {
                e.preventDefault();
                console.log('Verify button clicked!');
                await this.verifyCode();
            };
            console.log('Verify button event bound successfully');
        }
        
        // Enter key handling for verify code input
        const verifyCodeInput = document.getElementById('verifyCode');
        if (verifyCodeInput) {
            verifyCodeInput.onkeypress = async (e) => {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    await this.verifyCode();
                }
            };
        }
    }

    // متد جدید برای bind کردن events بعد از نمایش auth
    bindEventsAfterShow() {
        console.log('Auth: Binding events after auth container is shown');
        setTimeout(() => {
            this.bindAuthEvents();
        }, 100);
    }

    async sendVerificationCode() {
        console.log('Auth: sendVerificationCode called');
        const emailInput = document.getElementById('emailInput');
        if (!emailInput) {
            console.error('Email input not found');
            this.showError('عنصر ورودی ایمیل یافت نشد');
            return;
        }

        const email = emailInput.value.trim();
        console.log('Auth: Email entered:', email);
        
        if (!this.validateEmail(email)) {
            this.showError('لطفا یک ایمیل معتبر وارد کنید');
            return;
        }

        try {
            const sendCodeBtn = document.getElementById('sendCodeBtn');
            if (sendCodeBtn) {
                sendCodeBtn.disabled = true;
                sendCodeBtn.textContent = 'در حال ارسال...';
            }

            // Check if email service is available
            if (!this.emailService || typeof this.emailService.sendVerificationCode !== 'function') {
                throw new Error('سرویس ایمیل در دسترس نیست');
            }

            console.log('Auth: Sending verification code...');
            const verifyCode = await this.emailService.sendVerificationCode(email);
            console.log('Auth: Verification code sent:', verifyCode);
            
            // ذخیره کد در localStorage برای مقایسه
            localStorage.setItem('tempVerifyCode', verifyCode);
            localStorage.setItem('tempUserEmail', email);
            
            // Save to database with error handling
            if (typeof DatabaseManager !== 'undefined' && DatabaseManager.saveUser) {
                try {
                    await DatabaseManager.saveUser({
                        email: email,
                        verifyCode: verifyCode,
                        verified: false,
                        timestamp: Date.now()
                    });
                } catch (dbError) {
                    console.warn('Could not save user to database:', dbError);
                    // Continue without database save
                }
            }

            const verifySection = document.getElementById('verifySection');
            if (verifySection) {
                verifySection.style.display = 'block';
            }
            
            this.showSuccess('کد تایید به ایمیل شما ارسال شد');
   
        } catch (error) {
            console.error('خطا در ارسال کد:', error);
            this.showError(error.message || 'خطا در ارسال کد. لطفا دوباره تلاش کنید.');
        } finally {
            const sendCodeBtn = document.getElementById('sendCodeBtn');
            if (sendCodeBtn) {
                sendCodeBtn.disabled = false;
                sendCodeBtn.textContent = 'ارسال کد';
            }
        }
    }

    async verifyCode() {
        console.log('Auth: verifyCode called');
        const emailInput = document.getElementById('emailInput');
        const verifyCodeInput = document.getElementById('verifyCode');
        
        if (!emailInput || !verifyCodeInput) {
            console.error('Required inputs not found');
            return;
        }

        const email = emailInput.value.trim();
        const enteredCode = verifyCodeInput.value.trim();
       
        console.log('Auth: Email:', email);
        console.log('Auth: Entered code:', enteredCode);
        
        if (!enteredCode) {
            alert('لطفا کد تایید را وارد کنید');
            return;
        }

        try {
            // بررسی کد از localStorage
            const savedCode = localStorage.getItem('tempVerifyCode');
            const savedEmail = localStorage.getItem('tempUserEmail');
            
            console.log('Auth: Saved code:', savedCode);
            console.log('Auth: Saved email:', savedEmail);
            
            // بررسی کد از دیتابیس
            const user = await DatabaseManager.getUser(email);
            console.log('Auth: User from database:', user);
            
            // مقایسه کد (از localStorage یا دیتابیس)
            const isCodeValid = (savedCode && savedCode === enteredCode) || 
                               (user && user.verifyCode && user.verifyCode === enteredCode);
            
            console.log('Auth: Code validation result:', isCodeValid);
            
            if (isCodeValid && (savedEmail === email || (user && user.email === email))) {
                console.log('Auth: Code verified successfully');
                
                // ذخیره کاربر تایید شده
                await DatabaseManager.saveUser({
                    email: email,
                    verifyCode: enteredCode,
                    verified: true,
                    lastLogin: Date.now(),
                    userName: email.split('@')[0]
                });
                
                // تنظیم localStorage با اطلاعات کامل
                localStorage.setItem('userEmail', email);
                localStorage.setItem('userName', email.split('@')[0]);
                localStorage.setItem('userVerified', 'true');
                localStorage.setItem('loginTimestamp', Date.now().toString());
                
                // پاک کردن temporary data
                localStorage.removeItem('tempVerifyCode');
                localStorage.removeItem('tempUserEmail');
                
                // انتقال به صفحه اصلی
                const authContainer = document.getElementById('authContainer');
                const mainContent = document.getElementById('mainContent');
                
                if (authContainer) authContainer.style.display = 'none';
                if (mainContent) mainContent.style.display = 'block';
                
                // Dispatch authSuccess event
                console.log('Auth: Dispatching authSuccess event');
                const authSuccessEvent = new CustomEvent('authSuccess', {
                    detail: { email: email, userName: email.split('@')[0] }
                });
                window.dispatchEvent(authSuccessEvent);
                
                // راه‌اندازی ProfileManager بعد از ورود
                if (typeof ProfileManager !== 'undefined') {
                    setTimeout(() => {
                        window.profileManager = new ProfileManager();
                    }, 100);
                }
                
                alert('با موفقیت وارد شدید!');
                
            } else {
                console.log('Auth: Code verification failed');
                alert('کد وارد شده صحیح نیست. لطفا دوباره بررسی کنید.');
            }
        } catch (error) {
            console.error('خطا در تایید کد:', error);
            alert('خطا در تایید کد. لطفا دوباره تلاش کنید.');
        }
    }

    validateEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    static async checkUserSession() {
        const savedEmail = localStorage.getItem('userEmail');
        const userVerified = localStorage.getItem('userVerified');
        const loginTimestamp = localStorage.getItem('loginTimestamp');
        
        console.log('Auth: Checking user session:', {
            email: savedEmail,
            verified: userVerified,
            loginTime: loginTimestamp
        });
        
        if (savedEmail && userVerified === 'true') {
            const user = await DatabaseManager.getUser(savedEmail);
            return user && user.verified ? user : null;
        }
        return null;
    }

    // متد بهبود یافته logout که فقط در صورت لزوم session را پاک می‌کند
    static logout(force = false) {
        if (force || confirm('آیا مطمئن هستید که می‌خواهید خارج شوید؟')) {
            console.log('Auth: Logging out user');
            
            // پاک کردن اطلاعات session
            localStorage.removeItem('userEmail');
            localStorage.removeItem('userName');
            localStorage.removeItem('userAvatar');
            localStorage.removeItem('userVerified');
            localStorage.removeItem('loginTimestamp');
            localStorage.removeItem('currentRoomCode');
            localStorage.removeItem('tempVerifyCode');
            localStorage.removeItem('tempUserEmail');
            
            // انتقال به صفحه اصلی
            window.location.href = 'index.html';
        }
    }

    // متد جدید برای بررسی اعتبار session
    static isSessionValid() {
        const userEmail = localStorage.getItem('userEmail');
        const userVerified = localStorage.getItem('userVerified');
        const loginTimestamp = localStorage.getItem('loginTimestamp');
        
        if (!userEmail || userVerified !== 'true' || !loginTimestamp) {
            return false;
        }
        
        // بررسی انقضای session (مثلاً 30 روز)
        const sessionAge = Date.now() - parseInt(loginTimestamp);
        const maxSessionAge = 30 * 24 * 60 * 60 * 1000; // 30 روز
        
        return sessionAge < maxSessionAge;
    }

    // Helper methods for consistent message display
    showError(message) {
        if (window.errorHandler && typeof window.errorHandler.showUserMessage === 'function') {
            window.errorHandler.showUserMessage(message, 'error');
        } else {
            alert('❌ ' + message);
        }
    }

    showSuccess(message) {
        if (window.errorHandler && typeof window.errorHandler.showUserMessage === 'function') {
            window.errorHandler.showUserMessage(message, 'success');
        } else {
            alert('✅ ' + message);
        }
    }

    showWarning(message) {
        if (window.errorHandler && typeof window.errorHandler.showUserMessage === 'function') {
            window.errorHandler.showUserMessage(message, 'warning');
        } else {
            alert('⚠️ ' + message);
        }
    }
}

window.Auth = Auth;
