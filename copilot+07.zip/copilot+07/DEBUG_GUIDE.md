# 🔍 راهنمای تشخیص مشکل صفحه سفید

## مشکل: صفحه سفید هنگام کلیک روی دکمه میکروفون

### احتمالات:
1. **JavaScript Error** - کد crash می‌کند
2. **Permission Block** - WebView مجوز نمی‌دهد
3. **Secure Context** - محیط ناامن است
4. **WebView Settings** - تنظیمات اشتباه

## 🚨 تست اولیه (مهم!)

### گام 1: تست فایل ساده
1. فایل `debug-microphone-test.html` را در اپلیکیشن بارگذاری کنید
2. روی "تست ساده" کلیک کنید
3. خروجی را بررسی کنید

### گام 2: بررسی LogCat اندروید
```bash
adb logcat | grep -i "GlobgramMicrophone\|WebView\|getUserMedia\|permission"
```

## 🔧 راه‌حل‌های احتمالی:

### A) اگر صفحه تست ساده هم سفید شد:
**مشکل در WebView است**

#### راه‌حل:
```java
// در MainActivity
WebView.setWebContentsDebuggingEnabled(true);

webView.setWebViewClient(new WebViewClient() {
    @Override
    public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
        Log.e("WebView", "Error: " + error.getDescription());
    }
});
```

### B) اگر تست ساده کار کرد ولی میکروفون سفید شد:
**مشکل در getUserMedia است**

#### بررسی کنید:
- ✅ `window.isSecureContext` = true؟
- ✅ `navigator.mediaDevices` موجود؟
- ✅ مجوز `RECORD_AUDIO` در Manifest؟
- ✅ `onPermissionRequest` پیاده‌سازی شده؟

### C) اگر Secure Context = false:
**باید از localhost استفاده کنید**

#### راه‌حل سریع:
```java
// به جای file://
webView.loadUrl("file:///android_asset/debug-microphone-test.html");

// از localhost استفاده کنید:
webView.loadUrl("http://localhost:8080/debug-microphone-test.html");
```

## 🎯 MainActivity کامل و تضمینی:

```java
public class MainActivity extends AppCompatActivity {
    private WebView webView;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        // Debug mode
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            WebView.setWebContentsDebuggingEnabled(true);
        }
        
        checkPermissions();
        setupWebView();
    }
    
    private void checkPermissions() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) 
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, 
                new String[]{Manifest.permission.RECORD_AUDIO}, 1001);
        }
    }
    
    private void setupWebView() {
        webView = findViewById(R.id.webview);
        
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(true);
        
        // کلیدی: WebChromeClient
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(PermissionRequest request) {
                Log.d("WebView", "Permission request: " + Arrays.toString(request.getResources()));
                
                for (String resource : request.getResources()) {
                    if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)) {
                        Log.d("WebView", "Granting audio permission");
                        request.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
                        return;
                    }
                }
                request.deny();
            }
        });
        
        // Debug WebViewClient
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                Log.d("WebView", "Page loaded: " + url);
            }
            
            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                Log.e("WebView", "Error: " + error.getDescription());
            }
        });
        
        // بارگذاری صفحه تست
        webView.loadUrl("file:///android_asset/debug-microphone-test.html");
    }
}
```

## 📋 چک‌لیست:

- [ ] فایل `debug-microphone-test.html` در پوشه `assets` قرار گرفته؟
- [ ] مجوز `RECORD_AUDIO` در `AndroidManifest.xml` اضافه شده؟
- [ ] `onPermissionRequest` پیاده‌سازی شده؟
- [ ] `WebView debugging` فعال شده؟
- [ ] LogCat را بررسی کرده‌اید؟

## 🚀 گام بعدی:
1. فایل تست ساده را اجرا کنید
2. LogCat را بررسی کنید
3. نتیجه را گزارش دهید
