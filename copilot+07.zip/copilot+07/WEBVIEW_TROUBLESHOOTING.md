# 🛠️ راهنمای عیب‌یابی صفحه سفید و مشکلات میکروفون در WebView اندروید

این راهنما به شما کمک می‌کند مشکلات صفحه سفید و دسترسی میکروفون در اپلیکیشن اندروید با WebView را رفع کنید.

## علت‌های احتمالی مشکل صفحه سفید و دسترسی میکروفون

1. **تنظیمات WebView ناقص**: تنظیمات ضروری فعال نشده‌اند
2. **مجوز میکروفون**: مجوز RECORD_AUDIO در اندروید اعطا نشده است
3. **onPermissionRequest**: مدیریت نادرست درخواست مجوز در WebChromeClient
4. **Mixed Content**: محتوای مختلط HTTP/HTTPS بلاک شده است
5. **setMediaPlaybackRequiresUserGesture**: تنظیم نشده یا اشتباه تنظیم شده است
6. **JavaScriptInterface**: اینترفیس JavaScript برای ارتباط با کد native نصب نشده است
7. **خطای reload بعد از مجوز**: صفحه بعد از اعطای مجوز بازنشانی نشده است

## گام‌های دیباگ کردن و رفع مشکل

### 1. بررسی تنظیمات WebView در MainActivity.java

```java
WebSettings webSettings = webView.getSettings();
webSettings.setJavaScriptEnabled(true);
webSettings.setDomStorageEnabled(true);
webSettings.setMediaPlaybackRequiresUserGesture(false); // مهم برای میکروفون
webSettings.setAllowFileAccess(true);
webSettings.setAllowContentAccess(true);
webSettings.setDatabaseEnabled(true);

// تنظیمات ضروری برای mixed content
if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
    webSettings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
}
```

### 2. فعال کردن Remote Debugging

```java
// Enable debugging if in development build
if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
    WebView.setWebContentsDebuggingEnabled(true);
}
```

سپس در کامپیوتر خود:
1. Chrome را باز کنید
2. به `chrome://inspect` بروید
3. دستگاه اندروید را با USB متصل کنید
4. روی "inspect" برای WebView مورد نظر کلیک کنید

### 3. بررسی خطاها در WebViewClient

```java
webView.setWebViewClient(new WebViewClient() {
    @Override
    public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Log.e(TAG, "WebView Error: " + error.getDescription());
            Toast.makeText(MainActivity.this, "خطا: " + error.getDescription(), Toast.LENGTH_LONG).show();
        }
    }
});
```

### 4. بررسی مدیریت مجوزها در WebChromeClient

```java
webView.setWebChromeClient(new WebChromeClient() {
    @Override
    public void onPermissionRequest(PermissionRequest request) {
        Log.d(TAG, "onPermissionRequest: " + request.getOrigin().toString());
        
        // اجرا در UI thread بسیار مهم است
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                String[] resources = request.getResources();
                request.grant(resources);
                Log.d(TAG, "Permission granted to WebView");
            }
        });
    }
});
```

### 5. بررسی AndroidManifest.xml

اطمینان حاصل کنید مجوزهای زیر درخواست شده‌اند:

```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.RECORD_AUDIO" />
<uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />

<application
    ...
    android:usesCleartextTraffic="true">
```

### 6. رفع مشکل صفحه سفید بعد از تغییر مجوز

بعد از اعطای مجوز، WebView را بازنشانی کنید:

```java
@Override
public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
    super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    
    if (requestCode == REQUEST_MICROPHONE) {
        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            // مجوز اعطا شد
            
            // کمی تاخیر قبل از بازنشانی
            new android.os.Handler().postDelayed(
                new Runnable() {
                    public void run() {
                        webView.reload();
                    }
                }, 
                500);
        }
    }
}
```

### 7. استفاده از کد تست برای بررسی مشکلات

- فایل `android-webview-test.html` را باز کنید
- دکمه "تست محیط WebView" را بزنید تا وضعیت محیط مشخص شود
- دکمه "تست دسترسی میکروفون" را بزنید تا مشکلات مجوز شناسایی شوند
- دکمه "تست بازنشانی صفحه" را بزنید اگر بعد از تغییر مجوز مشکلی دارید

### 8. بررسی لاگ‌های کاربردی در Logcat

در Android Studio، Logcat را باز کنید و فیلترهای زیر را استفاده کنید:
- `GlobgramWebView`: لاگ‌های اصلی اپلیکیشن
- `WebAppInterface`: لاگ‌های JavaScriptInterface
- `PermissionRequest`: برای بررسی درخواست‌های مجوز
- `WebViewFactory`: برای بررسی خطاهای WebView

### 9. راه‌حل‌های شایع

1. **صفحه سفید**: 
   - فعال کردن JavaScript
   - تنظیم Mixed Content Mode
   - فعال کردن DOM Storage

2. **عدم دسترسی میکروفون**:
   - تنظیم `setMediaPlaybackRequiresUserGesture(false)`
   - اجرای `request.grant()` در `onPermissionRequest`
   - درخواست مجوز RECORD_AUDIO
   - بازنشانی صفحه بعد از اعطای مجوز

3. **بعد از اعطای مجوز هنوز کار نمی‌کند**:
   - بازنشانی WebView بعد از اعطای مجوز
   - استفاده از `evaluateJavascript` برای اطلاع به JavaScript
   - تست با کد آزمایشی قبل از استفاده در برنامه اصلی

## آزمایش نهایی

برای اطمینان از رفع مشکل:

1. مجوز میکروفون را غیرفعال کنید (از تنظیمات اندروید)
2. اپلیکیشن را باز کنید
3. به صفحه ضبط صدا بروید
4. درخواست مجوز را تایید کنید
5. بررسی کنید که صفحه به درستی بازنشانی شود و میکروفون کار کند

## خطاهای رایج و راه‌حل‌ها

### NotAllowedError
- مجوز میکروفون رد شده است
- به کاربر پیشنهاد دهید تنظیمات اپلیکیشن را باز کند

### SecurityError
- درخواست مجوز در `onPermissionRequest` صحیح مدیریت نشده است
- از `runOnUiThread` برای اعطای مجوز استفاده کنید

### NetworkError
- مشکل در بارگذاری منابع
- تنظیمات Mixed Content را بررسی کنید

### AbortError
- میکروفون توسط برنامه دیگری استفاده می‌شود
- به کاربر پیشنهاد دهید برنامه‌های دیگر را ببندد

## نکات پیشرفته

1. **لاگ کامل**: تمام خطاها و درخواست‌های مجوز را لاگ کنید
2. **Fallback**: یک راه جایگزین برای آپلود فایل صوتی در صورت ادامه مشکل فراهم کنید
3. **تست کامل**: تمام مسیرهای کاربر را تست کنید، از جمله:
   - اعطای مجوز از ابتدا
   - رد مجوز و سپس اعطا
   - اعطای مجوز از تنظیمات
