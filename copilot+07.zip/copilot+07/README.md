# 🎤 Globgram - چت صوتی پیشرفته

پلتفرم چت صوتی مدرن با قابلیت‌های P2P و پشتیبانی کامل از زبان فارسی.

## ✨ ویژگی‌ها

- 🎤 **ضبط و ارسال پیام‌های صوتی** با کیفیت بالا
- 🏠 **اتاق‌های خصوصی** - ایجاد و پیوستن به اتاق‌های چت
- 🔒 **امنیت بالا** - ارتباط مستقیم P2P و رمزنگاری شده
- 📱 **Mobile Ready** - سازگار با تمام دستگاه‌ها
- 🌐 **RTL Support** - پشتیبانی کامل از زبان فارسی
- ⌨️ **کلیدهای میانبر** - Ctrl + Space برای ضبط سریع
- 👥 **Real-time** - نمایش کاربران آنلاین
- 🎨 **UI مدرن** - طراحی زیبا و responsive

## 🛠️ تکنولوژی‌ها

- **Frontend**: HTML5, CSS3, Vanilla JavaScript
- **Database**: Dexie.js (IndexedDB wrapper)
- **P2P Communication**: PeerJS
- **Email Service**: EmailJS

## 🚀 نصب و راه‌اندازی

### پیش‌نیازها
- مرورگر مدرن با پشتیبانی از WebRTC
- HTTPS (برای production و دسترسی میکروفون)

### مراحل نصب

1. **کلون کردن پروژه:**
```bash
git clone <repository-url>
cd globgram
```

2. **تنظیم متغیرهای محیطی:**
```bash
# کپی کردن فایل env نمونه
cp src/env-config.example.js src/env-config.js

# ویرایش کلیدهای EmailJS
nano src/env-config.js
```

3. **راه‌اندازی سرور محلی:**
```bash
# با Python
python -m http.server 8000

# یا با Node.js
npx serve .

# یا با VS Code Live Server
```

4. **باز کردن در مرورگر:**
```
http://localhost:8000
```

## ⚙️ تنظیمات

### EmailJS Configuration
1. حساب [EmailJS](https://www.emailjs.com/) ایجاد کنید
2. یک service و template برای verification codes بسازید
3. کلیدها را در `src/env-config.js` قرار دهید:

```javascript
const ENV_CONFIG = {
    EMAIL: {
        PUBLIC_KEY: "your_public_key",
        SERVICE_ID: "your_service_id", 
        TEMPLATE_ID: "your_template_id"
    }
};
```

### STUN Servers
اگر نیاز به STUN servers خاص دارید، در `src/config.js` تغییر دهید:

```javascript
STUN_SERVERS: [
    { urls: 'stun:your-stun-server.com:19302' }
]
```

## 📱 استفاده در موبایل

### نصب آسان
- هیچ نیازی به دانلود اپلیکیشن نیست
- فقط در مرورگر باز کنید
- Bookmark کنید برای دسترسی سریع

### بهینه‌سازی موبایل
- رابط کاربری تطبیقی
- لمس‌های بهینه شده
- حداقل مصرف باتری

## 📱 ساخت اپلیکیشن Android

### 🚀 **راه سریع:**
```bash
# نصب Cordova
npm install -g cordova

# ایجاد پروژه Android
cordova create globgram-app com.example.globgram Globgram
cp -r * globgram-app/www/
cd globgram-app

# اضافه کردن plugins مورد نیاز
cordova plugin add cordova-plugin-media
cordova plugin add cordova-plugin-android-permissions

# ساخت APK
cordova platform add android
cordova build android
```

### 📖 **راهنمای کامل:**
برای جزئیات کامل ساخت اپلیکیشن Android، فایل [`ANDROID_BUILD_GUIDE.md`](ANDROID_BUILD_GUIDE.md) را مطالعه کنید.

### ⚠️ **نکات مهم Android App:**
- ✅ مجوز میکروفون خودکار درخواست می‌شود
- ✅ بهینه‌سازی خاص برای Android WebView
- ✅ پشتیبانی از Cordova plugins
- ✅ مدیریت permissions هوشمند

## 🔧 عیب‌یابی Android App

### **مشکل: میکروفون کار نمی‌کند**
1. تنظیمات > اپلیکیشن‌ها > Globgram > مجوزها > میکروفون ✅
2. گوشی را restart کنید
3. دکمه "تست میکروفون" را امتحان کنید

### **مشکل: اپ باز نمی‌شود**
1. Android 6+ (API 23+) مورد نیاز است
2. حداقل 50MB فضای خالی
3. Developer Options > USB Debugging برای test

## 🎯 نحوه استفاده

### ایجاد اتاق جدید
1. در صفحه اصلی "ایجاد اتاق" کلیک کنید
2. کد اتاق تولید شده را با دوستان به اشتراک بگذارید

### پیوستن به اتاق
1. "پیوستن به اتاق" را انتخاب کنید
2. کد اتاق را وارد کنید

### ضبط پیام صوتی
- **روش 1**: دکمه "🎤 شروع ضبط" کلیک کنید
- **روش 2**: `Ctrl + Space` فشار دهید
- حداکثر 60 ثانیه ضبط امکان‌پذیر است

## 🛡️ امنیت

- ✅ ارتباط P2P مستقیم (بدون سرور میانی)
- ✅ HTTPS برای production
- ✅ Environment variables برای کلیدهای API
- ✅ Rate limiting برای جلوگیری از spam
- ✅ Validation ورودی‌ها

## 📊 Browser Support

| مرورگر | Desktop | Mobile |
|---------|---------|--------|
| Chrome | ✅ | ✅ |
| Firefox | ✅ | ✅ |
| Safari | ✅ | ✅ |
| Edge | ✅ | ✅ |

## 🐛 عیب‌یابی

### مشکلات رایج

**میکروفون کار نمی‌کند:**
- اجازه دسترسی به میکروفون را بررسی کنید
- از HTTPS استفاده کنید (HTTP مجاز نیست)

**اتصال برقرار نمی‌شود:**
- اتصال اینترنت را بررسی کنید
- STUN servers در دسترس باشند
- Firewall یا VPN مداخله نکند

**کیفیت صدا پایین:**
- در تنظیمات کیفیت ضبط را افزایش دهید
- شرایط شبکه را بهبود ببخشید

### لاگ‌ها
```javascript
// در Console مرورگر
console.log(window.errorHandler.getErrorStats());
```

## 🤝 مشارکت

1. Fork کنید
2. Branch جدید بسازید (`git checkout -b feature/amazing-feature`)
3. تغییرات را commit کنید (`git commit -m 'Add amazing feature'`)
4. Push کنید (`git push origin feature/amazing-feature`)
5. Pull Request ایجاد کنید

## 📄 مجوز

این پروژه تحت مجوز MIT منتشر شده است. فایل [LICENSE](LICENSE) را ببینید.

## 📞 پشتیبانی

- 📧 Email: support@globgram.app
- 🐛 Issues: [GitHub Issues](../../issues)
- 📚 Documentation: [Wiki](../../wiki)

## 🙏 تشکر

- [PeerJS](https://peerjs.com/) برای P2P connectivity
- [Dexie.js](https://dexie.org/) برای database management
- [EmailJS](https://www.emailjs.com/) برای email services

---

**ساخته شده با ❤️ برای جامعه فارسی‌زبان**

## 🔧 مشکلات رفع شده

### ❌ مشکل Navigation در اندروید
**مشکل:** پس از ایجاد اتاق، صفحه به خوش‌آمدگویی و تنظیمات می‌پرید.

**راه‌حل:**
- حذف timeout از ایجاد اتاق
- بهبود session management برای Android WebView
- استفاده از `location.replace` به جای `location.href`
- اضافه کردن retry mechanism برای localStorage
- پیاده‌سازی فلگ `fromChatRoom` برای جلوگیری از loop

**تست:** فایل `android-navigation-test.html` برای تست و debug

### ✅ بهبودهای اعمال شده
- 🔒 حذف کامل PWA و Service Worker
- 🛡️ بهبود امنیت با env-config.js
- 🎤 بهبود دسترسی میکروفون در Android
- 📱 تشخیص محیط و مدیریت مجوزها
- 🎨 بهبود UI/UX و accessibility
- 🔄 بهبود error handling و Toast notifications

## ⚠️ مهم: محیط HTTP و محدودیت میکروفون

### مشکل دسترسی میکروفون در HTTP
مرورگرهای مدرن دسترسی به میکروفون را فقط در محیط‌های امن (HTTPS) مجاز می‌کنند. اگر از HTTP یا فایل‌های محلی استفاده می‌کنید:

#### 🔥 راه‌حل‌های فوری:
1. **آپلود فایل صوتی**: دکمه "📁 آپلود فایل صوتی" در اتاق چت
2. **GitHub Pages رایگان**: پروژه را در 5 دقیقه با HTTPS منتشر کنید
3. **اپلیکیشن اندروید**: بدون محدودیت میکروفون

📖 **راهنمای کامل**: `HTTP_GUIDE.md`
