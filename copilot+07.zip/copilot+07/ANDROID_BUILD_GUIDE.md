# 📱 راهنمای ساخت اپلیکیشن Android برای Globgram

## 🎯 مقدمه
این راهنما نحوه تبدیل پروژه Globgram به یک اپلیکیشن Android کامل را توضیح می‌دهد.

## 🛠️ روش‌های موجود

### 1️⃣ **Apache Cordova (توصیه شده)**
```bash
# نصب Cordova
npm install -g cordova

# ایجاد پروژه جدید
cordova create globgram-app com.example.globgram Globgram

# کپی کردن فایل‌های وب
cp -r * globgram-app/www/

# اضافه کردن پلتفرم Android
cd globgram-app
cordova platform add android

# نصب plugins مورد نیاز
cordova plugin add cordova-plugin-media
cordova plugin add cordova-plugin-android-permissions
cordova plugin add cordova-plugin-file

# ساخت APK
cordova build android
```

### 2️⃣ **Capacitor (مدرن)**
```bash
# نصب Capacitor
npm install @capacitor/core @capacitor/cli @capacitor/android

# راه‌اندازی
npx cap init globgram com.example.globgram

# کپی فایل‌های وب
npx cap copy

# اضافه کردن Android
npx cap add android

# باز کردن در Android Studio
npx cap open android
```

### 3️⃣ **PWA به APK (ساده‌ترین)**
```bash
# استفاده از PWA Builder
# https://www.pwabuilder.com

# یا Bubblewrap
npm install -g @bubblewrap/cli
bubblewrap init --manifest https://yoursite.com/manifest.json
bubblewrap build
```

## ⚙️ تنظیمات مورد نیاز

### 📄 **config.xml برای Cordova:**
```xml
<?xml version='1.0' encoding='utf-8'?>
<widget id="com.example.globgram" version="1.0.0" xmlns="http://www.w3.org/ns/widgets">
    <name>Globgram</name>
    <description>چت صوتی پیشرفته</description>
    <author email="dev@example.com" href="https://example.com">
        Globgram Team
    </author>
    
    <content src="index.html" />
    
    <!-- مجوزها -->
    <uses-permission android:name="android.permission.RECORD_AUDIO" />
    <uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    
    <!-- تنظیمات Android -->
    <platform name="android">
        <preference name="android-minSdkVersion" value="22" />
        <preference name="android-targetSdkVersion" value="33" />
        
        <!-- WebView تنظیمات -->
        <preference name="AndroidLaunchMode" value="singleTop" />
        <preference name="AndroidInsecureFileModeEnabled" value="true" />
        
        <!-- مجوزهای خاص -->
        <config-file target="AndroidManifest.xml" parent="/manifest">
            <uses-permission android:name="android.permission.RECORD_AUDIO" />
            <uses-feature android:name="android.hardware.microphone" android:required="true" />
        </config-file>
    </platform>
</widget>
```

### 📱 **AndroidManifest.xml اضافی:**
```xml
<!-- در AndroidManifest.xml -->
<uses-permission android:name="android.permission.RECORD_AUDIO" />
<uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />

<uses-feature 
    android:name="android.hardware.microphone" 
    android:required="true" />
```

## 🔧 تنظیمات پروژه

### 📦 **package.json برای Cordova:**
```json
{
  "name": "globgram-app",
  "version": "1.0.0",
  "description": "چت صوتی پیشرفته",
  "main": "index.js",
  "scripts": {
    "build": "cordova build android",
    "run": "cordova run android",
    "prepare": "cordova prepare"
  },
  "dependencies": {
    "cordova-android": "^12.0.0",
    "cordova-plugin-android-permissions": "^1.1.0",
    "cordova-plugin-media": "^6.1.0",
    "cordova-plugin-file": "^8.0.0"
  }
}
```

## 🎤 مدیریت دسترسی صدا در Android

### ✅ **کدهای اضافی برای پروژه:**

در `src/voice-manager.js` این کدها اضافه شده:

```javascript
// تشخیص محیط Android App
if (this.platform.isAndroidApp || this.platform.isCordova) {
    const permissionGranted = await this.requestAndroidAppPermissions();
    if (!permissionGranted) {
        this.showAndroidPermissionGuide();
        return;
    }
}
```

### 🔐 **مدیریت Permissions:**

```javascript
// استفاده از Cordova Permissions Plugin
if (window.cordova && window.cordova.plugins.permissions) {
    const permission = cordova.plugins.permissions.RECORD_AUDIO;
    cordova.plugins.permissions.requestPermission(permission, success, error);
}
```

## 📋 مراحل کامل ساخت اپ

### 1️⃣ **آماده‌سازی پروژه:**
```bash
# کلون پروژه
git clone <your-repo>
cd globgram

# ایجاد env-config.js
cp src/env-config.example.js src/env-config.js
# ویرایش کلیدهای EmailJS
```

### 2️⃣ **نصب Cordova:**
```bash
npm install -g cordova
cordova create globgram-app com.yourcompany.globgram Globgram
```

### 3️⃣ **کپی فایل‌ها:**
```bash
cp -r *.html *.css *.js src/ globgram-app/www/
```

### 4️⃣ **تنظیم plugins:**
```bash
cd globgram-app
cordova plugin add cordova-plugin-media
cordova plugin add cordova-plugin-android-permissions
cordova plugin add cordova-plugin-device
cordova plugin add cordova-plugin-network-information
```

### 5️⃣ **اضافه کردن Android:**
```bash
cordova platform add android
```

### 6️⃣ **ساخت APK:**
```bash
# برای test
cordova build android

# برای release
cordova build android --release
```

## 🐛 مشکلات رایج و راه‌حل

### ❌ **مشکل: میکروفون کار نمی‌کند**
**راه‌حل:**
```xml
<!-- در config.xml اضافه کنید -->
<edit-config file="app/src/main/AndroidManifest.xml" mode="merge" target="/manifest/application">
    <application android:usesCleartextTraffic="true" />
</edit-config>
```

### ❌ **مشکل: CORS Error**
**راه‌حل:**
```javascript
// در config.xml
<access origin="*" />
<allow-navigation href="*" />
<allow-intent href="*" />
```

### ❌ **مشکل: مجوز صدا درخواست نمی‌شود**
**راه‌حل:**
```bash
# نصب plugin permissions
cordova plugin add cordova-plugin-android-permissions

# در کد JavaScript
document.addEventListener('deviceready', function() {
    var permissions = cordova.plugins.permissions;
    permissions.requestPermission(permissions.RECORD_AUDIO, success, error);
});
```

## ⚠️ رفع مشکل Navigation در اندروید

### 🔍 مشکل شناسایی شده
پس از ایجاد اتاق در اپ اندروید، صفحه به جای ماندن در chat-room.html، به صفحه خوش‌آمدگویی و سپس تنظیمات می‌پرید.

### 🛠️ راه‌حل‌های پیاده‌سازی شده

#### 1. حذف Timeout از ایجاد اتاق
- ✅ تغییر `setTimeout` 3 ثانیه‌ای به انتقال فوری
- ✅ اضافه کردن تابع `navigateToRoom()` با مدیریت ویژه Android

#### 2. بهبود Session Management
- ✅ بررسی session قبل از ایجاد/پیوستن به اتاق
- ✅ Retry mechanism برای Android WebView
- ✅ استفاده از `location.replace` به جای `location.href` در Android

#### 3. تشخیص و مدیریت Android
```javascript
const isAndroid = /android/i.test(navigator.userAgent);
const isWebView = window.navigator.userAgent.includes('wv');

if (isAndroid || isWebView) {
    window.location.replace('chat-room.html');
} else {
    window.location.href = 'chat-room.html';
}
```

#### 4. جلوگیری از Loop Navigation
- ✅ اضافه کردن فلگ `fromChatRoom` در sessionStorage
- ✅ بررسی فلگ در index.html برای نمایش مستقیم محتوای اصلی

### 🧪 تست مشکل
1. فایل `android-navigation-test.html` ایجاد شده
2. برای تست کامل در Android WebView یا Cordova استفاده کنید
3. مراحل تست:
   - تشخیص محیط
   - تست localStorage/sessionStorage
   - شبیه‌سازی ایجاد اتاق
   - تست navigation

### 📱 تنظیمات ویژه Android در config.xml

```xml
<!-- جلوگیری از مشکلات Navigation -->
<preference name="DisallowOverscroll" value="true" />
<preference name="webviewbounce" value="false" />
<preference name="UIWebViewBounce" value="false" />

<!-- بهبود WebView Performance -->
<preference name="AndroidLaunchMode" value="singleTop" />
<preference name="LoadUrlTimeoutValue" value="60000" />

<!-- مجوزهای ضروری -->
<uses-permission android:name="android.permission.RECORD_AUDIO" />
<uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />
```

### 🔧 Debug اضافی
در صورت مشکل، در console مرورگر چک کنید:
```javascript
console.log('User session:', localStorage.getItem('userEmail'));
console.log('Room code:', localStorage.getItem('currentRoomCode'));
console.log('From chat room flag:', sessionStorage.getItem('fromChatRoom'));
```

## 📱 تست روی دستگاه

### 🔌 **USB Debugging:**
```bash
# فعال کردن Developer Options در Android
# Settings > About Phone > Build Number (7 بار کلیک)
# Settings > Developer Options > USB Debugging ✅

# اجرا روی دستگاه
cordova run android --device
```

### 📲 **نصب APK:**
```bash
# پیدا کردن APK
# platforms/android/app/build/outputs/apk/debug/app-debug.apk

# نصب دستی
adb install app-debug.apk
```

## 🎯 بهینه‌سازی برای Production

### 🚀 **Minification:**
```bash
cordova build android --release --buildConfig=build.json
```

### 🔐 **Signing APK:**
```json
// build.json
{
  "android": {
    "release": {
      "keystore": "globgram.keystore",
      "storePassword": "password",
      "alias": "globgram",
      "password": "password"
    }
  }
}
```

### 📦 **App Bundle:**
```bash
cordova build android --packageType=bundle
```

## 📚 منابع مفید

- [Cordova Documentation](https://cordova.apache.org/docs/)
- [Android Permissions Guide](https://developer.android.com/guide/topics/permissions)
- [WebRTC on Android](https://webrtc.org/getting-started/android)
- [PWA Builder](https://www.pwabuilder.com/)

## 💡 نکات مهم

1. **همیشه permissions را در AndroidManifest.xml اضافه کنید**
2. **HTTPS الزامی است حتی در local testing**
3. **از Cordova plugins استفاده کنید نه Web APIs**
4. **APK را قبل از release روی دستگاه‌های مختلف تست کنید**
5. **Google Play Console requirements را رعایت کنید**

---

🎉 **موفق باشید در ساخت اپلیکیشن Android خود!**
