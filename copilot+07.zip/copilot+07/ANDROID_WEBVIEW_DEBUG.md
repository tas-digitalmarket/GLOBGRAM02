# 🎯 تنظیمات ضروری برای WebView اندروید

برای حل مشکل صفحه سفید و دسترسی میکروفون در WebView اندروید، کدهای زیر را در اپلیکیشن اندروید خود اعمال کنید:

## 1. تنظیمات WebView در MainActivity.java

```java
WebSettings webSettings = webView.getSettings();
webSettings.setJavaScriptEnabled(true);
webSettings.setDomStorageEnabled(true);
webSettings.setMediaPlaybackRequiresUserGesture(false); // مهم برای میکروفون
webSettings.setAllowFileAccess(true);
webSettings.setAllowContentAccess(true);
webSettings.setDatabaseEnabled(true);

// فعال کردن Remote Debugging (اختیاری - فقط برای دیباگ)
if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
    WebView.setWebContentsDebuggingEnabled(true);
}
```

## 2. مدیریت مجوزها در WebChromeClient

```java
webView.setWebChromeClient(new WebChromeClient() {
    @Override
    public void onPermissionRequest(PermissionRequest request) {
        Log.d(TAG, "onPermissionRequest: " + request.getOrigin().toString());
        
        // مهم: مجوز به WebView داده شود
        String[] resources = request.getResources();
        request.grant(resources);
        Log.d(TAG, "Permission granted to WebView");
    }
});
```

## 3. اضافه کردن JavaScriptInterface برای ارتباط با وب

```java
// تعریف JavaScriptInterface
webView.addJavascriptInterface(new WebAppInterface(this), "AndroidAudio");

// کلاس WebAppInterface
public class WebAppInterface {
    private Context mContext;

    public WebAppInterface(Context context) {
        this.mContext = context;
    }

    @JavascriptInterface
    public boolean hasAudioPermission() {
        return ContextCompat.checkSelfPermission(mContext, Manifest.permission.RECORD_AUDIO) 
                == PackageManager.PERMISSION_GRANTED;
    }
    
    @JavascriptInterface
    public boolean requestPermission() {
        // کد درخواست مجوز
        return true;
    }
}
```

## 4. اصلاح AndroidManifest.xml

```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.RECORD_AUDIO" />
<uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />

<application
    ...
    android:usesCleartextTraffic="true">
    
    <activity android:name=".MainActivity"
        android:configChanges="orientation|screenSize">
        ...
    </activity>
</application>
```

## 5. برای رفع مشکل صفحه سفید

```java
// در WebViewClient
@Override
public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
    Log.e(TAG, "WebView Error: " + description);
    // نمایش خطا به کاربر یا بارگذاری صفحه fallback
}

// رفع مشکل mixed content
webSettings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
```

## 6. دیباگ کردن WebView

برای دیباگ WebView، از Chrome DevTools استفاده کنید:
1. در کامپیوتر، Chrome را باز کنید
2. آدرس `chrome://inspect` را باز کنید
3. دستگاه اندروید را با USB متصل کنید
4. WebView فعال در اپلیکیشن شما را پیدا کنید
5. روی "inspect" کلیک کنید
