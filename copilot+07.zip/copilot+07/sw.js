// Service Worker برای Globgram PWA
const CACHE_NAME = 'globgram-v1.0.1'; // افزایش نسخه برای پاکسازی کش
const urlsToCache = [
  '/',
  '/index.html',
  '/chat-room.html',
  '/styles.css',
  '/src/config.js',
  '/src/database.js',
  '/src/auth.js',
  '/src/email-service.js',
  '/src/profile-manager.js',
  '/src/settings-manager.js',
  '/src/room-manager.js',
  '/src/connection-manager.js',
  '/src/voice-manager.js',
  '/src/chat-room.js',
  'https://unpkg.com/dexie@latest/dist/dexie.js',
  'https://unpkg.com/peerjs@1.4.7/dist/peerjs.min.js',
  'https://cdn.jsdelivr.net/npm/@emailjs/browser@3/dist/email.min.js'
];

// نصب Service Worker
self.addEventListener('install', (event) => {
  console.log('Service Worker: Installing...');
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => {
        console.log('Service Worker: Caching files');
        return cache.addAll(urlsToCache.map(url => {
          return new Request(url, { mode: 'cors' });
        }));
      })
      .catch((error) => {
        console.error('Service Worker: Failed to cache:', error);
      })
  );
});

// فعال‌سازی Service Worker
self.addEventListener('activate', (event) => {
  console.log('Service Worker: Activating...');
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheName !== CACHE_NAME) {
            console.log('Service Worker: Deleting old cache:', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});

// پاسخ به درخواست‌ها
self.addEventListener('fetch', (event) => {
  // فقط درخواست‌های GET را handle می‌کنیم
  if (event.request.method !== 'GET') {
    return;
  }

  // درخواست‌های external API را skip می‌کنیم
  if (event.request.url.includes('emailjs.com') || 
      event.request.url.includes('googleapis.com')) {
    return;
  }

  event.respondWith(
    caches.match(event.request)
      .then((response) => {
        // اگر در cache پیدا شد، برگردان
        if (response) {
          return response;
        }
        
        // وگرنه از شبکه دریافت کن
        return fetch(event.request)
          .then((response) => {
            // بررسی معتبر بودن پاسخ
            if (!response || response.status !== 200 || response.type !== 'basic') {
              return response;
            }

            // کپی کردن پاسخ برای cache
            const responseToCache = response.clone();
            
            caches.open(CACHE_NAME)
              .then((cache) => {
                cache.put(event.request, responseToCache);
              });

            return response;
          })
          .catch(() => {
            // اگر offline است، صفحه fallback نمایش بده
            if (event.request.destination === 'document') {
              return caches.match('/index.html');
            }
          });
      })
  );
});

// پیام‌های push (برای آینده)
self.addEventListener('push', (event) => {
  console.log('Service Worker: Push received');
  
  const options = {
    body: event.data ? event.data.text() : 'پیام جدید دریافت شد',
    icon: '/manifest-icon-192.png',
    badge: '/manifest-icon-192.png',
    dir: 'rtl',
    lang: 'fa',
    tag: 'globgram-notification',
    requireInteraction: true,
    actions: [
      {
        action: 'open',
        title: 'باز کردن'
      },
      {
        action: 'close',
        title: 'بستن'
      }
    ]
  };

  event.waitUntil(
    self.registration.showNotification('Globgram', options)
  );
});

// کلیک روی notification
self.addEventListener('notificationclick', (event) => {
  console.log('Service Worker: Notification clicked');
  
  event.notification.close();
  
  if (event.action === 'open') {
    event.waitUntil(
      clients.openWindow('/')
    );
  }
});
